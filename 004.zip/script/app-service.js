define("config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * 小程序配置文件
 */

// 此处主机域名是腾讯云解决方案分配的域名
// 小程序后台服务解决方案：https://www.qcloud.com/solution/la

var host = '14592619.qcloud.la';

var config = {

  // 下面的地址配合云端 Server 工作
  host: host,

  // 登录地址，用于建立会话
  loginUrl: 'https://' + host + '/login',

  // 测试的请求地址，用于测试会话
  requestUrl: 'https://' + host + '/testRequest',

  // 用code换取openId
  openIdUrl: 'https://' + host + '/openid',

  // 测试的信道服务接口
  tunnelUrl: 'https://' + host + '/tunnel',

  // 生成支付订单的接口
  paymentUrl: 'https://' + host + '/payment',

  // 发送模板消息接口
  templateMessageUrl: 'https://' + host + '/templateMessage',

  // 发送订阅消息接口
  subscribeMessageUrl: 'https://' + host + '/subscribeMessage',

  // 上传文件接口
  uploadFileUrl: 'https://' + host + '/upload',

  // 下载示例图片接口
  downloadExampleUrl: 'https://' + host + '/static/weapp.jpg',

  // 云开发环境 ID
  envId: 'release-b86096',

  // 云开发-存储 示例文件的文件 ID
  demoImageFileId: 'cloud://release-b86096.7265-release-b86096/demo.jpg',
  demoVideoFileId: 'cloud://release-b86096.7265-release-b86096/demo.mp4'
};

module.exports = config;
});
define("page/API/components/set-tab-bar/set-tab-bar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var defaultTabBarStyle = {
  color: '#7A7E83',
  selectedColor: '#3cc51f',
  backgroundColor: '#ffffff'
};

var defaultItemName = '接口';

Component({
  data: {
    hasSetTabBarBadge: false,
    hasShownTabBarRedDot: false,
    hasCustomedStyle: false,
    hasCustomedItem: false,
    hasHiddenTabBar: false
  },

  attached: function attached() {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0
    });
  },
  detached: function detached() {
    this.removeTabBarBadge();
    this.hideTabBarRedDot();
    this.showTabBar();
    this.removeCustomStyle();
    this.removeCustomItem();
  },


  methods: {
    navigateBack: function navigateBack() {
      this.triggerEvent('unmount');
    },
    setTabBarBadge: function setTabBarBadge() {
      if (this.data.hasSetTabBarBadge) {
        this.removeTabBarBadge();
        return;
      }
      this.setData({
        hasSetTabBarBadge: true
      });
      wx.setTabBarBadge({
        index: 1,
        text: '1'
      });
    },
    removeTabBarBadge: function removeTabBarBadge() {
      this.setData({
        hasSetTabBarBadge: false
      });
      wx.removeTabBarBadge({
        index: 1
      });
    },
    showTabBarRedDot: function showTabBarRedDot() {
      if (this.data.hasShownTabBarRedDot) {
        this.hideTabBarRedDot();
        return;
      }
      this.setData({
        hasShownTabBarRedDot: true
      });
      wx.showTabBarRedDot({
        index: 1
      });
    },
    hideTabBarRedDot: function hideTabBarRedDot() {
      this.setData({
        hasShownTabBarRedDot: false
      });
      wx.hideTabBarRedDot({
        index: 1
      });
    },
    showTabBar: function showTabBar() {
      this.setData({ hasHiddenTabBar: false });
      wx.showTabBar();
    },
    hideTabBar: function hideTabBar() {
      if (this.data.hasHiddenTabBar) {
        this.showTabBar();
        return;
      }
      this.setData({ hasHiddenTabBar: true });
      wx.hideTabBar();
    },
    customStyle: function customStyle() {
      if (this.data.hasCustomedStyle) {
        this.removeCustomStyle();
        return;
      }
      this.setData({ hasCustomedStyle: true });
      wx.setTabBarStyle({
        color: '#FFF',
        selectedColor: '#1AAD19',
        backgroundColor: '#000000'
      });
    },
    removeCustomStyle: function removeCustomStyle() {
      this.setData({ hasCustomedStyle: false });
      wx.setTabBarStyle(defaultTabBarStyle);
    },
    customItem: function customItem() {
      if (this.data.hasCustomedItem) {
        this.removeCustomItem();
        return;
      }
      this.setData({ hasCustomedItem: true });
      wx.setTabBarItem({
        index: 1,
        text: 'API'
      });
    },
    removeCustomItem: function removeCustomItem() {
      this.setData({ hasCustomedItem: false });
      wx.setTabBarItem({
        index: 1,
        text: defaultItemName
      });
    }
  }
});
});
define("page/API/pages/canvas/example.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var example = {};

example.rotate = function (context) {
  context.beginPath();
  context.rotate(10 * Math.PI / 180);
  context.rect(225, 75, 20, 10);
  context.fill();
};

example.scale = function (context) {
  context.beginPath();
  context.rect(25, 25, 50, 50);
  context.stroke();

  context.scale(2, 2);

  context.beginPath();
  context.rect(25, 25, 50, 50);
  context.stroke();
};

example.reset = function (context) {
  context.beginPath();

  context.setFillStyle('#000000');
  context.setStrokeStyle('#000000');
  context.setFontSize(10);

  context.setShadow(0, 0, 0, 'rgba(0, 0, 0, 0)');

  context.setLineCap('butt');
  context.setLineJoin('miter');
  context.setLineWidth(1);
  context.setMiterLimit(10);
};

example.translate = function (context) {
  context.beginPath();
  context.rect(10, 10, 100, 50);
  context.fill();

  context.translate(70, 70);

  context.beginPath();
  context.fill();
};

example.save = function (context) {
  context.beginPath();
  context.setStrokeStyle('#00ff00');
  context.save();

  context.scale(2, 2);
  context.setStrokeStyle('#ff0000');
  context.rect(0, 0, 100, 100);
  context.stroke();
  context.restore();

  context.rect(0, 0, 50, 50);
  context.stroke();
};

example.restore = function (context) {
  [3, 2, 1].forEach(function (item) {
    context.beginPath();
    context.save();
    context.scale(item, item);
    context.rect(10, 10, 100, 100);
    context.stroke();
    context.restore();
  });
};

example.drawImage = function (context) {
  context.drawImage('/image/wechat.png', 0, 0);
};

example.fillText = function (context) {
  context.setStrokeStyle('#ff0000');

  context.beginPath();
  context.moveTo(0, 10);
  context.lineTo(300, 10);
  context.stroke();

  // context.save()
  // context.scale(1.5, 1.5)
  // context.translate(20, 20)
  context.setFontSize(10);
  context.fillText('Hello World', 0, 30);
  context.setFontSize(20);
  context.fillText('Hello World', 100, 30);

  // context.restore()

  context.beginPath();
  context.moveTo(0, 30);
  context.lineTo(300, 30);
  context.stroke();
};

example.fill = function (context) {
  context.beginPath();
  context.rect(20, 20, 150, 100);
  context.setStrokeStyle('#00ff00');
  context.fill();
};

example.stroke = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.setStrokeStyle('#00ff00');
  context.stroke();
};

example.clearRect = function (context) {
  context.setFillStyle('#ff0000');
  context.beginPath();
  context.rect(0, 0, 300, 150);
  context.fill();
  context.clearRect(20, 20, 100, 50);
};

example.beginPath = function (context) {
  context.beginPath();
  context.setLineWidth(5);
  context.setStrokeStyle('#ff0000');
  context.moveTo(0, 75);
  context.lineTo(250, 75);
  context.stroke();

  context.beginPath();
  context.setStrokeStyle('#0000ff');
  context.moveTo(50, 0);
  context.lineTo(150, 130);
  context.stroke();
};

example.closePath = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.closePath();
  context.stroke();
};

example.moveTo = function (context) {
  context.beginPath();
  context.moveTo(0, 0);
  context.lineTo(300, 150);
  context.stroke();
};

example.lineTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.lineTo(20, 100);
  context.lineTo(70, 100);
  context.stroke();
};

example.rect = function (context) {
  context.beginPath();
  context.rect(20, 20, 150, 100);
  context.stroke();
};

example.arc = function (context) {
  context.beginPath();
  context.arc(75, 75, 50, 0, Math.PI * 2, true);
  context.moveTo(110, 75);
  context.arc(75, 75, 35, 0, Math.PI, false);
  context.moveTo(65, 65);
  context.arc(60, 65, 5, 0, Math.PI * 2, true);
  context.moveTo(95, 65);
  context.arc(90, 65, 5, 0, Math.PI * 2, true);
  context.stroke();
};

example.quadraticCurveTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.quadraticCurveTo(20, 100, 200, 20);
  context.stroke();
};

example.bezierCurveTo = function (context) {
  context.beginPath();
  context.moveTo(20, 20);
  context.bezierCurveTo(20, 100, 200, 100, 200, 20);
  context.stroke();
};

example.setFillStyle = function (context) {
  ['#fef957', 'rgb(242,159,63)', 'rgb(242,117,63)', '#e87e51'].forEach(function (item, index) {
    context.setFillStyle(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.fill();
  });
};

example.setStrokeStyle = function (context) {
  ['#fef957', 'rgb(242,159,63)', 'rgb(242,117,63)', '#e87e51'].forEach(function (item, index) {
    context.setStrokeStyle(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.stroke();
  });
};

example.setGlobalAlpha = function (context) {
  context.setFillStyle('#000000');
  [1, 0.5, 0.1].forEach(function (item, index) {
    context.setGlobalAlpha(item);
    context.beginPath();
    context.rect(0 + 75 * index, 0, 50, 50);
    context.fill();
  });
};

example.setShadow = function (context) {
  context.beginPath();
  context.setShadow(10, 10, 10, 'rgba(0, 0, 0, 199)');
  context.rect(10, 10, 100, 100);
  context.fill();
};

example.setFontSize = function (context) {
  [10, 20, 30, 40].forEach(function (item, index) {
    context.setFontSize(item);
    context.fillText('Hello, world', 20, 20 + 40 * index);
  });
};

example.setLineCap = function (context) {
  context.setLineWidth(10);
  ['butt', 'round', 'square'].forEach(function (item, index) {
    context.beginPath();
    context.setLineCap(item);
    context.moveTo(20, 20 + 20 * index);
    context.lineTo(100, 20 + 20 * index);
    context.stroke();
  });
};

example.setLineJoin = function (context) {
  context.setLineWidth(10);
  ['bevel', 'round', 'miter'].forEach(function (item, index) {
    context.beginPath();

    context.setLineJoin(item);
    context.moveTo(20 + 80 * index, 20);
    context.lineTo(100 + 80 * index, 50);
    context.lineTo(20 + 80 * index, 100);
    context.stroke();
  });
};

example.setLineWidth = function (context) {
  [2, 4, 6, 8, 10].forEach(function (item, index) {
    context.beginPath();
    context.setLineWidth(item);
    context.moveTo(20, 20 + 20 * index);
    context.lineTo(100, 20 + 20 * index);
    context.stroke();
  });
};

example.setMiterLimit = function (context) {
  context.setLineWidth(4);

  [2, 4, 6, 8, 10].forEach(function (item, index) {
    context.beginPath();
    context.setMiterLimit(item);
    context.moveTo(20 + 80 * index, 20);
    context.lineTo(100 + 80 * index, 50);
    context.lineTo(20 + 80 * index, 100);
    context.stroke();
  });
};

module.exports = example;
});
define("page/API/pages/custom-service/custom-service.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

Page({});
});
define("page/API/pages/sendMessage/sendMessage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

Page({});
});
define("util/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function formatTime(time) {
  if (typeof time !== 'number' || time < 0) {
    return time;
  }

  var hour = parseInt(time / 3600, 10);
  time %= 3600;
  var minute = parseInt(time / 60, 10);
  time = parseInt(time % 60, 10);
  var second = time;

  return [hour, minute, second].map(function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  }).join(':');
}

function formatLocation(longitude, latitude) {
  if (typeof longitude === 'string' && typeof latitude === 'string') {
    longitude = parseFloat(longitude);
    latitude = parseFloat(latitude);
  }

  longitude = longitude.toFixed(2);
  latitude = latitude.toFixed(2);

  return {
    longitude: longitude.toString().split('.'),
    latitude: latitude.toString().split('.')
  };
}

function fib(n) {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fib(n - 1) + fib(n - 2);
}

function formatLeadingZeroNumber(n) {
  var digitNum = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;

  n = n.toString();
  var needNum = Math.max(digitNum - n.length, 0);
  return new Array(needNum).fill(0).join('') + n;
}

function formatDateTime(date) {
  var withMs = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var ms = date.getMilliseconds();

  var ret = [year, month, day].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join('-') + ' ' + [hour, minute, second].map(function (value) {
    return formatLeadingZeroNumber(value, 2);
  }).join(':');
  if (withMs) {
    ret += '.' + formatLeadingZeroNumber(ms, 3);
  }
  return ret;
}

function compareVersion(v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  var len = Math.max(v1.length, v2.length);

  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }

  for (var i = 0; i < len; i++) {
    var num1 = parseInt(v1[i], 10);
    var num2 = parseInt(v2[i], 10);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }

  return 0;
}

module.exports = {
  formatTime: formatTime,
  formatLocation: formatLocation,
  fib: fib,
  formatDateTime: formatDateTime,
  compareVersion: compareVersion
};
});
define("workers/fib/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function fib(n) {
  if (n < 1) return 0;
  if (n <= 2) return 1;
  return fib(n - 1) + fib(n - 2);
}

worker.onMessage(function (msg) {
  if (msg.type === 'execFunc_fib') {
    worker.postMessage({
      type: 'execFunc_fib',
      result: fib(msg.params[0])
    });
  }
});
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var config = require('./config');

App({
  onLaunch: function onLaunch(opts) {
    console.log('App Launch', opts);
  },
  onShow: function onShow(opts) {
    console.log('App Show', opts);
  },
  onHide: function onHide() {
    console.log('App Hide');
  },

  globalData: {
    hasLogin: false,
    openid: null
  },
  // lazy loading openid
  getUserOpenId: function getUserOpenId(callback) {
    var self = this;

    if (self.globalData.openid) {
      callback(null, self.globalData.openid);
    } else {
      wx.login({
        success: function success(data) {
          wx.request({
            url: config.openIdUrl,
            data: {
              code: data.code
            },
            success: function success(res) {
              console.log('拉取openid成功', res);
              self.globalData.openid = res.data.openid;
              callback(null, self.globalData.openid);
            },
            fail: function fail(res) {
              console.log('拉取用户openid失败，将无法正常使用开放接口等服务', res);
              callback(res);
            }
          });
        },
        fail: function fail(err) {
          console.log('wx.login 接口调用失败，将无法正常使用开放接口等服务', err);
          callback(err);
        }
      });
    }
  },

  // 通过云函数获取用户 openid，支持回调或 Promise
  getUserOpenIdViaCloud: function getUserOpenIdViaCloud() {
    var _this = this;

    return wx.cloud.callFunction({
      name: 'wxContext',
      data: {}
    }).then(function (res) {
      _this.globalData.openid = res.result.openid;
      return res.result.openid;
    });
  }
});
});require("app.js")
var __wxRoute = "page/component/index", __wxRouteBegin = true;
define("page/component/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShow: function onShow() {
    wx.reportAnalytics('enter_home_programmatically', {});
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序官方组件展示',
      path: 'page/component/index'
    };
  },


  data: {
    list: [{
      id: 'view',
      name: '视图容器',
      open: false,
      pages: ['view', 'scroll-view', 'swiper', 'movable-view', 'cover-view']
    }, {
      id: 'content',
      name: '基础内容',
      open: false,
      pages: ['text', 'icon', 'progress', 'rich-text']
    }, {
      id: 'form',
      name: '表单组件',
      open: false,
      pages: ['button', 'checkbox', 'form', 'input', 'label', 'picker', 'picker-view', 'radio', 'slider', 'switch', 'textarea', 'editor']
    }, {
      id: 'nav',
      name: '导航',
      open: false,
      pages: ['navigator']
    }, {
      id: 'media',
      name: '媒体组件',
      open: false,
      pages: ['image', 'audio', 'video', 'camera']
    }, {
      id: 'map',
      name: '地图',
      open: false,
      pages: ['map']
    }, {
      id: 'canvas',
      name: '画布',
      open: false,
      pages: ['canvas']
    }, {
      id: 'open',
      name: '开放能力',
      open: false,
      pages: ['ad', 'open-data', 'web-view']
    }]
  },

  kindToggle: function kindToggle(e) {
    var id = e.currentTarget.id;
    var list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
    wx.reportAnalytics('click_view_programmatically', {});
  }
});
});require("page/component/index.js")
var __wxRoute = "page/component/pages/view/view", __wxRouteBegin = true;
define("page/component/pages/view/view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'view',
      path: 'page/component/pages/view/view'
    };
  }
});
});require("page/component/pages/view/view.js")
var __wxRoute = "page/component/pages/scroll-view/scroll-view", __wxRouteBegin = true;
define("page/component/pages/scroll-view/scroll-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var order = ['demo1', 'demo2', 'demo3'];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'scroll-view',
      path: 'page/component/pages/scroll-view/scroll-view'
    };
  },


  data: {
    toView: 'green'
  },

  upper: function upper(e) {
    console.log(e);
  },
  lower: function lower(e) {
    console.log(e);
  },
  scroll: function scroll(e) {
    console.log(e);
  },
  scrollToTop: function scrollToTop() {
    this.setAction({
      scrollTop: 0
    });
  },
  tap: function tap() {
    for (var i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1],
          scrollTop: (i + 1) * 200
        });
        break;
      }
    }
  },
  tapMove: function tapMove() {
    this.setData({
      scrollTop: this.data.scrollTop + 10
    });
  }
});
});require("page/component/pages/scroll-view/scroll-view.js")
var __wxRoute = "page/component/pages/swiper/swiper", __wxRouteBegin = true;
define("page/component/pages/swiper/swiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'swiper',
      path: 'page/component/pages/swiper/swiper'
    };
  },


  data: {
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: false,
    autoplay: false,
    interval: 2000,
    duration: 500
  },

  changeIndicatorDots: function changeIndicatorDots() {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    });
  },
  changeAutoplay: function changeAutoplay() {
    this.setData({
      autoplay: !this.data.autoplay
    });
  },
  intervalChange: function intervalChange(e) {
    this.setData({
      interval: e.detail.value
    });
  },
  durationChange: function durationChange(e) {
    this.setData({
      duration: e.detail.value
    });
  }
});
});require("page/component/pages/swiper/swiper.js")
var __wxRoute = "page/component/pages/text/text", __wxRouteBegin = true;
define("page/component/pages/text/text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var texts = ['2011年1月，微信1.0发布', '同年5月，微信2.0语音对讲发布', '10月，微信3.0新增摇一摇功能', '2012年3月，微信用户突破1亿', '4月份，微信4.0朋友圈发布', '同年7月，微信4.2发布公众平台', '2013年8月，微信5.0发布微信支付', '2014年9月，企业号发布', '同月，发布微信卡包', '2015年1月，微信第一条朋友圈广告', '2016年1月，企业微信发布', '2017年1月，小程序发布', '......'];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'text',
      path: 'page/component/pages/text/text'
    };
  },


  data: {
    text: '',
    canAdd: true,
    canRemove: false
  },
  extraLine: [],

  add: function add() {
    var _this = this;

    this.extraLine.push(texts[this.extraLine.length % 12]);
    this.setData({
      text: this.extraLine.join('\n'),
      canAdd: this.extraLine.length < 12,
      canRemove: this.extraLine.length > 0
    });
    setTimeout(function () {
      _this.setData({
        scrollTop: 99999
      });
    }, 0);
  },
  remove: function remove() {
    var _this2 = this;

    if (this.extraLine.length > 0) {
      this.extraLine.pop();
      this.setData({
        text: this.extraLine.join('\n'),
        canAdd: this.extraLine.length < 12,
        canRemove: this.extraLine.length > 0
      });
    }
    setTimeout(function () {
      _this2.setData({
        scrollTop: 99999
      });
    }, 0);
  }
});
});require("page/component/pages/text/text.js")
var __wxRoute = "page/component/pages/icon/icon", __wxRouteBegin = true;
define("page/component/pages/icon/icon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'icon',
      path: 'page/component/pages/icon/icon'
    };
  }
});
});require("page/component/pages/icon/icon.js")
var __wxRoute = "page/component/pages/progress/progress", __wxRouteBegin = true;
define("page/component/pages/progress/progress.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'progress',
      path: 'page/component/pages/progress/progress'
    };
  }
});
});require("page/component/pages/progress/progress.js")
var __wxRoute = "page/component/pages/button/button", __wxRouteBegin = true;
define("page/component/pages/button/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var types = ['default', 'primary', 'warn'];
var pageObject = {
  data: {
    defaultSize: 'default',
    primarySize: 'default',
    warnSize: 'default',
    disabled: false,
    plain: false,
    loading: false
  },

  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'button',
      path: 'page/component/pages/button/button'
    };
  },
  setDisabled: function setDisabled() {
    this.setData({
      disabled: !this.data.disabled
    });
  },
  setPlain: function setPlain() {
    this.setData({
      plain: !this.data.plain
    });
  },
  setLoading: function setLoading() {
    this.setData({
      loading: !this.data.loading
    });
  }
};

for (var i = 0; i < types.length; ++i) {
  (function (type) {
    pageObject[type] = function () {
      var key = type + 'Size';
      var changedData = {};
      changedData[key] = this.data[key] === 'default' ? 'mini' : 'default';
      this.setData(changedData);
    };
  })(types[i]);
}

Page(pageObject);
});require("page/component/pages/button/button.js")
var __wxRoute = "page/component/pages/checkbox/checkbox", __wxRouteBegin = true;
define("page/component/pages/checkbox/checkbox.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'checkbox',
      path: 'page/component/pages/checkbox/checkbox'
    };
  },


  data: {
    items: [{ value: 'USA', name: '美国' }, { value: 'CHN', name: '中国', checked: 'true' }, { value: 'BRA', name: '巴西' }, { value: 'JPN', name: '日本' }, { value: 'ENG', name: '英国' }, { value: 'FRA', name: '法国' }]
  },

  checkboxChange: function checkboxChange(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);

    var items = this.data.items;
    var values = e.detail.value;
    for (var i = 0, lenI = items.length; i < lenI; ++i) {
      items[i].checked = false;

      for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
        if (items[i].value === values[j]) {
          items[i].checked = true;
          break;
        }
      }
    }

    this.setData({
      items: items
    });
  }
});
});require("page/component/pages/checkbox/checkbox.js")
var __wxRoute = "page/component/pages/form/form", __wxRouteBegin = true;
define("page/component/pages/form/form.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'form',
      path: 'page/component/pages/form/form'
    };
  },


  data: {
    pickerHidden: true,
    chosen: ''
  },

  pickerConfirm: function pickerConfirm(e) {
    this.setData({
      pickerHidden: true
    });
    this.setData({
      chosen: e.detail.value
    });
  },
  pickerCancel: function pickerCancel() {
    this.setData({
      pickerHidden: true
    });
  },
  pickerShow: function pickerShow() {
    this.setData({
      pickerHidden: false
    });
  },
  formSubmit: function formSubmit(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
  },
  formReset: function formReset(e) {
    console.log('form发生了reset事件，携带数据为：', e.detail.value);
    this.setData({
      chosen: ''
    });
  }
});
});require("page/component/pages/form/form.js")
var __wxRoute = "page/component/pages/input/input", __wxRouteBegin = true;
define("page/component/pages/input/input.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'input',
      path: 'page/component/pages/input/input'
    };
  },


  data: {
    focus: false,
    inputValue: ''
  },

  bindKeyInput: function bindKeyInput(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },
  bindReplaceInput: function bindReplaceInput(e) {
    var value = e.detail.value;
    var pos = e.detail.cursor;
    var left = void 0;
    if (pos !== -1) {
      // 光标在中间
      left = e.detail.value.slice(0, pos);
      // 计算光标的位置
      pos = left.replace(/11/g, '2').length;
    }

    // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos

      // 或者直接返回字符串,光标在最后边
      // return value.replace(/11/g,'2'),
    };
  },
  bindHideKeyboard: function bindHideKeyboard(e) {
    if (e.detail.value === '123') {
      // 收起键盘
      wx.hideKeyboard();
    }
  }
});
});require("page/component/pages/input/input.js")
var __wxRoute = "page/component/pages/label/label", __wxRouteBegin = true;
define("page/component/pages/label/label.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'label',
      path: 'page/component/pages/label/label'
    };
  },


  data: {
    checkboxItems: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }],
    radioItems: [{ name: 'USA', value: '美国' }, { name: 'CHN', value: '中国', checked: 'true' }],
    hidden: false
  },

  checkboxChange: function checkboxChange(e) {
    var checked = e.detail.value;
    var changed = {};
    for (var i = 0; i < this.data.checkboxItems.length; i++) {
      if (checked.indexOf(this.data.checkboxItems[i].name) !== -1) {
        changed['checkboxItems[' + i + '].checked'] = true;
      } else {
        changed['checkboxItems[' + i + '].checked'] = false;
      }
    }
    this.setData(changed);
  },
  radioChange: function radioChange(e) {
    var checked = e.detail.value;
    var changed = {};
    for (var i = 0; i < this.data.radioItems.length; i++) {
      if (checked.indexOf(this.data.radioItems[i].name) !== -1) {
        changed['radioItems[' + i + '].checked'] = true;
      } else {
        changed['radioItems[' + i + '].checked'] = false;
      }
    }
    this.setData(changed);
  },
  tapEvent: function tapEvent() {
    console.log('按钮被点击');
  }
});
});require("page/component/pages/label/label.js")
var __wxRoute = "page/component/pages/picker/picker", __wxRouteBegin = true;
define("page/component/pages/picker/picker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'picker',
      path: 'page/component/pages/picker/picker'
    };
  },


  data: {
    array: ['中国', '美国', '巴西', '日本'],
    index: 0,
    date: '2016-09-01',
    time: '12:01'
  },

  bindPickerChange: function bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      index: e.detail.value
    });
  },
  bindDateChange: function bindDateChange(e) {
    this.setData({
      date: e.detail.value
    });
  },
  bindTimeChange: function bindTimeChange(e) {
    this.setData({
      time: e.detail.value
    });
  }
});
});require("page/component/pages/picker/picker.js")
var __wxRoute = "page/component/pages/radio/radio", __wxRouteBegin = true;
define("page/component/pages/radio/radio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'radio',
      path: 'page/component/pages/radio/radio'
    };
  },


  data: {
    items: [{ value: 'USA', name: '美国' }, { value: 'CHN', name: '中国', checked: 'true' }, { value: 'BRA', name: '巴西' }, { value: 'JPN', name: '日本' }, { value: 'ENG', name: '英国' }, { value: 'FRA', name: '法国' }]
  },

  radioChange: function radioChange(e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value);

    var items = this.data.items;
    for (var i = 0, len = items.length; i < len; ++i) {
      items[i].checked = items[i].value === e.detail.value;
    }

    this.setData({
      items: items
    });
  }
});
});require("page/component/pages/radio/radio.js")
var __wxRoute = "page/component/pages/slider/slider", __wxRouteBegin = true;
define("page/component/pages/slider/slider.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var pageData = {
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'slider',
      path: 'page/component/pages/slider/slider'
    };
  }
};

for (var i = 1; i < 5; ++i) {
  (function (index) {
    pageData['slider' + index + 'change'] = function (e) {
      console.log('slider' + index + '发生change事件，携带值为', e.detail.value);
    };
  })(i);
}

Page(pageData);
});require("page/component/pages/slider/slider.js")
var __wxRoute = "page/component/pages/switch/switch", __wxRouteBegin = true;
define("page/component/pages/switch/switch.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'switch',
      path: 'page/component/pages/switch/switch'
    };
  },
  switch1Change: function switch1Change(e) {
    console.log('switch1 发生 change 事件，携带值为', e.detail.value);
  },
  switch2Change: function switch2Change(e) {
    console.log('switch2 发生 change 事件，携带值为', e.detail.value);
  }
});
});require("page/component/pages/switch/switch.js")
var __wxRoute = "page/component/pages/textarea/textarea", __wxRouteBegin = true;
define("page/component/pages/textarea/textarea.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'textarea',
      path: 'page/component/pages/textarea/textarea'
    };
  },


  data: {
    focus: false
  },

  bindTextAreaBlur: function bindTextAreaBlur(e) {
    console.log(e.detail.value);
  }
});
});require("page/component/pages/textarea/textarea.js")
var __wxRoute = "page/component/pages/navigator/navigator", __wxRouteBegin = true;
define("page/component/pages/navigator/navigator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'navigator',
      path: 'page/component/pages/navigator/navigator'
    };
  }
});
});require("page/component/pages/navigator/navigator.js")
var __wxRoute = "page/component/pages/navigator/navigate", __wxRouteBegin = true;
define("page/component/pages/navigator/navigate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'navigatePage',
      path: 'page/component/pages/navigator/navigate'
    };
  },
  onLoad: function onLoad(options) {
    console.log(options);
    this.setData({
      title: options.title
    });
  }
});
});require("page/component/pages/navigator/navigate.js")
var __wxRoute = "page/component/pages/navigator/redirect", __wxRouteBegin = true;
define("page/component/pages/navigator/redirect.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'redirectPage',
      path: 'page/component/pages/navigator/redirect'
    };
  },
  onLoad: function onLoad(options) {
    console.log(options);
    this.setData({
      title: options.title
    });
  }
});
});require("page/component/pages/navigator/redirect.js")
var __wxRoute = "page/component/pages/image/image", __wxRouteBegin = true;
define("page/component/pages/image/image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var config = require('../../../../config');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'image',
      path: 'page/component/pages/image/image'
    };
  },

  data: {
    imageUrl: config.downloadExampleUrl
  }
});
});require("page/component/pages/image/image.js")
var __wxRoute = "page/component/pages/audio/audio", __wxRouteBegin = true;
define("page/component/pages/audio/audio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'audio',
      path: 'page/component/pages/audio/audio'
    };
  },


  data: {
    current: {
      poster: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000',
      name: '此时此刻',
      author: '许巍',
      src: 'http://ws.stream.qqmusic.qq.com/M500001VfvsJ21xFqb.mp3?guid=ffffffff82def4af4b12b3cd9337d5e7&uin=346897220&vkey=6292F51E1E384E06DCBDC9AB7C49FD713D632D313AC4858BACB8DDD29067D3C601481D36E62053BF8DFEAF74C0A5CCFADD6471160CAF3E6A&fromtag=46'
    },
    audioAction: {
      method: 'pause'
    }
  }
});
});require("page/component/pages/audio/audio.js")
var __wxRoute = "page/component/pages/video/video", __wxRouteBegin = true;
define("page/component/pages/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function getRandomColor() {
  var rgb = [];
  for (var i = 0; i < 3; ++i) {
    var color = Math.floor(Math.random() * 256).toString(16);
    color = color.length === 1 ? '0' + color : color;
    rgb.push(color);
  }
  return '#' + rgb.join('');
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'video',
      path: 'page/component/pages/video/video'
    };
  },
  onReady: function onReady() {
    this.videoContext = wx.createVideoContext('myVideo');
  },


  inputValue: '',
  data: {
    src: '',
    danmuList: [{
      text: '第 1s 出现的弹幕',
      color: '#ff0000',
      time: 1
    }, {
      text: '第 3s 出现的弹幕',
      color: '#ff00ff',
      time: 3
    }]
  },

  bindInputBlur: function bindInputBlur(e) {
    this.inputValue = e.detail.value;
  },
  bindButtonTap: function bindButtonTap() {
    var that = this;
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: ['front', 'back'],
      success: function success(res) {
        that.setData({
          src: res.tempFilePath
        });
      }
    });
  },
  bindSendDanmu: function bindSendDanmu() {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
    });
  },
  videoErrorCallback: function videoErrorCallback(e) {
    console.log('视频错误信息:');
    console.log(e.detail.errMsg);
  }
});
});require("page/component/pages/video/video.js")
var __wxRoute = "page/component/pages/map/map", __wxRouteBegin = true;
define("page/component/pages/map/map.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'map',
      path: 'page/component/pages/map/map'
    };
  },


  data: {
    latitude: 23.099994,
    longitude: 113.324520,
    markers: [{
      latitude: 23.099994,
      longitude: 113.324520,
      name: 'T.I.T 创意园'
    }],
    covers: [{
      latitude: 23.099994,
      longitude: 113.344520,
      iconPath: '/image/location.png'
    }, {
      latitude: 23.099994,
      longitude: 113.304520,
      iconPath: '/image/location.png'
    }],
    polygons: [{
      points: [{
        latitude: 23.099994,
        longitude: 113.324520
      }, {
        latitude: 23.098994,
        longitude: 113.323520
      }, {
        latitude: 23.098994,
        longitude: 113.325520
      }],
      strokeWidth: 3,
      strokeColor: '#FFFFFFAA'
    }],
    subKey: 'B5QBZ-7JTLU-DSSVA-2BRJ3-TNXLF-2TBR7',
    enable3d: false,
    showCompass: false,
    enableOverlooking: false,
    enableZoom: true,
    enableScroll: true,
    enableRotate: false,
    drawPolygon: false,
    enableSatellite: false,
    enableTraffic: false
  },
  toggle3d: function toggle3d() {
    this.setData({
      enable3d: !this.data.enable3d
    });
  },
  toggleShowCompass: function toggleShowCompass() {
    this.setData({
      showCompass: !this.data.showCompass
    });
  },
  toggleOverlooking: function toggleOverlooking() {
    this.setData({
      enableOverlooking: !this.data.enableOverlooking
    });
  },
  toggleZoom: function toggleZoom() {
    this.setData({
      enableZoom: !this.data.enableZoom
    });
  },
  toggleScroll: function toggleScroll() {
    this.setData({
      enableScroll: !this.data.enableScroll
    });
  },
  toggleRotate: function toggleRotate() {
    this.setData({
      enableRotate: !this.data.enableRotate
    });
  },
  togglePolygon: function togglePolygon() {
    this.setData({
      drawPolygon: !this.data.drawPolygon
    });
  },
  toggleSatellite: function toggleSatellite() {
    this.setData({
      enableSatellite: !this.data.enableSatellite
    });
  },
  toggleTraffic: function toggleTraffic() {
    this.setData({
      enableTraffic: !this.data.enableTraffic
    });
  }
});
});require("page/component/pages/map/map.js")
var __wxRoute = "page/component/pages/canvas/canvas", __wxRouteBegin = true;
define("page/component/pages/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'canvas',
      path: 'page/component/pages/canvas/canvas'
    };
  },
  onReady: function onReady() {
    this.position = {
      x: 150,
      y: 150,
      vx: 2,
      vy: 2
    };

    this.drawBall();
    this.interval = setInterval(this.drawBall, 17);
  },
  drawBall: function drawBall() {
    var p = this.position;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    var context = wx.createCanvasContext('canvas');

    function ball(x, y) {
      context.beginPath(0);
      context.arc(x, y, 5, 0, Math.PI * 2);
      context.setFillStyle('#1aad19');
      context.setStrokeStyle('rgba(1,1,1,0)');
      context.fill();
      context.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);

    context.draw();
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
  }
});
});require("page/component/pages/canvas/canvas.js")
var __wxRoute = "page/component/pages/ad/ad", __wxRouteBegin = true;
define("page/component/pages/ad/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var info = wx.getSystemInfoSync();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'ad',
      path: 'page/component/pages/ad/ad'
    };
  },


  data: {
    platform: info.platform
  }
});
});require("page/component/pages/ad/ad.js")
var __wxRoute = "page/component/pages/movable-view/movable-view", __wxRouteBegin = true;
define("page/component/pages/movable-view/movable-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'movable-view',
      path: 'page/component/pages/movable-view/movable-view'
    };
  },


  data: {
    x: 0,
    y: 0,
    scale: 2
  },

  tap: function tap() {
    this.setData({
      x: 30,
      y: 30
    });
  },
  tap2: function tap2() {
    this.setData({
      scale: 3
    });
  },
  onChange: function onChange(e) {
    console.log(e.detail);
  },
  onScale: function onScale(e) {
    console.log(e.detail);
  }
});
});require("page/component/pages/movable-view/movable-view.js")
var __wxRoute = "page/component/pages/cover-view/cover-view", __wxRouteBegin = true;
define("page/component/pages/cover-view/cover-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'cover-view',
      path: 'page/component/pages/cover-view/cover-view'
    };
  },


  data: {
    latitude: 23.099994,
    longitude: 113.324520
  }
});
});require("page/component/pages/cover-view/cover-view.js")
var __wxRoute = "page/component/pages/rich-text/rich-text", __wxRouteBegin = true;
define("page/component/pages/rich-text/rich-text.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var htmlSnip = '<div class="div_class">\n  <h1>Title</h1>\n  <p class="p">\n    Life is&nbsp;<i>like</i>&nbsp;a box of\n    <b>&nbsp;chocolates</b>.\n  </p>\n</div>\n';

var nodeSnip = 'Page({\n  data: {\n    nodes: [{\n      name: \'div\',\n      attrs: {\n        class: \'div_class\',\n        style: \'line-height: 60px; color: red;\'\n      },\n      children: [{\n        type: \'text\',\n        text: \'You never know what you\'re gonna get.\'\n      }]\n    }]\n  }\n})\n';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'rich-text',
      path: 'page/component/pages/rich-text/rich-text'
    };
  },


  data: {
    htmlSnip: htmlSnip,
    nodeSnip: nodeSnip,
    renderedByHtml: false,
    renderedByNode: false,
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: #1AAD19;'
      },
      children: [{
        type: 'text',
        text: 'You never know what you\'re gonna get.'
      }]
    }]
  },
  renderHtml: function renderHtml() {
    this.setData({
      renderedByHtml: true
    });
  },
  renderNode: function renderNode() {
    this.setData({
      renderedByNode: true
    });
  },
  enterCode: function enterCode(e) {
    console.log(e.detail.value);
    this.setData({
      htmlSnip: e.detail.value
    });
  }
});
});require("page/component/pages/rich-text/rich-text.js")
var __wxRoute = "page/API/index", __wxRouteBegin = true;
define("page/API/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序接口能力展示',
      path: 'page/API/index'
    };
  },


  data: {
    list: [{
      id: 'api',
      name: '开放接口',
      open: false,
      pages: [{
        zh: '微信登录',
        url: 'login/login'
      }, {
        zh: '获取用户信息',
        url: 'get-user-info/get-user-info'
      }, {
        zh: '发起支付',
        url: 'request-payment/request-payment'
      }, {
        zh: '转发',
        url: 'share/share'
      }, {
        zh: '转发按钮',
        url: 'share-button/share-button'
      }, {
        zh: '客服消息',
        url: 'custom-message/custom-message'
      }, {
        zh: '模板消息',
        url: 'template-message/template-message'
      }, {
        zh: '收货地址',
        url: 'choose-address/choose-address'
      }, {
        zh: '获取发票抬头',
        url: 'choose-invoice-title/choose-invoice-title'
      }, {
        zh: '生物认证',
        url: 'soter-authentication/soter-authentication'
      }, {
        zh: '设置',
        url: 'setting/setting'
      }]
    }, {
      id: 'page',
      name: '界面',
      open: false,
      pages: [{
        zh: '设置界面标题',
        url: 'set-navigation-bar-title/set-navigation-bar-title'
      }, {
        zh: '标题栏加载动画',
        url: 'navigation-bar-loading/navigation-bar-loading'
      }, {
        zh: '设置TabBar',
        url: '@set-tab-bar'
      }, {
        zh: '页面跳转',
        url: 'navigator/navigator'
      }, {
        zh: '下拉刷新',
        url: 'pull-down-refresh/pull-down-refresh'
      }, {
        zh: '创建动画',
        url: 'animation/animation'
      }, {
        zh: '创建绘画',
        url: 'canvas/canvas'
      }, {
        zh: '显示操作菜单',
        url: 'action-sheet/action-sheet'
      }, {
        zh: '显示模态弹窗',
        url: 'modal/modal'
      }, {
        zh: '页面滚动',
        url: 'page-scroll/page-scroll'
      }, {
        zh: '显示消息提示框',
        url: 'toast/toast'
      }, {
        zh: '获取WXML节点信息',
        url: 'get-wxml-node-info/get-wxml-node-info'
      }, {
        zh: 'WXML节点布局相交状态',
        url: 'intersection-observer/intersection-observer'
      }]
    }, {
      id: 'device',
      name: '设备',
      open: false,
      pages: [{
        zh: '获取手机网络状态',
        url: 'get-network-type/get-network-type'
      }, {
        zh: '监听手机网络变化',
        url: 'on-network-status-change/on-network-status-change'
      }, {
        zh: '获取手机系统信息',
        url: 'get-system-info/get-system-info'
      }, {
        zh: '监听重力感应数据',
        url: 'on-accelerometer-change/on-accelerometer-change'
      }, {
        zh: '监听罗盘数据',
        url: 'on-compass-change/on-compass-change'
      }, {
        zh: '打电话',
        url: 'make-phone-call/make-phone-call'
      }, {
        zh: '扫码',
        url: 'scan-code/scan-code'
      }, {
        zh: '剪切板',
        url: 'clipboard-data/clipboard-data'
      }, {
        zh: '蓝牙',
        url: 'bluetooth/bluetooth'
      }, {
        zh: 'iBeacon',
        url: 'ibeacon/ibeacon'
      }, {
        zh: '屏幕亮度',
        url: 'screen-brightness/screen-brightness'
      }, {
        zh: '用户截屏事件',
        url: 'capture-screen/capture-screen'
      }, {
        zh: '振动',
        url: 'vibrate/vibrate'
      }, {
        zh: '手机联系人',
        url: 'add-contact/add-contact'
      }, {
        zh: 'Wi-Fi',
        url: 'wifi/wifi'
      }]
    }, {
      id: 'network',
      name: '网络',
      open: false,
      pages: [{
        zh: '发起一个请求',
        url: 'request/request'
      }, {
        zh: 'WebSocket',
        url: 'web-socket/web-socket'
      }, {
        zh: '上传文件',
        url: 'upload-file/upload-file'
      }, {
        zh: '下载文件',
        url: 'download-file/download-file'
      }]
    }, {
      id: 'media',
      name: '媒体',
      open: false,
      pages: [{
        zh: '图片',
        url: 'image/image'
      }, {
        zh: '录音',
        url: 'voice/voice'
      }, {
        zh: '背景音频',
        url: 'background-audio/background-audio'
      }, {
        zh: '文件',
        url: 'file/file'
      }, {
        zh: '视频',
        url: 'video/video'
      }, {
        zh: '动态加载字体',
        url: 'load-font-face/load-font-face'
      }]
    }, {
      id: 'location',
      name: '位置',
      open: false,
      pages: [{
        zh: '获取当前位置',
        url: 'get-location/get-location'
      }, {
        zh: '使用原生地图查看位置',
        url: 'open-location/open-location'
      }, {
        zh: '使用原生地图选择位置',
        url: 'choose-location/choose-location'
      }]
    }, {
      id: 'storage',
      name: '数据',
      url: 'storage/storage'
    }, {
      id: 'worker',
      name: '多线程',
      url: 'worker/worker'
    }],
    isSetTabBarPage: false
  },
  onShow: function onShow() {
    this.leaveSetTabBarPage();
  },
  onHide: function onHide() {
    this.leaveSetTabBarPage();
  },
  kindToggle: function kindToggle(e) {
    var id = e.currentTarget.id;var list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id === id) {
        if (list[i].url) {
          wx.navigateTo({
            url: 'pages/' + list[i].url
          });
          return;
        }
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
  },
  enterSetTabBarPage: function enterSetTabBarPage() {
    this.setData({
      isSetTabBarPage: true
    });
  },
  leaveSetTabBarPage: function leaveSetTabBarPage() {
    this.setData({
      isSetTabBarPage: false
    });
  }
});
});require("page/API/index.js")
var __wxRoute = "page/API/pages/login/login", __wxRouteBegin = true;
define("page/API/pages/login/login.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '微信登录',
      path: 'page/API/pages/login/login'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      hasLogin: app.globalData.hasLogin
    });
  },

  data: {},
  login: function login() {
    var that = this;
    wx.login({
      success: function success() {
        app.globalData.hasLogin = true;
        that.setData({
          hasLogin: true
        });
      }
    });
  }
});
});require("page/API/pages/login/login.js")
var __wxRoute = "page/API/pages/get-user-info/get-user-info", __wxRouteBegin = true;
define("page/API/pages/get-user-info/get-user-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取用户信息',
      path: 'page/API/pages/get-user-info/get-user-info'
    };
  },


  data: {
    hasUserInfo: false
  },
  getUserInfo: function getUserInfo(info) {
    var userInfo = info.detail.userInfo;
    this.setData({
      userInfo: userInfo,
      hasUserInfo: true
    });
  },
  clear: function clear() {
    this.setData({
      hasUserInfo: false,
      userInfo: {}
    });
  }
});
});require("page/API/pages/get-user-info/get-user-info.js")
var __wxRoute = "page/API/pages/request-payment/request-payment", __wxRouteBegin = true;
define("page/API/pages/request-payment/request-payment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var paymentUrl = require('../../../../config').paymentUrl;

var app = getApp();

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '发起支付',
      path: 'page/API/pages/request-payment/request-payment'
    };
  },
  onLoad: function onLoad() {},
  requestPayment: function requestPayment() {
    var self = this;

    self.setData({
      loading: true
    });

    // 此处需要先调用wx.login方法获取code，然后在服务端调用微信接口使用code换取下单用户的openId
    // 具体文档参考https://mp.weixin.qq.com/debug/wxadoc/dev/api/api-login.html?t=20161230#wxloginobject
    app.getUserOpenId(function (err, openid) {
      if (!err) {
        wx.request({
          url: paymentUrl,
          data: {
            openid: openid
          },
          method: 'POST',
          success: function success(res) {
            console.log('unified order success, response is:', res);
            var payargs = res.data.payargs;
            wx.requestPayment({
              timeStamp: payargs.timeStamp,
              nonceStr: payargs.nonceStr,
              package: payargs.package,
              signType: payargs.signType,
              paySign: payargs.paySign
            });

            self.setData({
              loading: false
            });
          }
        });
      } else {
        console.log('err:', err);
        self.setData({
          loading: false
        });
      }
    });
  }
});
});require("page/API/pages/request-payment/request-payment.js")
var __wxRoute = "page/API/pages/share/share", __wxRouteBegin = true;
define("page/API/pages/share/share.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  data: {
    shareData: {
      title: '自定义转发标题',
      desc: '自定义转发描述',
      path: '/page/API/pages/share/share'
    }
  },

  onShareAppMessage: function onShareAppMessage() {
    return this.data.shareData;
  }
});
});require("page/API/pages/share/share.js")
var __wxRoute = "page/API/pages/share-button/share-button", __wxRouteBegin = true;
define("page/API/pages/share-button/share-button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '转发按钮',
      path: 'page/API/pages/share-button/share-button'
    };
  },
  handleTapShareButton: function handleTapShareButton() {
    if (!(typeof wx.canIUse === 'function' && wx.canIUse('button.open-type.share'))) {
      wx.showModal({
        title: '当前版本不支持转发按钮',
        content: '请升级至最新版本微信客户端',
        showCancel: false
      });
    }
  }
});
});require("page/API/pages/share-button/share-button.js")
var __wxRoute = "page/API/pages/custom-message/custom-message", __wxRouteBegin = true;
define("page/API/pages/custom-message/custom-message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '客服消息',
      path: 'page/API/pages/custom-message/custom-message'
    };
  }
});
});require("page/API/pages/custom-message/custom-message.js")
var __wxRoute = "page/API/pages/template-message/template-message", __wxRouteBegin = true;
define("page/API/pages/template-message/template-message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var templateMessageUrl = require('../../../../config').templateMessageUrl;

var app = getApp();

var formData = {
  address: 'T.I.T 造舰厂',
  time: '2017.01.09',
  name: '帝国歼星舰',
  serial: '123456789'
};

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '模板消息',
      path: 'page/API/pages/template-message/template-message'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      formData: formData
    });
  },
  submitForm: function submitForm(e) {
    var self = this;
    var formId = e.detail.formId;

    var formData = e.detail.value;

    console.log('form_id is:', formId);

    self.setData({
      loading: true
    });

    app.getUserOpenId(function (err, openid) {
      if (!err) {
        wx.request({
          url: templateMessageUrl,
          method: 'POST',
          data: {
            form_id: formId,
            openid: openid,
            formData: formData
          },
          success: function success(res) {
            console.log('submit form success', res);
            wx.showToast({
              title: '发送成功',
              icon: 'success'
            });
            self.setData({
              loading: false
            });
          },
          fail: function fail(_ref) {
            var errMsg = _ref.errMsg;

            console.log('submit form fail, errMsg is:', errMsg);
          }
        });
      } else {
        console.log('err:', err);
      }
    });
  }
});
});require("page/API/pages/template-message/template-message.js")
var __wxRoute = "page/API/pages/set-navigation-bar-title/set-navigation-bar-title", __wxRouteBegin = true;
define("page/API/pages/set-navigation-bar-title/set-navigation-bar-title.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '设置页面标题',
      path: 'page/API/pages/set-navigation-bar-title/set-navigation-bar-title'
    };
  },
  setNaivgationBarTitle: function setNaivgationBarTitle(e) {
    var title = e.detail.value.title;
    console.log(title);
    wx.setNavigationBarTitle({
      title: title,
      success: function success() {
        console.log('setNavigationBarTitle success');
      },
      fail: function fail(err) {
        console.log('setNavigationBarTitle fail, err is', err);
      }
    });

    return false;
  }
});
});require("page/API/pages/set-navigation-bar-title/set-navigation-bar-title.js")
var __wxRoute = "page/API/pages/navigation-bar-loading/navigation-bar-loading", __wxRouteBegin = true;
define("page/API/pages/navigation-bar-loading/navigation-bar-loading.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '标题栏加载动画',
      path: 'page/API/pages/navigation-bar-loading/navigation-bar-loading'
    };
  },
  showNavigationBarLoading: function showNavigationBarLoading() {
    wx.showNavigationBarLoading();
  },
  hideNavigationBarLoading: function hideNavigationBarLoading() {
    wx.hideNavigationBarLoading();
  }
});
});require("page/API/pages/navigation-bar-loading/navigation-bar-loading.js")
var __wxRoute = "page/API/pages/navigator/navigator", __wxRouteBegin = true;
define("page/API/pages/navigator/navigator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '页面跳转',
      path: 'page/API/pages/navigator/navigator'
    };
  },
  navigateTo: function navigateTo() {
    wx.navigateTo({ url: './navigator' });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  redirectTo: function redirectTo() {
    wx.redirectTo({ url: './navigator' });
  },
  switchTab: function switchTab() {
    wx.switchTab({ url: '/page/component/index' });
  },
  reLaunch: function reLaunch() {
    wx.reLaunch({ url: '/page/component/index' });
  }
});
});require("page/API/pages/navigator/navigator.js")
var __wxRoute = "page/API/pages/pull-down-refresh/pull-down-refresh", __wxRouteBegin = true;
define("page/API/pages/pull-down-refresh/pull-down-refresh.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '下拉刷新',
      path: 'page/API/pages/pull-down-refresh/pull-down-refresh'
    };
  },
  onPullDownRefresh: function onPullDownRefresh() {
    wx.showToast({
      title: 'loading...',
      icon: 'loading'
    });
    console.log('onPullDownRefresh', new Date());
  },
  stopPullDownRefresh: function stopPullDownRefresh() {
    wx.stopPullDownRefresh({
      complete: function complete(res) {
        wx.hideToast();
        console.log(res, new Date());
      }
    });
  }
});
});require("page/API/pages/pull-down-refresh/pull-down-refresh.js")
var __wxRoute = "page/API/pages/animation/animation", __wxRouteBegin = true;
define("page/API/pages/animation/animation.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '动画',
      path: 'page/API/pages/animation/animation'
    };
  },
  onReady: function onReady() {
    this.animation = wx.createAnimation();
  },
  rotate: function rotate() {
    this.animation.rotate(Math.random() * 720 - 360).step();
    this.setData({ animation: this.animation.export() });
  },
  scale: function scale() {
    this.animation.scale(Math.random() * 2).step();
    this.setData({ animation: this.animation.export() });
  },
  translate: function translate() {
    this.animation.translate(Math.random() * 100 - 50, Math.random() * 100 - 50).step();
    this.setData({ animation: this.animation.export() });
  },
  skew: function skew() {
    this.animation.skew(Math.random() * 90, Math.random() * 90).step();
    this.setData({ animation: this.animation.export() });
  },
  rotateAndScale: function rotateAndScale() {
    this.animation.rotate(Math.random() * 720 - 360).scale(Math.random() * 2).step();
    this.setData({ animation: this.animation.export() });
  },
  rotateThenScale: function rotateThenScale() {
    this.animation.rotate(Math.random() * 720 - 360).step().scale(Math.random() * 2).step();
    this.setData({ animation: this.animation.export() });
  },
  all: function all() {
    this.animation.rotate(Math.random() * 720 - 360).scale(Math.random() * 2).translate(Math.random() * 100 - 50, Math.random() * 100 - 50).skew(Math.random() * 90, Math.random() * 90).step();
    this.setData({ animation: this.animation.export() });
  },
  allInQueue: function allInQueue() {
    this.animation.rotate(Math.random() * 720 - 360).step().scale(Math.random() * 2).step().translate(Math.random() * 100 - 50, Math.random() * 100 - 50).step().skew(Math.random() * 90, Math.random() * 90).step();
    this.setData({ animation: this.animation.export() });
  },
  reset: function reset() {
    this.animation.rotate(0, 0).scale(1).translate(0, 0).skew(0, 0).step({ duration: 0 });
    this.setData({ animation: this.animation.export() });
  }
});
});require("page/API/pages/animation/animation.js")
var __wxRoute = "page/API/pages/action-sheet/action-sheet", __wxRouteBegin = true;
define("page/API/pages/action-sheet/action-sheet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '操作菜单',
      path: 'page/API/pages/action-sheet/action-sheet'
    };
  },
  actionSheetTap: function actionSheetTap() {
    wx.showActionSheet({
      itemList: ['item1', 'item2', 'item3', 'item4'],
      success: function success(e) {
        console.log(e.tapIndex);
      }
    });
  }
});
});require("page/API/pages/action-sheet/action-sheet.js")
var __wxRoute = "page/API/pages/modal/modal", __wxRouteBegin = true;
define("page/API/pages/modal/modal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '模态弹窗',
      path: 'page/API/pages/modal/modal'
    };
  },


  data: {
    modalHidden: true,
    modalHidden2: true
  },
  modalTap: function modalTap() {
    wx.showModal({
      title: '弹窗标题',
      content: '弹窗内容，告知当前状态、信息和解决方法，描述文字尽量控制在三行内',
      showCancel: false,
      confirmText: '确定'
    });
  },
  noTitlemodalTap: function noTitlemodalTap() {
    wx.showModal({
      content: '弹窗内容，告知当前状态、信息和解决方法，描述文字尽量控制在三行内',
      confirmText: '确定',
      cancelText: '取消'
    });
  }
});
});require("page/API/pages/modal/modal.js")
var __wxRoute = "page/API/pages/toast/toast", __wxRouteBegin = true;
define("page/API/pages/toast/toast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '消息提示框',
      path: 'page/API/pages/toast/toast'
    };
  },
  toast1Tap: function toast1Tap() {
    wx.showToast({
      title: '默认'
    });
  },
  toast2Tap: function toast2Tap() {
    wx.showToast({
      title: 'duration 3000',
      duration: 3000
    });
  },
  toast3Tap: function toast3Tap() {
    wx.showToast({
      title: 'loading',
      icon: 'loading',
      duration: 5000
    });
  },
  hideToast: function hideToast() {
    wx.hideToast();
  }
});
});require("page/API/pages/toast/toast.js")
var __wxRoute = "page/API/pages/get-network-type/get-network-type", __wxRouteBegin = true;
define("page/API/pages/get-network-type/get-network-type.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取手机网络状态',
      path: 'page/API/pages/get-network-type/get-network-type'
    };
  },


  data: {
    hasNetworkType: false
  },
  getNetworkType: function getNetworkType() {
    var that = this;
    wx.getNetworkType({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasNetworkType: true,
          networkType: res.subtype || res.networkType
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasNetworkType: false,
      networkType: ''
    });
  }
});
});require("page/API/pages/get-network-type/get-network-type.js")
var __wxRoute = "page/API/pages/on-network-status-change/on-network-status-change", __wxRouteBegin = true;
define("page/API/pages/on-network-status-change/on-network-status-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听手机网络变化',
      path: 'page/API/pages/on-network-status-change/on-network-status-change'
    };
  },


  data: {
    isConnected: false
  },
  onLoad: function onLoad() {
    var that = this;
    wx.onNetworkStatusChange(function (res) {
      that.setData({
        isConnected: res.isConnected,
        networkType: res.networkType
      });
    });
  },
  onShow: function onShow() {
    var that = this;
    wx.getNetworkType({
      success: function success(res) {
        that.setData({
          isConnected: res.networkType !== 'none',
          networkType: res.networkType
        });
      }
    });
  }
});
});require("page/API/pages/on-network-status-change/on-network-status-change.js")
var __wxRoute = "page/API/pages/get-system-info/get-system-info", __wxRouteBegin = true;
define("page/API/pages/get-system-info/get-system-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取手机系统信息',
      path: 'page/API/pages/get-system-info/get-system-info'
    };
  },


  data: {
    systemInfo: {}
  },
  getSystemInfo: function getSystemInfo() {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          systemInfo: res
        });
      }
    });
  }
});
});require("page/API/pages/get-system-info/get-system-info.js")
var __wxRoute = "page/API/pages/on-compass-change/on-compass-change", __wxRouteBegin = true;
define("page/API/pages/on-compass-change/on-compass-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听罗盘数据',
      path: 'page/API/pages/on-compass-change/on-compass-change'
    };
  },


  data: {
    enabled: true,
    direction: 0
  },
  onReady: function onReady() {
    var that = this;
    wx.onCompassChange(function (res) {
      that.setData({
        direction: parseInt(res.direction, 10)
      });
    });
  },
  startCompass: function startCompass() {
    if (this.data.enabled) {
      return;
    }
    var that = this;
    wx.startCompass({
      success: function success() {
        that.setData({
          enabled: true
        });
      }
    });
  },
  stopCompass: function stopCompass() {
    if (!this.data.enabled) {
      return;
    }
    var that = this;
    wx.stopCompass({
      success: function success() {
        that.setData({
          enabled: false
        });
      }
    });
  }
});
});require("page/API/pages/on-compass-change/on-compass-change.js")
var __wxRoute = "page/API/pages/make-phone-call/make-phone-call", __wxRouteBegin = true;
define("page/API/pages/make-phone-call/make-phone-call.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '打电话',
      path: 'page/API/pages/make-phone-call/make-phone-call'
    };
  },


  data: {
    disabled: true
  },
  bindInput: function bindInput(e) {
    this.inputValue = e.detail.value;

    if (this.inputValue.length > 0) {
      this.setData({
        disabled: false
      });
    } else {
      this.setData({
        disabled: true
      });
    }
  },
  makePhoneCall: function makePhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.inputValue,
      success: function success() {
        console.log('成功拨打电话');
      }
    });
  }
});
});require("page/API/pages/make-phone-call/make-phone-call.js")
var __wxRoute = "page/API/pages/scan-code/scan-code", __wxRouteBegin = true;
define("page/API/pages/scan-code/scan-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '扫码',
      path: 'page/API/pages/scan-code/scan-code'
    };
  },


  data: {
    result: ''
  },

  scanCode: function scanCode() {
    var that = this;
    wx.scanCode({
      success: function success(res) {
        that.setData({
          result: res.result
        });
      },
      fail: function fail() {}
    });
  }
});
});require("page/API/pages/scan-code/scan-code.js")
var __wxRoute = "page/API/pages/request/request", __wxRouteBegin = true;
define("page/API/pages/request/request.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var requestUrl = require('../../../../config').requestUrl;

var duration = 2000;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '网络请求',
      path: 'page/API/pages/request/request'
    };
  },
  makeRequest: function makeRequest() {
    var self = this;

    self.setData({
      loading: true
    });

    wx.request({
      url: requestUrl,
      data: {
        noncestr: Date.now()
      },
      success: function success(result) {
        wx.showToast({
          title: '请求成功',
          icon: 'success',
          mask: true,
          duration: duration
        });
        self.setData({
          loading: false
        });
        console.log('request success', result);
      },
      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        console.log('request fail', errMsg);
        self.setData({
          loading: false
        });
      }
    });
  }
});
});require("page/API/pages/request/request.js")
var __wxRoute = "page/API/pages/web-socket/web-socket", __wxRouteBegin = true;
define("page/API/pages/web-socket/web-socket.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function showModal(title, content) {
  wx.showModal({
    title: title,
    content: content,
    showCancel: false
  });
}

function showSuccess(title) {
  wx.showToast({
    title: title,
    icon: 'success',
    duration: 1000
  });
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'Web Socket',
      path: 'page/API/pages/web-socket/web-socket'
    };
  },


  data: {
    socketStatus: 'closed'
  },

  onLoad: function onLoad() {
    var self = this;
    self.setData({
      hasLogin: true
    });
    // qcloud.setLoginUrl(loginUrl)

    // qcloud.login({
    //   success: function(result) {
    //     console.log('登录成功', result)
    //     self.setData({
    //       hasLogin: true
    //     })
    //   },

    //   fail: function(error) {
    //     console.log('登录失败', error)
    //   }
    // })
  },
  onUnload: function onUnload() {
    this.closeSocket();
  },
  toggleSocket: function toggleSocket(e) {
    var turnedOn = e.detail.value;

    if (turnedOn && this.data.socketStatus === 'closed') {
      this.openSocket();
    } else if (!turnedOn && this.data.socketStatus === 'connected') {
      var _showSuccess = true;
      this.closeSocket(_showSuccess);
    }
  },
  openSocket: function openSocket() {
    var _this = this;

    // var socket = this.socket = new qcloud.Tunnel(tunnelUrl)

    wx.onSocketOpen(function () {
      console.log('WebSocket 已连接');
      showSuccess('Socket已连接');
      _this.setData({
        socketStatus: 'connected',
        waitingResponse: false
      });
    });

    wx.onSocketClose(function () {
      console.log('WebSocket 已断开');
      _this.setData({ socketStatus: 'closed' });
    });

    wx.onSocketError(function (error) {
      showModal('发生错误', JSON.stringify(error));
      console.error('socket error:', error);
      _this.setData({
        loading: false
      });
    });

    // 监听服务器推送消息
    wx.onSocketMessage(function (message) {
      showSuccess('收到信道消息');
      console.log('socket message:', message);
      _this.setData({
        loading: false
      });
    });

    // 打开信道
    wx.connectSocket({
      url: 'wss://echo.websocket.org'
    });
  },
  closeSocket: function closeSocket() {
    var _this2 = this;

    if (this.data.socketStatus === 'connected') {
      wx.closeSocket({
        success: function success() {
          showSuccess('Socket已断开');
          _this2.setData({ socketStatus: 'closed' });
        }
      });
    }
  },
  sendMessage: function sendMessage() {
    if (this.data.socketStatus === 'connected') {
      wx.sendSocketMessage({
        data: 'Hello, Miniprogram!'
      });
    }
  }
});
});require("page/API/pages/web-socket/web-socket.js")
var __wxRoute = "page/API/pages/upload-file/upload-file", __wxRouteBegin = true;
define("page/API/pages/upload-file/upload-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var uploadFileUrl = require('../../../../config').uploadFileUrl;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '上传文件',
      path: 'page/API/pages/upload-file/upload-file'
    };
  },
  chooseImage: function chooseImage() {
    var self = this;

    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success: function success(res) {
        console.log('chooseImage success, temp path is', res.tempFilePaths[0]);

        var imageSrc = res.tempFilePaths[0];

        wx.uploadFile({
          url: uploadFileUrl,
          filePath: imageSrc,
          name: 'data',
          success: function success(res) {
            console.log('uploadImage success, res is:', res);

            wx.showToast({
              title: '上传成功',
              icon: 'success',
              duration: 1000
            });

            self.setData({
              imageSrc: imageSrc
            });
          },
          fail: function fail(_ref) {
            var errMsg = _ref.errMsg;

            console.log('uploadImage fail, errMsg is', errMsg);
          }
        });
      },
      fail: function fail(_ref2) {
        var errMsg = _ref2.errMsg;

        console.log('chooseImage fail, err is', errMsg);
      }
    });
  }
});
});require("page/API/pages/upload-file/upload-file.js")
var __wxRoute = "page/API/pages/download-file/download-file", __wxRouteBegin = true;
define("page/API/pages/download-file/download-file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var downloadExampleUrl = require('../../../../config').downloadExampleUrl;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '下载文件',
      path: 'page/API/pages/download-file/download-file'
    };
  },
  downloadImage: function downloadImage() {
    var self = this;

    wx.downloadFile({
      url: downloadExampleUrl,
      success: function success(res) {
        console.log('downloadFile success, res is', res);

        self.setData({
          imageSrc: res.tempFilePath
        });
      },
      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        console.log('downloadFile fail, err is:', errMsg);
      }
    });
  }
});
});require("page/API/pages/download-file/download-file.js")
var __wxRoute = "page/API/pages/image/image", __wxRouteBegin = true;
define("page/API/pages/image/image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sourceType = [['camera'], ['album'], ['camera', 'album']];
var sizeType = [['compressed'], ['original'], ['compressed', 'original']];

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '图片',
      path: 'page/API/pages/image/image'
    };
  },


  data: {
    imageList: [],
    sourceTypeIndex: 2,
    sourceType: ['拍照', '相册', '拍照或相册'],

    sizeTypeIndex: 2,
    sizeType: ['压缩', '原图', '压缩或原图'],

    countIndex: 8,
    count: [1, 2, 3, 4, 5, 6, 7, 8, 9]
  },
  sourceTypeChange: function sourceTypeChange(e) {
    this.setData({
      sourceTypeIndex: e.detail.value
    });
  },
  sizeTypeChange: function sizeTypeChange(e) {
    this.setData({
      sizeTypeIndex: e.detail.value
    });
  },
  countChange: function countChange(e) {
    this.setData({
      countIndex: e.detail.value
    });
  },
  chooseImage: function chooseImage() {
    var that = this;
    wx.chooseImage({
      sourceType: sourceType[this.data.sourceTypeIndex],
      sizeType: sizeType[this.data.sizeTypeIndex],
      count: this.data.count[this.data.countIndex],
      success: function success(res) {
        console.log(res);
        that.setData({
          imageList: res.tempFilePaths
        });
      }
    });
  },
  previewImage: function previewImage(e) {
    var current = e.target.dataset.src;

    wx.previewImage({
      current: current,
      urls: this.data.imageList
    });
  }
});
});require("page/API/pages/image/image.js")
var __wxRoute = "page/API/pages/voice/voice", __wxRouteBegin = true;
define("page/API/pages/voice/voice.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../../util/util.js');

var playTimeInterval = void 0;
var recordTimeInterval = void 0;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '录音',
      path: 'page/API/pages/voice/voice'
    };
  },


  data: {
    recording: false,
    playing: false,
    hasRecord: false,
    recordTime: 0,
    playTime: 0,
    formatedRecordTime: '00:00:00',
    formatedPlayTime: '00:00:00'
  },

  onHide: function onHide() {
    if (this.data.playing) {
      this.stopVoice();
    } else if (this.data.recording) {
      this.stopRecordUnexpectedly();
    }
  },
  startRecord: function startRecord() {
    this.setData({ recording: true });

    var that = this;
    recordTimeInterval = setInterval(function () {
      var recordTime = that.data.recordTime += 1;
      that.setData({
        formatedRecordTime: util.formatTime(that.data.recordTime),
        recordTime: recordTime
      });
    }, 1000);

    wx.startRecord({
      success: function success(res) {
        that.setData({
          hasRecord: true,
          tempFilePath: res.tempFilePath,
          formatedPlayTime: util.formatTime(that.data.playTime)
        });
      },
      complete: function complete() {
        that.setData({ recording: false });
        clearInterval(recordTimeInterval);
      }
    });
  },
  stopRecord: function stopRecord() {
    wx.stopRecord();
  },
  stopRecordUnexpectedly: function stopRecordUnexpectedly() {
    var that = this;
    wx.stopRecord({
      success: function success() {
        console.log('stop record success');
        clearInterval(recordTimeInterval);
        that.setData({
          recording: false,
          hasRecord: false,
          recordTime: 0,
          formatedRecordTime: util.formatTime(0)
        });
      }
    });
  },
  playVoice: function playVoice() {
    var that = this;
    playTimeInterval = setInterval(function () {
      var playTime = that.data.playTime + 1;
      console.log('update playTime', playTime);
      that.setData({
        playing: true,
        formatedPlayTime: util.formatTime(playTime),
        playTime: playTime
      });
    }, 1000);
    wx.playVoice({
      filePath: this.data.tempFilePath,
      success: function success() {
        clearInterval(playTimeInterval);
        var playTime = 0;
        console.log('play voice finished');
        that.setData({
          playing: false,
          formatedPlayTime: util.formatTime(playTime),
          playTime: playTime
        });
      }
    });
  },
  pauseVoice: function pauseVoice() {
    clearInterval(playTimeInterval);
    wx.pauseVoice();
    this.setData({
      playing: false
    });
  },
  stopVoice: function stopVoice() {
    clearInterval(playTimeInterval);
    this.setData({
      playing: false,
      formatedPlayTime: util.formatTime(0),
      playTime: 0
    });
    wx.stopVoice();
  },
  clear: function clear() {
    clearInterval(playTimeInterval);
    wx.stopVoice();
    this.setData({
      playing: false,
      hasRecord: false,
      tempFilePath: '',
      formatedRecordTime: util.formatTime(0),
      recordTime: 0,
      playTime: 0
    });
  }
});
});require("page/API/pages/voice/voice.js")
var __wxRoute = "page/API/pages/file/file", __wxRouteBegin = true;
define("page/API/pages/file/file.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '文件',
      path: 'page/API/pages/file/file'
    };
  },
  onLoad: function onLoad() {
    this.setData({
      savedFilePath: wx.getStorageSync('savedFilePath')
    });
  },

  data: {
    tempFilePath: '',
    savedFilePath: '',
    dialog: {
      hidden: true
    }
  },
  chooseImage: function chooseImage() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function success(res) {
        that.setData({
          tempFilePath: res.tempFilePaths[0]
        });
      }
    });
  },
  saveFile: function saveFile() {
    if (this.data.tempFilePath.length > 0) {
      var that = this;
      wx.saveFile({
        tempFilePath: this.data.tempFilePath,
        success: function success(res) {
          that.setData({
            savedFilePath: res.savedFilePath
          });
          wx.setStorageSync('savedFilePath', res.savedFilePath);
          that.setData({
            dialog: {
              title: '保存成功',
              content: '下次进入应用时，此文件仍可用',
              hidden: false
            }
          });
        },
        fail: function fail() {
          that.setData({
            dialog: {
              title: '保存失败',
              content: '应该是有 bug 吧',
              hidden: false
            }
          });
        }
      });
    }
  },
  clear: function clear() {
    wx.setStorageSync('savedFilePath', '');
    this.setData({
      tempFilePath: '',
      savedFilePath: ''
    });
  },
  confirm: function confirm() {
    this.setData({
      'dialog.hidden': true
    });
  }
});
});require("page/API/pages/file/file.js")
var __wxRoute = "page/API/pages/on-accelerometer-change/on-accelerometer-change", __wxRouteBegin = true;
define("page/API/pages/on-accelerometer-change/on-accelerometer-change.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '监听重力感应数据',
      path: 'page/API/pages/on-accelerometer-change/on-accelerometer-change'
    };
  },


  data: {
    x: 0,
    y: 0,
    z: 0,
    enabled: true
  },
  onReady: function onReady() {
    this.drawBigBall();
    var that = this;

    this.position = {
      x: 151,
      y: 151,
      vx: 0,
      vy: 0,
      ax: 0,
      ay: 0
    };
    wx.onAccelerometerChange(function (res) {
      that.setData({
        x: res.x.toFixed(2),
        y: res.y.toFixed(2),
        z: res.z.toFixed(2)
      });
      that.position.ax = Math.sin(res.x * Math.PI / 2);
      that.position.ay = -Math.sin(res.y * Math.PI / 2);
      // that.drawSmallBall()
    });

    this.interval = setInterval(function () {
      that.drawSmallBall();
    }, 17);
  },
  drawBigBall: function drawBigBall() {
    var context = wx.createContext();
    context.beginPath(0);
    context.arc(151, 151, 140, 0, Math.PI * 2);
    context.setFillStyle('#ffffff');
    context.setStrokeStyle('#aaaaaa');
    context.fill();
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'big-ball',
      actions: context.getActions()
    });
  },
  drawSmallBall: function drawSmallBall() {
    var p = this.position;
    var strokeStyle = 'rgba(1,1,1,0)';

    p.x += p.vx;
    p.y += p.vy;
    p.vx += p.ax;
    p.vy += p.ay;

    // eslint-disable-next-line
    if (Math.sqrt(Math.pow(Math.abs(p.x) - 151, 2) + Math.pow(Math.abs(p.y) - 151, 2)) >= 115) {
      if (p.x > 151 && p.vx > 0) {
        p.vx = 0;
      }
      if (p.x < 151 && p.vx < 0) {
        p.vx = 0;
      }
      if (p.y > 151 && p.vy > 0) {
        p.vy = 0;
      }
      if (p.y < 151 && p.vy < 0) {
        p.vy = 0;
      }
      strokeStyle = '#ff0000';
    }

    var context = wx.createContext();
    context.beginPath(0);
    context.arc(p.x, p.y, 15, 0, Math.PI * 2);
    context.setFillStyle('#1aad19');
    context.setStrokeStyle(strokeStyle);
    context.fill();
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'small-ball',
      actions: context.getActions()
    });
  },
  startAccelerometer: function startAccelerometer() {
    if (this.data.enabled) {
      return;
    }
    var that = this;
    wx.startAccelerometer({
      success: function success() {
        that.setData({
          enabled: true
        });
      }
    });
  },
  stopAccelerometer: function stopAccelerometer() {
    if (!this.data.enabled) {
      return;
    }
    var that = this;
    wx.stopAccelerometer({
      success: function success() {
        that.setData({
          enabled: false
        });
      }
    });
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
  }
});
});require("page/API/pages/on-accelerometer-change/on-accelerometer-change.js")
var __wxRoute = "page/API/pages/canvas/canvas", __wxRouteBegin = true;
define("page/API/pages/canvas/canvas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var example = require('./example.js');

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '创建画布',
      path: 'page/API/pages/canvas/canvas'
    };
  },
  onLoad: function onLoad() {
    this.context = wx.createContext();

    var methods = Object.keys(example);
    this.setData({
      methods: methods
    });

    var that = this;
    methods.forEach(function (method) {
      that[method] = function () {
        example[method](that.context);
        var actions = that.context.getActions();

        wx.drawCanvas({
          canvasId: 'canvas',
          actions: actions
        });
      };
    });
  },
  toTempFilePath: function toTempFilePath() {
    wx.canvasToTempFilePath({
      canvasId: 'canvas',
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(res) {
        console.log(res);
      }
    });
  }
});
});require("page/API/pages/canvas/canvas.js")
var __wxRoute = "page/API/pages/background-audio/background-audio", __wxRouteBegin = true;
define("page/API/pages/background-audio/background-audio.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../../../util/util.js');

var dataUrl = 'http://ws.stream.qqmusic.qq.com/M500001VfvsJ21xFqb.mp3?guid=ffffffff82def4af4b12b3cd9337d5e7&uin=346897220&vkey=6292F51E1E384E061FF02C31F716658E5C81F5594D561F2E88B854E81CAAB7806D5E4F103E55D33C16F3FAC506D1AB172DE8600B37E43FAD&fromtag=46';
Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '背景音乐',
      path: 'page/API/pages/background-audio/background-audio'
    };
  },
  onLoad: function onLoad() {
    this._enableInterval();

    if (app.globalData.backgroundAudioPlaying) {
      this.setData({
        playing: true
      });
    }
  },

  data: {
    playing: false,
    playTime: 0,
    formatedPlayTime: '00:00:00'
  },
  play: function play() {
    var that = this;
    wx.playBackgroundAudio({
      dataUrl: dataUrl,
      title: '此时此刻',
      coverImgUrl: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000',
      complete: function complete() {
        that.setData({
          playing: true
        });
      }
    });
    this._enableInterval();
    app.globalData.backgroundAudioPlaying = true;
  },
  seek: function seek(e) {
    clearInterval(this.updateInterval);
    var that = this;
    wx.seekBackgroundAudio({
      position: e.detail.value,
      complete: function complete() {
        // 实际会延迟两秒左右才跳过去
        setTimeout(function () {
          that._enableInterval();
        }, 2000);
      }
    });
  },
  pause: function pause() {
    var that = this;
    wx.pauseBackgroundAudio({
      dataUrl: dataUrl,
      success: function success() {
        that.setData({
          playing: false
        });
      }
    });
    app.globalData.backgroundAudioPlaying = false;
  },
  stop: function stop() {
    var that = this;
    wx.stopBackgroundAudio({
      dataUrl: dataUrl,
      success: function success() {
        that.setData({
          playing: false,
          playTime: 0,
          formatedPlayTime: util.formatTime(0)
        });
      }
    });
    app.globalData.backgroundAudioPlaying = false;
  },
  _enableInterval: function _enableInterval() {
    var that = this;
    function update() {
      wx.getBackgroundAudioPlayerState({
        success: function success(res) {
          that.setData({
            playTime: res.currentPosition,
            formatedPlayTime: util.formatTime(res.currentPosition + 1)
          });
        }
      });
    }

    update();
    this.updateInterval = setInterval(update, 500);
  },
  onUnload: function onUnload() {
    clearInterval(this.updateInterval);
  }
});
});require("page/API/pages/background-audio/background-audio.js")
var __wxRoute = "page/API/pages/video/video", __wxRouteBegin = true;
define("page/API/pages/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sourceType = [['camera'], ['album'], ['camera', 'album']];
var camera = [['front'], ['back'], ['front', 'back']];

// eslint-disable-next-line
var duration = Array.apply(null, { length: 60 }).map(function (n, i) {
  return i + 1;
});

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '拍摄/选择视频',
      path: 'page/API/pages/video/video'
    };
  },


  data: {
    sourceTypeIndex: 2,
    sourceType: ['拍摄', '相册', '拍摄或相册'],

    cameraIndex: 2,
    camera: ['前置', '后置', '前置或后置'],

    durationIndex: 59,
    duration: duration.map(function (t) {
      return t + '秒';
    }),

    src: ''
  },
  sourceTypeChange: function sourceTypeChange(e) {
    this.setData({
      sourceTypeIndex: e.detail.value
    });
  },
  cameraChange: function cameraChange(e) {
    this.setData({
      cameraIndex: e.detail.value
    });
  },
  durationChange: function durationChange(e) {
    this.setData({
      durationIndex: e.detail.value
    });
  },
  chooseVideo: function chooseVideo() {
    var that = this;
    wx.chooseVideo({
      sourceType: sourceType[this.data.sourceTypeIndex],
      camera: camera[this.data.cameraIndex],
      maxDuration: duration[this.data.durationIndex],
      success: function success(res) {
        that.setData({
          src: res.tempFilePath
        });
      }
    });
  }
});
});require("page/API/pages/video/video.js")
var __wxRoute = "page/API/pages/get-location/get-location", __wxRouteBegin = true;
define("page/API/pages/get-location/get-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../../util/util.js');

var formatLocation = util.formatLocation;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取位置',
      path: 'page/API/pages/get-location/get-location'
    };
  },


  data: {
    hasLocation: false
  },
  getLocation: function getLocation() {
    var that = this;
    wx.getLocation({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasLocation: true,
          location: formatLocation(res.longitude, res.latitude)
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasLocation: false
    });
  }
});
});require("page/API/pages/get-location/get-location.js")
var __wxRoute = "page/API/pages/open-location/open-location", __wxRouteBegin = true;
define("page/API/pages/open-location/open-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '查看位置',
      path: 'page/API/pages/open-location/open-location'
    };
  },
  openLocation: function openLocation(e) {
    console.log(e);
    var value = e.detail.value;
    console.log(value);
    wx.openLocation({
      longitude: Number(value.longitude),
      latitude: Number(value.latitude),
      name: value.name,
      address: value.address
    });
  }
});
});require("page/API/pages/open-location/open-location.js")
var __wxRoute = "page/API/pages/choose-location/choose-location", __wxRouteBegin = true;
define("page/API/pages/choose-location/choose-location.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../../util/util.js');

var formatLocation = util.formatLocation;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '使用原生地图选择位置',
      path: 'page/API/pages/choose-location/choose-location'
    };
  },


  data: {
    hasLocation: false
  },
  chooseLocation: function chooseLocation() {
    var that = this;
    wx.chooseLocation({
      success: function success(res) {
        console.log(res);
        that.setData({
          hasLocation: true,
          location: formatLocation(res.longitude, res.latitude),
          locationAddress: res.address
        });
      }
    });
  },
  clear: function clear() {
    this.setData({
      hasLocation: false
    });
  }
});
});require("page/API/pages/choose-location/choose-location.js")
var __wxRoute = "page/API/pages/storage/storage", __wxRouteBegin = true;
define("page/API/pages/storage/storage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '数据存储',
      path: 'page/API/pages/storage/storage'
    };
  },


  data: {
    key: '',
    data: '',
    dialog: {
      title: '',
      content: '',
      hidden: true
    }
  },

  keyChange: function keyChange(e) {
    this.data.key = e.detail.value;
  },
  dataChange: function dataChange(e) {
    this.data.data = e.detail.value;
  },
  getStorage: function getStorage() {
    var _data = this.data,
        key = _data.key,
        data = _data.data;

    var storageData = void 0;

    if (key.length === 0) {
      this.setData({
        key: key,
        data: data,
        'dialog.hidden': false,
        'dialog.title': '读取数据失败',
        'dialog.content': 'key 不能为空'
      });
    } else {
      storageData = wx.getStorageSync(key);
      if (storageData === '') {
        this.setData({
          key: key,
          data: data,
          'dialog.hidden': false,
          'dialog.title': '读取数据失败',
          'dialog.content': '找不到 key 对应的数据'
        });
      } else {
        this.setData({
          key: key,
          data: data,
          'dialog.hidden': false,
          'dialog.title': '读取数据成功',
          // eslint-disable-next-line
          'dialog.content': "data: '" + storageData + "'"
        });
      }
    }
  },
  setStorage: function setStorage() {
    var _data2 = this.data,
        key = _data2.key,
        data = _data2.data;

    if (key.length === 0) {
      this.setData({
        key: key,
        data: data,
        'dialog.hidden': false,
        'dialog.title': '保存数据失败',
        'dialog.content': 'key 不能为空'
      });
    } else {
      wx.setStorageSync(key, data);
      this.setData({
        key: key,
        data: data,
        'dialog.hidden': false,
        'dialog.title': '存储数据成功'
      });
    }
  },
  clearStorage: function clearStorage() {
    wx.clearStorageSync();
    this.setData({
      key: '',
      data: '',
      'dialog.hidden': false,
      'dialog.title': '清除数据成功',
      'dialog.content': ''
    });
  },
  confirm: function confirm() {
    this.setData({
      'dialog.hidden': true,
      'dialog.title': '',
      'dialog.content': ''
    });
  }
});
});require("page/API/pages/storage/storage.js")
var __wxRoute = "page/component/pages/picker-view/picker-view", __wxRouteBegin = true;
define("page/component/pages/picker-view/picker-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var date = new Date();
var years = [];
var months = [];
var days = [];

for (var i = 1990; i <= date.getFullYear(); i++) {
  years.push(i);
}

for (var _i = 1; _i <= 12; _i++) {
  months.push(_i);
}

for (var _i2 = 1; _i2 <= 31; _i2++) {
  days.push(_i2);
}

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'picker-view',
      path: 'page/component/pages/picker-view/picker-view'
    };
  },


  data: {
    years: years,
    year: date.getFullYear(),
    months: months,
    month: 2,
    days: days,
    day: 2,
    value: [9999, 1, 1],
    isDaytime: true
  },

  bindChange: function bindChange(e) {
    var val = e.detail.value;
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]],
      isDaytime: !val[3]
    });
  }
});
});require("page/component/pages/picker-view/picker-view.js")
var __wxRoute = "page/component/pages/camera/camera", __wxRouteBegin = true;
define("page/component/pages/camera/camera.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera/camera'
    };
  },


  data: {
    src: '',
    videoSrc: '',
    position: 'back',
    mode: 'scanCode',
    result: {}
  },
  onLoad: function onLoad() {
    this.ctx = wx.createCameraContext();
  },
  takePhoto: function takePhoto() {
    var _this = this;

    this.ctx.takePhoto({
      quality: 'high',
      success: function success(res) {
        _this.setData({
          src: res.tempImagePath
        });
      }
    });
  },
  startRecord: function startRecord() {
    this.ctx.startRecord({
      success: function success() {
        console.log('startRecord');
      }
    });
  },
  stopRecord: function stopRecord() {
    var _this2 = this;

    this.ctx.stopRecord({
      success: function success(res) {
        _this2.setData({
          src: res.tempThumbPath,
          videoSrc: res.tempVideoPath
        });
      }
    });
  },
  togglePosition: function togglePosition() {
    this.setData({
      position: this.data.position === 'front' ? 'back' : 'front'
    });
  },
  error: function error(e) {
    console.log(e.detail);
  }
});
});require("page/component/pages/camera/camera.js")
var __wxRoute = "page/component/pages/camera-scan-code/camera-scan-code", __wxRouteBegin = true;
define("page/component/pages/camera-scan-code/camera-scan-code.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'camera',
      path: 'page/component/pages/camera-scan-code/camera-scan-code'
    };
  },


  data: {
    result: {}
  },
  onReady: function onReady() {
    wx.showModal({
      title: '提示',
      content: '将摄像头对准一维码即可扫描',
      showCancel: false
    });
  },
  scanCode: function scanCode(e) {
    console.log('scanCode:', e);
    this.setData({
      result: e.detail
    });
  },
  navigateBack: function navigateBack() {
    wx.navigateBack();
  },
  error: function error(e) {
    console.log(e.detail);
  }
});
});require("page/component/pages/camera-scan-code/camera-scan-code.js")
var __wxRoute = "page/API/pages/get-wxml-node-info/get-wxml-node-info", __wxRouteBegin = true;
define("page/API/pages/get-wxml-node-info/get-wxml-node-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取WXML节点信息',
      path: 'page/API/pages/get-wxml-node-info/get-wxml-node-info'
    };
  },


  data: {
    metrics: []
  },

  onReady: function onReady() {
    this.getNodeInfo();
  },
  getNodeInfo: function getNodeInfo() {
    var _this = this;

    var $ = wx.createSelectorQuery();
    var target = $.select('.target');
    target.boundingClientRect();

    $.exec(function (res) {
      var rect = res[0];
      if (rect) {
        var metrics = [];
        // eslint-disable-next-line
        for (var key in rect) {
          if (key !== 'id' && key !== 'dataset') {
            var val = rect[key];
            metrics.push({ key: key, val: val });
          }
        }

        _this.setData({ metrics: metrics });
      }
    });
  }
});
});require("page/API/pages/get-wxml-node-info/get-wxml-node-info.js")
var __wxRoute = "page/component/pages/open-data/open-data", __wxRouteBegin = true;
define("page/component/pages/open-data/open-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'open-data',
      path: 'page/component/pages/open-data/open-data'
    };
  }
});
});require("page/component/pages/open-data/open-data.js")
var __wxRoute = "page/component/pages/web-view/web-view", __wxRouteBegin = true;
define("page/component/pages/web-view/web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'webview',
      path: 'page/component/pages/web-view/web-view'
    };
  }
});
});require("page/component/pages/web-view/web-view.js")
var __wxRoute = "page/API/pages/load-font-face/load-font-face", __wxRouteBegin = true;
define("page/API/pages/load-font-face/load-font-face.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '动态加载字体',
      path: 'page/API/pages/load-font-face/load-font-face'
    };
  },


  data: {
    fontFamily: 'Bitstream Vera Serif Bold',
    loaded: false
  },

  onLoad: function onLoad() {
    this.setData({
      loaded: false
    });
  },
  loadFontFace: function loadFontFace() {
    var self = this;
    wx.loadFontFace({
      family: this.data.fontFamily,
      source: 'url("https://sungd.github.io/Pacifico.ttf")',
      success: function success(res) {
        console.log(res.status);
        self.setData({ loaded: true });
      },
      fail: function fail(res) {
        console.log(res.status);
      },
      complete: function complete(res) {
        console.log(res.status);
      }
    });
  },
  clear: function clear() {
    this.setData({ loaded: false });
  }
});
});require("page/API/pages/load-font-face/load-font-face.js")
var __wxRoute = "page/API/pages/clipboard-data/clipboard-data", __wxRouteBegin = true;
define("page/API/pages/clipboard-data/clipboard-data.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '剪切板',
      path: 'page/API/pages/clipboard-data/clipboard-data'
    };
  },


  data: {
    value: 'edit and copy me',
    pasted: ''
  },

  valueChanged: function valueChanged(e) {
    this.setData({
      value: e.detail.value
    });
  },
  copy: function copy() {
    wx.setClipboardData({
      data: this.data.value,
      success: function success() {
        wx.showToast({
          title: '复制成功',
          icon: 'success',
          duration: 1000
        });
      }
    });
  },
  paste: function paste() {
    var self = this;
    wx.getClipboardData({
      success: function success(res) {
        self.setData({
          pasted: res.data
        });
        wx.showToast({
          title: '粘贴成功',
          icon: 'success',
          duration: 1000
        });
      }
    });
  }
});
});require("page/API/pages/clipboard-data/clipboard-data.js")
var __wxRoute = "page/API/pages/screen-brightness/screen-brightness", __wxRouteBegin = true;
define("page/API/pages/screen-brightness/screen-brightness.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '屏幕亮度',
      path: 'page/API/pages/screen-brightness/screen-brightness'
    };
  },


  data: {
    screenBrightness: 0
  },

  onLoad: function onLoad() {
    this._updateScreenBrightness();
  },
  changeBrightness: function changeBrightness(e) {
    var _this = this;

    var value = Number.parseFloat(e.detail.value.toFixed(1));
    wx.setScreenBrightness({
      value: value,
      success: function success() {
        _this._updateScreenBrightness();
      }
    });
  },
  _updateScreenBrightness: function _updateScreenBrightness() {
    var _this2 = this;

    wx.getScreenBrightness({
      success: function success(res) {
        _this2.setData({
          screenBrightness: Number.parseFloat(res.value.toFixed(1))
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});require("page/API/pages/screen-brightness/screen-brightness.js")
var __wxRoute = "page/API/pages/vibrate/vibrate", __wxRouteBegin = true;
define("page/API/pages/vibrate/vibrate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '振动',
      path: 'page/API/pages/vibrate/vibrate'
    };
  },
  vibrateShort: function vibrateShort() {
    wx.vibrateShort({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      },
      complete: function complete() {
        console.log('completed');
      }
    });
  },
  vibrateLong: function vibrateLong() {
    wx.vibrateLong({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      },
      complete: function complete() {
        console.log('completed');
      }
    });
  }
});
});require("page/API/pages/vibrate/vibrate.js")
var __wxRoute = "page/API/pages/add-contact/add-contact", __wxRouteBegin = true;
define("page/API/pages/add-contact/add-contact.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '新增联系人',
      path: 'page/API/pages/add-contact/add-contact'
    };
  },
  submit: function submit(e) {
    var formData = e.detail.value;
    wx.addPhoneContact(_extends({}, formData, {
      success: function success() {
        wx.showToast({
          title: '联系人创建成功'
        });
      },
      fail: function fail() {
        wx.showToast({
          title: '联系人创建失败'
        });
      }
    }));
  }
});
});require("page/API/pages/add-contact/add-contact.js")
var __wxRoute = "page/API/pages/wifi/wifi", __wxRouteBegin = true;
define("page/API/pages/wifi/wifi.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'Wi-Fi',
      path: 'page/API/pages/wifi/wifi'
    };
  },


  data: {
    wifiList: []
  },

  onUnload: function onUnload() {
    this.stopSearch();
  },
  startSearch: function startSearch() {
    var _this = this;

    var getWifiList = function getWifiList() {
      wx.getWifiList({
        success: function success() {
          wx.onGetWifiList(function (res) {
            var wifiList = res.wifiList.sort(function (a, b) {
              return b.signalStrength - a.signalStrength;
            }).map(function (wifi) {
              var strength = Math.ceil(wifi.signalStrength * 4);
              return Object.assign(wifi, { strength: strength });
            });
            _this.setData({
              wifiList: wifiList
            });
          });
        },
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    var startWifi = function startWifi() {
      wx.startWifi({
        success: getWifiList,
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    wx.getSystemInfo({
      success: function success(res) {
        var isIOS = res.platform === 'ios';
        if (isIOS) {
          wx.showModal({
            title: '提示',
            content: '由于系统限制，iOS用户请手动进入系统WiFi页面，然后返回小程序。',
            showCancel: false,
            success: function success() {
              startWifi();
            }
          });
          return;
        }
        startWifi();
      }
    });
  },
  stopSearch: function stopSearch() {
    wx.stopWifi({
      success: function success(res) {
        console.log(res);
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});require("page/API/pages/wifi/wifi.js")
var __wxRoute = "page/API/pages/page-scroll/page-scroll", __wxRouteBegin = true;
define("page/API/pages/page-scroll/page-scroll.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '页面滚动',
      path: 'page/API/pages/page-scroll/page-scroll'
    };
  },
  scrollToTop: function scrollToTop() {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300
    });
  },
  scrollToBottom: function scrollToBottom() {
    wx.pageScrollTo({
      scrollTop: 3000,
      duration: 300
    });
  }
});
});require("page/API/pages/page-scroll/page-scroll.js")
var __wxRoute = "page/API/pages/intersection-observer/intersection-observer", __wxRouteBegin = true;
define("page/API/pages/intersection-observer/intersection-observer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'WXML节点布局相交状态',
      path: 'page/API/pages/intersection-observer/intersection-observer'
    };
  },


  data: {
    appear: false
  },
  onLoad: function onLoad() {
    var _this = this;

    this._observer = wx.createIntersectionObserver(this);
    this._observer.relativeTo('.scroll-view').observe('.ball', function (res) {
      console.log(res);
      _this.setData({
        appear: res.intersectionRatio > 0
      });
    });
  },
  onUnload: function onUnload() {
    if (this._observer) this._observer.disconnect();
  }
});
});require("page/API/pages/intersection-observer/intersection-observer.js")
var __wxRoute = "page/API/pages/capture-screen/capture-screen", __wxRouteBegin = true;
define("page/API/pages/capture-screen/capture-screen.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '用户截屏事件',
      path: 'page/API/pages/capture-screen/capture-screen'
    };
  },


  data: {
    captured: false
  },
  onLoad: function onLoad() {
    var _this = this;

    wx.onUserCaptureScreen(function () {
      _this.setData({
        captured: true
      });
    });
  }
});
});require("page/API/pages/capture-screen/capture-screen.js")
var __wxRoute = "page/API/pages/worker/worker", __wxRouteBegin = true;
define("page/API/pages/worker/worker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _require = require('../../../../util/util.js'),
    fib = _require.fib;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '多线程Worker',
      path: 'page/API/pages/worker/worker'
    };
  },


  data: {
    res: '',
    input: 35
  },

  onLoad: function onLoad() {
    this._worker = wx.createWorker('workers/fib/index.js');
  },
  onUnload: function onUnload() {
    clearInterval(this.interval);
    if (this._worker) this._worker.terminate();
  },
  bindInput: function bindInput(e) {
    var val = Number(e.detail.value);
    if (val > 40) return { value: 40 };
    if (Number.isNaN(val)) return { value: 33 };
    this.setData({
      input: val
    });
    return undefined;
  },
  reset: function reset() {
    this.setData({ res: '' });
  },
  compute: function compute() {
    this.reset();
    wx.showLoading({
      title: '计算中...'
    });
    var t0 = +Date.now();
    var res = fib(this.data.input);
    var t1 = +Date.now();
    wx.hideLoading();
    this.setData({
      res: res,
      time: t1 - t0
    });
  },
  multiThreadCompute: function multiThreadCompute() {
    var _this = this;

    this.reset();
    wx.showLoading({
      title: '计算中...'
    });

    var t0 = +Date.now();
    this._worker.postMessage({
      type: 'execFunc_fib',
      params: [this.data.input]
    });
    this._worker.onMessage(function (res) {
      if (res.type === 'execFunc_fib') {
        wx.hideLoading();
        var t1 = +Date.now();
        _this.setData({
          res: res.result,
          time: t1 - t0
        });
      }
    });
  },
  onReady: function onReady() {
    this.position = {
      x: 150,
      y: 150,
      vx: 2,
      vy: 2
    };

    this.drawBall();
    this.interval = setInterval(this.drawBall, 17);
  },
  drawBall: function drawBall() {
    var p = this.position;
    p.x += p.vx;
    p.y += p.vy;
    if (p.x >= 300) {
      p.vx = -2;
    }
    if (p.x <= 7) {
      p.vx = 2;
    }
    if (p.y >= 300) {
      p.vy = -2;
    }
    if (p.y <= 7) {
      p.vy = 2;
    }

    var context = wx.createContext();

    function ball(x, y) {
      context.beginPath(0);
      context.arc(x, y, 5, 0, Math.PI * 2);
      context.setFillStyle('#1aad19');
      context.setStrokeStyle('rgba(1,1,1,0)');
      context.fill();
      context.stroke();
    }

    ball(p.x, 150);
    ball(150, p.y);
    ball(300 - p.x, 150);
    ball(150, 300 - p.y);
    ball(p.x, p.y);
    ball(300 - p.x, 300 - p.y);
    ball(p.x, 300 - p.y);
    ball(300 - p.x, p.y);

    wx.drawCanvas({
      canvasId: 'canvas',
      actions: context.getActions()
    });
  }
});
});require("page/API/pages/worker/worker.js")
var __wxRoute = "page/API/pages/ibeacon/ibeacon", __wxRouteBegin = true;
define("page/API/pages/ibeacon/ibeacon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'iBeacon',
      path: 'page/API/pages/ibeacon/ibeacon'
    };
  },


  data: {
    uuid: '',
    beacons: []
  },

  onUnload: function onUnload() {
    this.stopSearch();
  },
  enterUuid: function enterUuid(e) {
    this.setData({
      uuid: e.detail.value
    });
  },
  startSearch: function startSearch() {
    var _this = this;

    if (this._searching) return;
    this._searching = true;
    wx.startBeaconDiscovery({
      uuids: [this.data.uuid],
      success: function success(res) {
        console.log(res);
        wx.onBeaconUpdate(function (_ref) {
          var beacons = _ref.beacons;

          _this.setData({
            beacons: beacons
          });
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  },
  stopSearch: function stopSearch() {
    this._searching = false;
    wx.stopBeaconDiscovery();
  }
});
});require("page/API/pages/ibeacon/ibeacon.js")
var __wxRoute = "page/API/pages/choose-address/choose-address", __wxRouteBegin = true;
define("page/API/pages/choose-address/choose-address.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '收货地址',
      path: 'page/API/pages/choose-address/choose-address'
    };
  },


  data: {
    addressInfo: null
  },
  chooseAddress: function chooseAddress() {
    var _this = this;

    wx.chooseAddress({
      success: function success(res) {
        _this.setData({
          addressInfo: res
        });
      },
      fail: function fail(err) {
        console.log(err);
      }
    });
  }
});
});require("page/API/pages/choose-address/choose-address.js")
var __wxRoute = "page/API/pages/setting/setting", __wxRouteBegin = true;
define("page/API/pages/setting/setting.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '设置',
      path: 'page/API/pages/setting/setting'
    };
  },


  data: {
    setting: {}
  },

  getSetting: function getSetting() {
    var _this = this;

    wx.getSetting({
      success: function success(res) {
        console.log(res);
        _this.setData({ setting: res.authSetting });
      }
    });
  }
});
});require("page/API/pages/setting/setting.js")
var __wxRoute = "page/API/pages/choose-invoice-title/choose-invoice-title", __wxRouteBegin = true;
define("page/API/pages/choose-invoice-title/choose-invoice-title.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '获取发票抬头',
      path: 'page/API/pages/choose-invoice-title/choose-invoice-title'
    };
  },


  data: {
    type: '',
    title: '',
    taxNumber: '',
    companyAddress: '',
    telephone: '',
    bankName: '',
    bankAccount: ''
  },
  chooseInvoiceTitle: function chooseInvoiceTitle() {
    var _this = this;

    wx.chooseInvoiceTitle({
      success: function success(res) {
        _this.setData({
          type: res.type,
          title: res.title,
          taxNumber: res.taxNumber,
          companyAddress: res.companyAddress,
          telephone: res.telephone,
          bankName: res.bankName,
          bankAccount: res.bankAccount
        });
      },
      fail: function fail(err) {
        console.error(err);
      }
    });
  }
});
});require("page/API/pages/choose-invoice-title/choose-invoice-title.js")
var __wxRoute = "page/API/pages/soter-authentication/soter-authentication", __wxRouteBegin = true;
define("page/API/pages/soter-authentication/soter-authentication.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var AUTH_MODE = 'fingerPrint';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '生物认证',
      path: 'page/API/pages/soter-authentication/soter-authentication'
    };
  },
  startAuth: function startAuth() {
    var startSoterAuthentication = function startSoterAuthentication() {
      wx.startSoterAuthentication({
        requestAuthModes: [AUTH_MODE],
        challenge: 'test',
        authContent: '小程序示例',
        success: function success() {
          wx.showToast({
            title: '认证成功'
          });
        },
        fail: function fail(err) {
          console.error(err);
          wx.showModal({
            title: '失败',
            content: '认证失败',
            showCancel: false
          });
        }
      });
    };

    var checkIsEnrolled = function checkIsEnrolled() {
      wx.checkIsSoterEnrolledInDevice({
        checkAuthMode: AUTH_MODE,
        success: function success(res) {
          console.log(res);
          if (parseInt(res.isEnrolled, 10) <= 0) {
            wx.showModal({
              title: '错误',
              content: '您暂未录入指纹信息，请录入后重试',
              showCancel: false
            });
            return;
          }
          startSoterAuthentication();
        },
        fail: function fail(err) {
          console.error(err);
        }
      });
    };

    var notSupported = function notSupported() {
      wx.showModal({
        title: '错误',
        content: '您的设备不支持指纹识别',
        showCancel: false
      });
    };

    wx.checkIsSupportSoterAuthentication({
      success: function success(res) {
        console.log(res);
        if (!res || res.supportMode.length === 0 || res.supportMode.indexOf('fingerPrint') < 0) {
          notSupported();
          return;
        }
        checkIsEnrolled();
      },
      fail: function fail(err) {
        console.error(err);
        notSupported();
      }
    });
  }
});
});require("page/API/pages/soter-authentication/soter-authentication.js")
var __wxRoute = "page/component/pages/map-styles/map-styles", __wxRouteBegin = true;
define("page/component/pages/map-styles/map-styles.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'map底图样式',
      path: 'page/component/pages/map-styles/map-styles'
    };
  }
});
});require("page/component/pages/map-styles/map-styles.js")
var __wxRoute = "page/component/pages/doc-web-view/doc-web-view", __wxRouteBegin = true;
define("page/component/pages/doc-web-view/doc-web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序组件文档',
      path: 'page/component/pages/doc-web-view/doc-web-view'
    };
  }
});
});require("page/component/pages/doc-web-view/doc-web-view.js")
var __wxRoute = "page/API/pages/doc-web-view/doc-web-view", __wxRouteBegin = true;
define("page/API/pages/doc-web-view/doc-web-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: '小程序接口文档',
      path: 'page/API/pages/doc-web-view/doc-web-view'
    };
  }
});
});require("page/API/pages/doc-web-view/doc-web-view.js")
var __wxRoute = "page/component/pages/editor/editor", __wxRouteBegin = true;
define("page/component/pages/editor/editor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var util = require('../../../../util/util.js');

var compareVersion = util.compareVersion;

Page({
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: 'editor',
      path: 'page/component/pages/editor/editor'
    };
  },


  data: {
    formats: {},
    bottom: 0,
    readOnly: false,
    placeholder: '开始输入...'
  },
  readOnlyChange: function readOnlyChange() {
    this.setData({
      readOnly: !this.data.readOnly
    });
  },
  onLoad: function onLoad() {
    this.canUse = true;
    wx.loadFontFace({
      family: 'Pacifico',
      source: 'url("https://sungd.github.io/Pacifico.ttf")',
      success: console.log
    });

    var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
        SDKVersion = _wx$getSystemInfoSync.SDKVersion;

    if (compareVersion(SDKVersion, '2.7.0') >= 0) {
      //
    } else {
      this.canUse = false;
      // 如果希望用户在最新版本的客户端上体验您的小程序，可以这样子提示
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      });
    }
  },
  onEditorReady: function onEditorReady() {
    var that = this;
    wx.createSelectorQuery().select('#editor').context(function (res) {
      that.editorCtx = res.context;
    }).exec();
  },
  undo: function undo() {
    this.editorCtx.undo();
  },
  redo: function redo() {
    this.editorCtx.redo();
  },
  format: function format(e) {
    if (!this.canUse) return;
    var _e$target$dataset = e.target.dataset,
        name = _e$target$dataset.name,
        value = _e$target$dataset.value;

    if (!name) return;
    // console.log('format', name, value)
    this.editorCtx.format(name, value);
  },
  onStatusChange: function onStatusChange(e) {
    var formats = e.detail;
    this.setData({ formats: formats });
  },
  insertDivider: function insertDivider() {
    this.editorCtx.insertDivider({
      success: function success() {
        console.log('insert divider success');
      }
    });
  },
  clear: function clear() {
    this.editorCtx.clear({
      success: function success() {
        console.log('clear success');
      }
    });
  },
  removeFormat: function removeFormat() {
    this.editorCtx.removeFormat();
  },
  insertDate: function insertDate() {
    var date = new Date();
    var formatDate = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
    this.editorCtx.insertText({
      text: formatDate
    });
  },
  insertImage: function insertImage() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function success() {
        that.editorCtx.insertImage({
          src: 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1543767268337&di=5a3bbfaeb30149b2afd33a3c7aaa4ead&imgtype=0&src=http%3A%2F%2Fimg02.tooopen.com%2Fimages%2F20151031%2Ftooopen_sy_147004931368.jpg',
          data: {
            id: 'abcd',
            role: 'god'
          },
          success: function success() {
            console.log('insert image success');
          }
        });
      }
    });
  }
});
});require("page/component/pages/editor/editor.js")