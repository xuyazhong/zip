define("common/manifest.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

/******/(function (modules) {
  // webpackBootstrap
  /******/ // install a JSONP callback for chunk loading
  /******/var parentJsonpFunctionName = "webpackJsonpMpvue";
  /******/var parentJsonpFunction = global[parentJsonpFunctionName];
  /******/var parentJsonpFunctionIsInit = parentJsonpFunctionName + "IsInit";
  /******/if (global[parentJsonpFunctionIsInit]) return;
  /******/global[parentJsonpFunctionIsInit] = true;
  /******/global[parentJsonpFunctionName] = function webpackJsonpCallback(chunkIds, moreModules, executeModules) {
    /******/ // add "moreModules" to the modules object,
    /******/ // then flag all "chunkIds" as loaded and fire callback
    /******/var moduleId,
        chunkId,
        i = 0,
        resolves = [],
        result;
    /******/for (; i < chunkIds.length; i++) {
      /******/chunkId = chunkIds[i];
      /******/if (installedChunks[chunkId]) {
        /******/resolves.push(installedChunks[chunkId][0]);
        /******/
      }
      /******/installedChunks[chunkId] = 0;
      /******/
    }
    /******/for (moduleId in moreModules) {
      /******/if (Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
        /******/modules[moduleId] = moreModules[moduleId];
        /******/
      }
      /******/
    }
    /******/if (parentJsonpFunction) parentJsonpFunction(chunkIds, moreModules, executeModules);
    /******/while (resolves.length) {
      /******/resolves.shift()();
      /******/
    }
    /******/if (executeModules) {
      /******/for (i = 0; i < executeModules.length; i++) {
        /******/result = __webpack_require__(__webpack_require__.s = executeModules[i]);
        /******/
      }
      /******/
    }
    /******/return result;
    /******/
  };
  /******/
  /******/ // The module cache
  /******/var installedModules = {};
  /******/
  /******/ // objects to store loaded and loading chunks
  /******/var installedChunks = {
    /******/23: 0
    /******/ };
  /******/
  /******/ // The require function
  /******/function __webpack_require__(moduleId) {
    /******/
    /******/ // Check if module is in cache
    /******/if (installedModules[moduleId]) {
      /******/return installedModules[moduleId].exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/var module = installedModules[moduleId] = {
      /******/i: moduleId,
      /******/l: false,
      /******/exports: {}
      /******/ };
    /******/
    /******/ // Execute the module function
    /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    /******/
    /******/ // Flag the module as loaded
    /******/module.l = true;
    /******/
    /******/ // Return the exports of the module
    /******/return module.exports;
    /******/
  }
  /******/
  /******/
  /******/ // expose the modules object (__webpack_modules__)
  /******/__webpack_require__.m = modules;
  /******/
  /******/ // expose the module cache
  /******/__webpack_require__.c = installedModules;
  /******/
  /******/ // define getter function for harmony exports
  /******/__webpack_require__.d = function (exports, name, getter) {
    /******/if (!__webpack_require__.o(exports, name)) {
      /******/Object.defineProperty(exports, name, {
        /******/configurable: false,
        /******/enumerable: true,
        /******/get: getter
        /******/ });
      /******/
    }
    /******/
  };
  /******/
  /******/ // getDefaultExport function for compatibility with non-harmony modules
  /******/__webpack_require__.n = function (module) {
    /******/var getter = module && module.__esModule ?
    /******/function getDefault() {
      return module['default'];
    } :
    /******/function getModuleExports() {
      return module;
    };
    /******/__webpack_require__.d(getter, 'a', getter);
    /******/return getter;
    /******/
  };
  /******/
  /******/ // Object.prototype.hasOwnProperty.call
  /******/__webpack_require__.o = function (object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  /******/
  /******/ // __webpack_public_path__
  /******/__webpack_require__.p = "/";
  /******/
  /******/ // on error function for async loading
  /******/__webpack_require__.oe = function (err) {
    console.error(err);throw err;
  };
  /******/
})(
/************************************************************************/
/******/[]);
});
define("common/vendor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

global.webpackJsonpMpvue([0], [
/* 0 */
/***/function (module, exports) {

  /* globals __VUE_SSR_CONTEXT__ */

  // this module is a runtime utility for cleaner component module output and will
  // be included in the final webpack user bundle

  module.exports = function normalizeComponent(rawScriptExports, compiledTemplate, injectStyles, scopeId, moduleIdentifier /* server only */
  ) {
    var esModule;
    var scriptExports = rawScriptExports = rawScriptExports || {};

    // ES6 modules interop
    var type = _typeof2(rawScriptExports.default);
    if (type === 'object' || type === 'function') {
      esModule = rawScriptExports;
      scriptExports = rawScriptExports.default;
    }

    // Vue.extend constructor export interop
    var options = typeof scriptExports === 'function' ? scriptExports.options : scriptExports;

    // render functions
    if (compiledTemplate) {
      options.render = compiledTemplate.render;
      options.staticRenderFns = compiledTemplate.staticRenderFns;
    }

    // scopedId
    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;
    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true
        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        }
        // inject component styles
        if (injectStyles) {
          injectStyles.call(this, context);
        }
        // register component module identifier for async chunk inferrence
        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      };
      // used by ssr in case component is cached and beforeCreate
      // never gets called
      options._ssrRegister = hook;
    } else if (injectStyles) {
      hook = injectStyles;
    }

    if (hook) {
      var functional = options.functional;
      var existing = functional ? options.render : options.beforeCreate;
      if (!functional) {
        // inject component registration as beforeCreate hook
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      } else {
        // register for functioal component in vue file
        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return existing(h, context);
        };
      }
    }

    return {
      esModule: esModule,
      exports: scriptExports,
      options: options
    };
  };

  /***/
},
/* 1 */
/***/function (module, exports, __webpack_require__) {

  /* WEBPACK VAR INJECTION */(function (global) {
    // fix env
    try {
      if (!global) global = {};
      global.process = global.process || {};
      global.process.env = global.process.env || {};
      global.App = global.App || App;
      global.Page = global.Page || Page;
      global.Component = global.Component || Component;
      global.getApp = global.getApp || getApp;

      if (typeof wx !== 'undefined') {
        global.mpvue = wx;
        global.mpvuePlatform = 'wx';
      } else if (typeof swan !== 'undefined') {
        global.mpvue = swan;
        global.mpvuePlatform = 'swan';
      } else if (typeof tt !== 'undefined') {
        global.mpvue = tt;
        global.mpvuePlatform = 'tt';
      } else if (typeof my !== 'undefined') {
        global.mpvue = my;
        global.mpvuePlatform = 'my';
      }
    } catch (e) {}

    (function (global, factory) {
      true ? module.exports = factory() : typeof define === 'function' && define.amd ? define(factory) : global.Vue = factory();
    })(this, function () {
      'use strict';

      /*  */

      // these helpers produces better vm code in JS engines due to their
      // explicitness and function inlining

      function isUndef(v) {
        return v === undefined || v === null;
      }

      function isDef(v) {
        return v !== undefined && v !== null;
      }

      function isTrue(v) {
        return v === true;
      }

      function isFalse(v) {
        return v === false;
      }

      /**
       * Check if value is primitive
       */
      function isPrimitive(value) {
        return typeof value === 'string' || typeof value === 'number';
      }

      /**
       * Quick object check - this is primarily used to tell
       * Objects from primitive values when we know the value
       * is a JSON-compliant type.
       */
      function isObject(obj) {
        return obj !== null && (typeof obj === 'undefined' ? 'undefined' : _typeof2(obj)) === 'object';
      }

      var _toString = Object.prototype.toString;

      /**
       * Strict object type check. Only returns true
       * for plain JavaScript objects.
       */
      function isPlainObject(obj) {
        return _toString.call(obj) === '[object Object]';
      }

      function isRegExp(v) {
        return _toString.call(v) === '[object RegExp]';
      }

      /**
       * Check if val is a valid array index.
       */
      function isValidArrayIndex(val) {
        var n = parseFloat(val);
        return n >= 0 && Math.floor(n) === n && isFinite(val);
      }

      /**
       * Convert a value to a string that is actually rendered.
       */
      function toString(val) {
        return val == null ? '' : (typeof val === 'undefined' ? 'undefined' : _typeof2(val)) === 'object' ? JSON.stringify(val, null, 2) : String(val);
      }

      /**
       * Convert a input value to a number for persistence.
       * If the conversion fails, return original string.
       */
      function toNumber(val) {
        var n = parseFloat(val);
        return isNaN(n) ? val : n;
      }

      /**
       * Make a map and return a function for checking if a key
       * is in that map.
       */
      function makeMap(str, expectsLowerCase) {
        var map = Object.create(null);
        var list = str.split(',');
        for (var i = 0; i < list.length; i++) {
          map[list[i]] = true;
        }
        return expectsLowerCase ? function (val) {
          return map[val.toLowerCase()];
        } : function (val) {
          return map[val];
        };
      }

      /**
       * Check if a tag is a built-in tag.
       */
      var isBuiltInTag = makeMap('slot,component', true);

      /**
       * Check if a attribute is a reserved attribute.
       */
      var isReservedAttribute = makeMap('key,ref,slot,is');

      /**
       * Remove an item from an array
       */
      function remove(arr, item) {
        if (arr.length) {
          var index = arr.indexOf(item);
          if (index > -1) {
            return arr.splice(index, 1);
          }
        }
      }

      /**
       * Check whether the object has the property.
       */
      var hasOwnProperty = Object.prototype.hasOwnProperty;
      function hasOwn(obj, key) {
        return hasOwnProperty.call(obj, key);
      }

      /**
       * Create a cached version of a pure function.
       */
      function cached(fn) {
        var cache = Object.create(null);
        return function cachedFn(str) {
          var hit = cache[str];
          return hit || (cache[str] = fn(str));
        };
      }

      /**
       * Camelize a hyphen-delimited string.
       */
      var camelizeRE = /-(\w)/g;
      var camelize = cached(function (str) {
        return str.replace(camelizeRE, function (_, c) {
          return c ? c.toUpperCase() : '';
        });
      });

      /**
       * Capitalize a string.
       */
      var capitalize = cached(function (str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
      });

      /**
       * Hyphenate a camelCase string.
       */
      var hyphenateRE = /([^-])([A-Z])/g;
      var hyphenate = cached(function (str) {
        return str.replace(hyphenateRE, '$1-$2').replace(hyphenateRE, '$1-$2').toLowerCase();
      });

      /**
       * Simple bind, faster than native
       */
      function bind(fn, ctx) {
        function boundFn(a) {
          var l = arguments.length;
          return l ? l > 1 ? fn.apply(ctx, arguments) : fn.call(ctx, a) : fn.call(ctx);
        }
        // record original fn length
        boundFn._length = fn.length;
        return boundFn;
      }

      /**
       * Convert an Array-like object to a real Array.
       */
      function toArray(list, start) {
        start = start || 0;
        var i = list.length - start;
        var ret = new Array(i);
        while (i--) {
          ret[i] = list[i + start];
        }
        return ret;
      }

      /**
       * Mix properties into target object.
       */
      function extend(to, _from) {
        for (var key in _from) {
          to[key] = _from[key];
        }
        return to;
      }

      /**
       * Merge an Array of Objects into a single Object.
       */
      function toObject(arr) {
        var res = {};
        for (var i = 0; i < arr.length; i++) {
          if (arr[i]) {
            extend(res, arr[i]);
          }
        }
        return res;
      }

      /**
       * Perform no operation.
       * Stubbing args to make Flow happy without leaving useless transpiled code
       * with ...rest (https://flow.org/blog/2017/05/07/Strict-Function-Call-Arity/)
       */
      function noop(a, b, c) {}

      /**
       * Always return false.
       */
      var no = function no(a, b, c) {
        return false;
      };

      /**
       * Return same value
       */
      var identity = function identity(_) {
        return _;
      };

      /**
       * Generate a static keys string from compiler modules.
       */

      /**
       * Check if two values are loosely equal - that is,
       * if they are plain objects, do they have the same shape?
       */
      function looseEqual(a, b) {
        var isObjectA = isObject(a);
        var isObjectB = isObject(b);
        if (isObjectA && isObjectB) {
          try {
            return JSON.stringify(a) === JSON.stringify(b);
          } catch (e) {
            // possible circular reference
            return a === b;
          }
        } else if (!isObjectA && !isObjectB) {
          return String(a) === String(b);
        } else {
          return false;
        }
      }

      function looseIndexOf(arr, val) {
        for (var i = 0; i < arr.length; i++) {
          if (looseEqual(arr[i], val)) {
            return i;
          }
        }
        return -1;
      }

      /**
       * Ensure a function is called only once.
       */
      function once(fn) {
        var called = false;
        return function () {
          if (!called) {
            called = true;
            fn.apply(this, arguments);
          }
        };
      }

      var SSR_ATTR = 'data-server-rendered';

      var ASSET_TYPES = ['component', 'directive', 'filter'];

      var LIFECYCLE_HOOKS = ['beforeCreate', 'created', 'beforeMount', 'mounted', 'beforeUpdate', 'updated', 'beforeDestroy', 'destroyed', 'activated', 'deactivated', 'onLaunch', 'onLoad', 'onShow', 'onReady', 'onHide', 'onUnload', 'onPullDownRefresh', 'onReachBottom', 'onShareAppMessage', 'onPageScroll', 'onTabItemTap', 'attached', 'ready', 'moved', 'detached'];

      /*  */

      var config = {
        /**
         * Option merge strategies (used in core/util/options)
         */
        optionMergeStrategies: Object.create(null),

        /**
         * Whether to suppress warnings.
         */
        silent: false,

        /**
         * Show production mode tip message on boot?
         */
        productionTip: "production" !== 'production',

        /**
         * Whether to enable devtools
         */
        devtools: "production" !== 'production',

        /**
         * Whether to record perf
         */
        performance: false,

        /**
         * Error handler for watcher errors
         */
        errorHandler: null,

        /**
         * Warn handler for watcher warns
         */
        warnHandler: null,

        /**
         * Ignore certain custom elements
         */
        ignoredElements: [],

        /**
         * Custom user key aliases for v-on
         */
        keyCodes: Object.create(null),

        /**
         * Check if a tag is reserved so that it cannot be registered as a
         * component. This is platform-dependent and may be overwritten.
         */
        isReservedTag: no,

        /**
         * Check if an attribute is reserved so that it cannot be used as a component
         * prop. This is platform-dependent and may be overwritten.
         */
        isReservedAttr: no,

        /**
         * Check if a tag is an unknown element.
         * Platform-dependent.
         */
        isUnknownElement: no,

        /**
         * Get the namespace of an element
         */
        getTagNamespace: noop,

        /**
         * Parse the real tag name for the specific platform.
         */
        parsePlatformTagName: identity,

        /**
         * Check if an attribute must be bound using property, e.g. value
         * Platform-dependent.
         */
        mustUseProp: no,

        /**
         * Exposed for legacy reasons
         */
        _lifecycleHooks: LIFECYCLE_HOOKS
      };

      /*  */

      var emptyObject = Object.freeze({});

      /**
       * Check if a string starts with $ or _
       */
      function isReserved(str) {
        var c = (str + '').charCodeAt(0);
        return c === 0x24 || c === 0x5F;
      }

      /**
       * Define a property.
       */
      function def(obj, key, val, enumerable) {
        Object.defineProperty(obj, key, {
          value: val,
          enumerable: !!enumerable,
          writable: true,
          configurable: true
        });
      }

      /**
       * Parse simple path.
       */
      var bailRE = /[^\w.$]/;
      function parsePath(path) {
        if (bailRE.test(path)) {
          return;
        }
        var segments = path.split('.');
        return function (obj) {
          for (var i = 0; i < segments.length; i++) {
            if (!obj) {
              return;
            }
            obj = obj[segments[i]];
          }
          return obj;
        };
      }

      /*  */

      var warn = noop;

      var formatComponentName = null; // work around flow check

      /*  */

      function handleError(err, vm, info) {
        if (config.errorHandler) {
          config.errorHandler.call(null, err, vm, info);
        } else {
          if (inBrowser && typeof console !== 'undefined') {
            console.error(err);
          } else {
            throw err;
          }
        }
      }

      /*  */

      // can we use __proto__?
      var hasProto = '__proto__' in {};

      // Browser environment sniffing
      var inBrowser = typeof window !== 'undefined';
      var UA = ['mpvue-runtime'].join();
      var isIE = UA && /msie|trident/.test(UA);
      var isIE9 = UA && UA.indexOf('msie 9.0') > 0;
      var isEdge = UA && UA.indexOf('edge/') > 0;
      var isAndroid = UA && UA.indexOf('android') > 0;
      var isIOS = UA && /iphone|ipad|ipod|ios/.test(UA);
      var isChrome = UA && /chrome\/\d+/.test(UA) && !isEdge;

      // Firefix has a "watch" function on Object.prototype...
      var nativeWatch = {}.watch;

      var supportsPassive = false;
      if (inBrowser) {
        try {
          var opts = {};
          Object.defineProperty(opts, 'passive', {
            get: function get() {
              /* istanbul ignore next */
              supportsPassive = true;
            }
          }); // https://github.com/facebook/flow/issues/285
          window.addEventListener('test-passive', null, opts);
        } catch (e) {}
      }

      // this needs to be lazy-evaled because vue may be required before
      // vue-server-renderer can set VUE_ENV
      var _isServer;
      var isServerRendering = function isServerRendering() {
        if (_isServer === undefined) {
          /* istanbul ignore if */
          if (!inBrowser && typeof global !== 'undefined') {
            // detect presence of vue-server-renderer and avoid
            // Webpack shimming the process
            _isServer = global['process'].env.VUE_ENV === 'server';
          } else {
            _isServer = false;
          }
        }
        return _isServer;
      };

      // detect devtools
      var devtools = inBrowser && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;

      /* istanbul ignore next */
      function isNative(Ctor) {
        return typeof Ctor === 'function' && /native code/.test(Ctor.toString());
      }

      var hasSymbol = typeof Symbol !== 'undefined' && isNative(Symbol) && typeof Reflect !== 'undefined' && isNative(Reflect.ownKeys);

      /**
       * Defer a task to execute it asynchronously.
       */
      var nextTick = function () {
        var callbacks = [];
        var pending = false;
        var timerFunc;

        function nextTickHandler() {
          pending = false;
          var copies = callbacks.slice(0);
          callbacks.length = 0;
          for (var i = 0; i < copies.length; i++) {
            copies[i]();
          }
        }

        // the nextTick behavior leverages the microtask queue, which can be accessed
        // via either native Promise.then or MutationObserver.
        // MutationObserver has wider support, however it is seriously bugged in
        // UIWebView in iOS >= 9.3.3 when triggered in touch event handlers. It
        // completely stops working after triggering a few times... so, if native
        // Promise is available, we will use it:
        /* istanbul ignore if */
        if (typeof Promise !== 'undefined' && isNative(Promise)) {
          var p = Promise.resolve();
          var logError = function logError(err) {
            console.error(err);
          };
          timerFunc = function timerFunc() {
            p.then(nextTickHandler).catch(logError);
            // in problematic UIWebViews, Promise.then doesn't completely break, but
            // it can get stuck in a weird state where callbacks are pushed into the
            // microtask queue but the queue isn't being flushed, until the browser
            // needs to do some other work, e.g. handle a timer. Therefore we can
            // "force" the microtask queue to be flushed by adding an empty timer.
            if (isIOS) {
              setTimeout(noop);
            }
          };
          // } else if (typeof MutationObserver !== 'undefined' && (
          //   isNative(MutationObserver) ||
          //   // PhantomJS and iOS 7.x
          //   MutationObserver.toString() === '[object MutationObserverConstructor]'
          // )) {
          //   // use MutationObserver where native Promise is not available,
          //   // e.g. PhantomJS IE11, iOS7, Android 4.4
          //   var counter = 1
          //   var observer = new MutationObserver(nextTickHandler)
          //   var textNode = document.createTextNode(String(counter))
          //   observer.observe(textNode, {
          //     characterData: true
          //   })
          //   timerFunc = () => {
          //     counter = (counter + 1) % 2
          //     textNode.data = String(counter)
          //   }
        } else {
          // fallback to setTimeout
          /* istanbul ignore next */
          timerFunc = function timerFunc() {
            setTimeout(nextTickHandler, 0);
          };
        }

        return function queueNextTick(cb, ctx) {
          var _resolve;
          callbacks.push(function () {
            if (cb) {
              try {
                cb.call(ctx);
              } catch (e) {
                handleError(e, ctx, 'nextTick');
              }
            } else if (_resolve) {
              _resolve(ctx);
            }
          });
          if (!pending) {
            pending = true;
            timerFunc();
          }
          if (!cb && typeof Promise !== 'undefined') {
            return new Promise(function (resolve, reject) {
              _resolve = resolve;
            });
          }
        };
      }();

      var _Set;
      /* istanbul ignore if */
      if (typeof Set !== 'undefined' && isNative(Set)) {
        // use native Set when available.
        _Set = Set;
      } else {
        // a non-standard Set polyfill that only works with primitive keys.
        _Set = function () {
          function Set() {
            this.set = Object.create(null);
          }
          Set.prototype.has = function has(key) {
            return this.set[key] === true;
          };
          Set.prototype.add = function add(key) {
            this.set[key] = true;
          };
          Set.prototype.clear = function clear() {
            this.set = Object.create(null);
          };

          return Set;
        }();
      }

      /*  */

      var uid$1 = 0;

      /**
       * A dep is an observable that can have multiple
       * directives subscribing to it.
       */
      var Dep = function Dep() {
        this.id = uid$1++;
        this.subs = [];
      };

      Dep.prototype.addSub = function addSub(sub) {
        this.subs.push(sub);
      };

      Dep.prototype.removeSub = function removeSub(sub) {
        remove(this.subs, sub);
      };

      Dep.prototype.depend = function depend() {
        if (Dep.target) {
          Dep.target.addDep(this);
        }
      };

      Dep.prototype.notify = function notify() {
        // stabilize the subscriber list first
        var subs = this.subs.slice();
        for (var i = 0, l = subs.length; i < l; i++) {
          subs[i].update();
        }
      };

      // the current target watcher being evaluated.
      // this is globally unique because there could be only one
      // watcher being evaluated at any time.
      Dep.target = null;
      var targetStack = [];

      function pushTarget(_target) {
        if (Dep.target) {
          targetStack.push(Dep.target);
        }
        Dep.target = _target;
      }

      function popTarget() {
        Dep.target = targetStack.pop();
      }

      /*
       * not type checking this file because flow doesn't play well with
       * dynamically accessing methods on Array prototype
       */

      var arrayProto = Array.prototype;
      var arrayMethods = Object.create(arrayProto);['push', 'pop', 'shift', 'unshift', 'splice', 'sort', 'reverse'].forEach(function (method) {
        // cache original method
        var original = arrayProto[method];
        def(arrayMethods, method, function mutator() {
          var args = [],
              len = arguments.length;
          while (len--) {
            args[len] = arguments[len];
          }var result = original.apply(this, args);
          var ob = this.__ob__;
          var inserted;
          switch (method) {
            case 'push':
            case 'unshift':
              inserted = args;
              break;
            case 'splice':
              inserted = args.slice(2);
              break;
          }
          if (inserted) {
            ob.observeArray(inserted);
          }
          // notify change
          ob.dep.notify();
          return result;
        });
      });

      /*  */

      var arrayKeys = Object.getOwnPropertyNames(arrayMethods);

      /**
       * By default, when a reactive property is set, the new value is
       * also converted to become reactive. However when passing down props,
       * we don't want to force conversion because the value may be a nested value
       * under a frozen data structure. Converting it would defeat the optimization.
       */
      var observerState = {
        shouldConvert: true
      };

      /**
       * Observer class that are attached to each observed
       * object. Once attached, the observer converts target
       * object's property keys into getter/setters that
       * collect dependencies and dispatches updates.
       */
      var Observer = function Observer(value, key) {
        this.value = value;
        this.dep = new Dep();
        this.vmCount = 0;
        if (key) {
          this.key = key;
        }
        def(value, '__ob__', this);
        if (Array.isArray(value)) {
          var augment = hasProto ? protoAugment : copyAugment;
          augment(value, arrayMethods, arrayKeys);
          this.observeArray(value);
        } else {
          this.walk(value);
        }
      };

      /**
       * Walk through each property and convert them into
       * getter/setters. This method should only be called when
       * value type is Object.
       */
      Observer.prototype.walk = function walk(obj) {
        var keys = Object.keys(obj);
        for (var i = 0; i < keys.length; i++) {
          defineReactive$$1(obj, keys[i], obj[keys[i]]);
        }
      };

      /**
       * Observe a list of Array items.
       */
      Observer.prototype.observeArray = function observeArray(items) {
        for (var i = 0, l = items.length; i < l; i++) {
          observe(items[i]);
        }
      };

      // helpers

      /**
       * Augment an target Object or Array by intercepting
       * the prototype chain using __proto__
       */
      function protoAugment(target, src, keys) {
        /* eslint-disable no-proto */
        target.__proto__ = src;
        /* eslint-enable no-proto */
      }

      /**
       * Augment an target Object or Array by defining
       * hidden properties.
       */
      /* istanbul ignore next */
      function copyAugment(target, src, keys) {
        for (var i = 0, l = keys.length; i < l; i++) {
          var key = keys[i];
          def(target, key, src[key]);
        }
      }

      /**
       * Attempt to create an observer instance for a value,
       * returns the new observer if successfully observed,
       * or the existing observer if the value already has one.
       */
      function observe(value, asRootData, key) {
        if (!isObject(value)) {
          return;
        }
        var ob;
        if (hasOwn(value, '__ob__') && value.__ob__ instanceof Observer) {
          ob = value.__ob__;
        } else if (observerState.shouldConvert && !isServerRendering() && (Array.isArray(value) || isPlainObject(value)) && Object.isExtensible(value) && !value._isVue) {
          ob = new Observer(value, key);
        }
        if (asRootData && ob) {
          ob.vmCount++;
        }
        return ob;
      }

      /**
       * Define a reactive property on an Object.
       */
      function defineReactive$$1(obj, key, val, customSetter, shallow) {
        var dep = new Dep();

        var property = Object.getOwnPropertyDescriptor(obj, key);
        if (property && property.configurable === false) {
          return;
        }

        // cater for pre-defined getter/setters
        var getter = property && property.get;
        var setter = property && property.set;

        var childOb = !shallow && observe(val, undefined, key);
        Object.defineProperty(obj, key, {
          enumerable: true,
          configurable: true,
          get: function reactiveGetter() {
            var value = getter ? getter.call(obj) : val;
            if (Dep.target) {
              dep.depend();
              if (childOb) {
                childOb.dep.depend();
              }
              if (Array.isArray(value)) {
                dependArray(value);
              }
            }
            return value;
          },
          set: function reactiveSetter(newVal) {
            var value = getter ? getter.call(obj) : val;
            /* eslint-disable no-self-compare */
            if (newVal === value || newVal !== newVal && value !== value) {
              return;
            }

            /* eslint-enable no-self-compare */
            if (false) {
              customSetter();
            }
            if (setter) {
              setter.call(obj, newVal);
            } else {
              val = newVal;
            }
            childOb = !shallow && observe(newVal, undefined, key);
            dep.notify();

            if (!obj.__keyPath) {
              def(obj, '__keyPath', {}, false);
            }
            obj.__keyPath[key] = true;
            if (newVal instanceof Object && !(newVal instanceof Array)) {
              // 标记是否是通过this.Obj = {} 赋值印发的改动，解决少更新问题#1305
              def(newVal, '__newReference', true, false);
            }
          }
        });
      }

      /**
       * Set a property on an object. Adds the new property and
       * triggers change notification if the property doesn't
       * already exist.
       */
      function set(target, key, val) {
        if (Array.isArray(target) && isValidArrayIndex(key)) {
          target.length = Math.max(target.length, key);
          target.splice(key, 1, val);
          return val;
        }
        if (hasOwn(target, key)) {
          target[key] = val;
          return val;
        }
        var ob = target.__ob__;
        if (target._isVue || ob && ob.vmCount) {
          "production" !== 'production' && warn('Avoid adding reactive properties to a Vue instance or its root $data ' + 'at runtime - declare it upfront in the data option.');
          return val;
        }
        if (!ob) {
          target[key] = val;
          return val;
        }
        defineReactive$$1(ob.value, key, val);
        // Vue.set 添加对象属性，渲染时候把 val 传给小程序渲染
        if (!target.__keyPath) {
          def(target, '__keyPath', {}, false);
        }
        target.__keyPath[key] = true;
        ob.dep.notify();
        return val;
      }

      /**
       * Delete a property and trigger change if necessary.
       */
      function del(target, key) {
        if (Array.isArray(target) && isValidArrayIndex(key)) {
          target.splice(key, 1);
          return;
        }
        var ob = target.__ob__;
        if (target._isVue || ob && ob.vmCount) {
          "production" !== 'production' && warn('Avoid deleting properties on a Vue instance or its root $data ' + '- just set it to null.');
          return;
        }
        if (!hasOwn(target, key)) {
          return;
        }
        delete target[key];
        if (!ob) {
          return;
        }
        if (!target.__keyPath) {
          def(target, '__keyPath', {}, false);
        }
        // Vue.del 删除对象属性，渲染时候把这个属性设置为 undefined
        target.__keyPath[key] = 'del';
        ob.dep.notify();
      }

      /**
       * Collect dependencies on array elements when the array is touched, since
       * we cannot intercept array element access like property getters.
       */
      function dependArray(value) {
        for (var e = void 0, i = 0, l = value.length; i < l; i++) {
          e = value[i];
          e && e.__ob__ && e.__ob__.dep.depend();
          if (Array.isArray(e)) {
            dependArray(e);
          }
        }
      }

      /*  */

      /**
       * Option overwriting strategies are functions that handle
       * how to merge a parent option value and a child option
       * value into the final value.
       */
      var strats = config.optionMergeStrategies;

      /**
       * Options with restrictions
       */
      /**
       * Helper that recursively merges two data objects together.
       */
      function mergeData(to, from) {
        if (!from) {
          return to;
        }
        var key, toVal, fromVal;
        var keys = Object.keys(from);
        for (var i = 0; i < keys.length; i++) {
          key = keys[i];
          toVal = to[key];
          fromVal = from[key];
          if (!hasOwn(to, key)) {
            set(to, key, fromVal);
          } else if (isPlainObject(toVal) && isPlainObject(fromVal)) {
            mergeData(toVal, fromVal);
          }
        }
        return to;
      }

      /**
       * Data
       */
      function mergeDataOrFn(parentVal, childVal, vm) {
        if (!vm) {
          // in a Vue.extend merge, both should be functions
          if (!childVal) {
            return parentVal;
          }
          if (!parentVal) {
            return childVal;
          }
          // when parentVal & childVal are both present,
          // we need to return a function that returns the
          // merged result of both functions... no need to
          // check if parentVal is a function here because
          // it has to be a function to pass previous merges.
          return function mergedDataFn() {
            return mergeData(typeof childVal === 'function' ? childVal.call(this) : childVal, parentVal.call(this));
          };
        } else if (parentVal || childVal) {
          return function mergedInstanceDataFn() {
            // instance merge
            var instanceData = typeof childVal === 'function' ? childVal.call(vm) : childVal;
            var defaultData = typeof parentVal === 'function' ? parentVal.call(vm) : undefined;
            if (instanceData) {
              return mergeData(instanceData, defaultData);
            } else {
              return defaultData;
            }
          };
        }
      }

      strats.data = function (parentVal, childVal, vm) {
        if (!vm) {
          if (childVal && typeof childVal !== 'function') {
            "production" !== 'production' && warn('The "data" option should be a function ' + 'that returns a per-instance value in component ' + 'definitions.', vm);

            return parentVal;
          }
          return mergeDataOrFn.call(this, parentVal, childVal);
        }

        return mergeDataOrFn(parentVal, childVal, vm);
      };

      /**
       * Hooks and props are merged as arrays.
       */
      function mergeHook(parentVal, childVal) {
        return childVal ? parentVal ? parentVal.concat(childVal) : Array.isArray(childVal) ? childVal : [childVal] : parentVal;
      }

      LIFECYCLE_HOOKS.forEach(function (hook) {
        strats[hook] = mergeHook;
      });

      /**
       * Assets
       *
       * When a vm is present (instance creation), we need to do
       * a three-way merge between constructor options, instance
       * options and parent options.
       */
      function mergeAssets(parentVal, childVal) {
        var res = Object.create(parentVal || null);
        return childVal ? extend(res, childVal) : res;
      }

      ASSET_TYPES.forEach(function (type) {
        strats[type + 's'] = mergeAssets;
      });

      /**
       * Watchers.
       *
       * Watchers hashes should not overwrite one
       * another, so we merge them as arrays.
       */
      strats.watch = function (parentVal, childVal) {
        // work around Firefox's Object.prototype.watch...
        if (parentVal === nativeWatch) {
          parentVal = undefined;
        }
        if (childVal === nativeWatch) {
          childVal = undefined;
        }
        /* istanbul ignore if */
        if (!childVal) {
          return Object.create(parentVal || null);
        }
        if (!parentVal) {
          return childVal;
        }
        var ret = {};
        extend(ret, parentVal);
        for (var key in childVal) {
          var parent = ret[key];
          var child = childVal[key];
          if (parent && !Array.isArray(parent)) {
            parent = [parent];
          }
          ret[key] = parent ? parent.concat(child) : Array.isArray(child) ? child : [child];
        }
        return ret;
      };

      /**
       * Other object hashes.
       */
      strats.props = strats.methods = strats.inject = strats.computed = function (parentVal, childVal) {
        if (!childVal) {
          return Object.create(parentVal || null);
        }
        if (!parentVal) {
          return childVal;
        }
        var ret = Object.create(null);
        extend(ret, parentVal);
        extend(ret, childVal);
        return ret;
      };
      strats.provide = mergeDataOrFn;

      /**
       * Default strategy.
       */
      var defaultStrat = function defaultStrat(parentVal, childVal) {
        return childVal === undefined ? parentVal : childVal;
      };

      /**
       * Ensure all props option syntax are normalized into the
       * Object-based format.
       */
      function normalizeProps(options) {
        var props = options.props;
        if (!props) {
          return;
        }
        var res = {};
        var i, val, name;
        if (Array.isArray(props)) {
          i = props.length;
          while (i--) {
            val = props[i];
            if (typeof val === 'string') {
              name = camelize(val);
              res[name] = { type: null };
            } else {}
          }
        } else if (isPlainObject(props)) {
          for (var key in props) {
            val = props[key];
            name = camelize(key);
            res[name] = isPlainObject(val) ? val : { type: val };
          }
        }
        options.props = res;
      }

      /**
       * Normalize all injections into Object-based format
       */
      function normalizeInject(options) {
        var inject = options.inject;
        if (Array.isArray(inject)) {
          var normalized = options.inject = {};
          for (var i = 0; i < inject.length; i++) {
            normalized[inject[i]] = inject[i];
          }
        }
      }

      /**
       * Normalize raw function directives into object format.
       */
      function normalizeDirectives(options) {
        var dirs = options.directives;
        if (dirs) {
          for (var key in dirs) {
            var def = dirs[key];
            if (typeof def === 'function') {
              dirs[key] = { bind: def, update: def };
            }
          }
        }
      }

      /**
       * Merge two option objects into a new one.
       * Core utility used in both instantiation and inheritance.
       */
      function mergeOptions(parent, child, vm) {
        if (typeof child === 'function') {
          child = child.options;
        }

        normalizeProps(child);
        normalizeInject(child);
        normalizeDirectives(child);
        var extendsFrom = child.extends;
        if (extendsFrom) {
          parent = mergeOptions(parent, extendsFrom, vm);
        }
        if (child.mixins) {
          for (var i = 0, l = child.mixins.length; i < l; i++) {
            parent = mergeOptions(parent, child.mixins[i], vm);
          }
        }
        var options = {};
        var key;
        for (key in parent) {
          mergeField(key);
        }
        for (key in child) {
          if (!hasOwn(parent, key)) {
            mergeField(key);
          }
        }
        function mergeField(key) {
          var strat = strats[key] || defaultStrat;
          options[key] = strat(parent[key], child[key], vm, key);
        }
        return options;
      }

      /**
       * Resolve an asset.
       * This function is used because child instances need access
       * to assets defined in its ancestor chain.
       */
      function resolveAsset(options, type, id, warnMissing) {
        /* istanbul ignore if */
        if (typeof id !== 'string') {
          return;
        }
        var assets = options[type];
        // check local registration variations first
        if (hasOwn(assets, id)) {
          return assets[id];
        }
        var camelizedId = camelize(id);
        if (hasOwn(assets, camelizedId)) {
          return assets[camelizedId];
        }
        var PascalCaseId = capitalize(camelizedId);
        if (hasOwn(assets, PascalCaseId)) {
          return assets[PascalCaseId];
        }
        // fallback to prototype chain
        var res = assets[id] || assets[camelizedId] || assets[PascalCaseId];
        if (false) {
          warn('Failed to resolve ' + type.slice(0, -1) + ': ' + id, options);
        }
        return res;
      }

      /*  */

      function validateProp(key, propOptions, propsData, vm) {
        var prop = propOptions[key];
        var absent = !hasOwn(propsData, key);
        var value = propsData[key];
        // handle boolean props
        if (isType(Boolean, prop.type)) {
          if (absent && !hasOwn(prop, 'default')) {
            value = false;
          } else if (!isType(String, prop.type) && (value === '' || value === hyphenate(key))) {
            value = true;
          }
        }
        // check default value
        if (value === undefined) {
          value = getPropDefaultValue(vm, prop, key);
          // since the default value is a fresh copy,
          // make sure to observe it.
          var prevShouldConvert = observerState.shouldConvert;
          observerState.shouldConvert = true;
          observe(value);
          observerState.shouldConvert = prevShouldConvert;
        }
        return value;
      }

      /**
       * Get the default value of a prop.
       */
      function getPropDefaultValue(vm, prop, key) {
        // no default, return undefined
        if (!hasOwn(prop, 'default')) {
          return undefined;
        }
        var def = prop.default;
        // warn against non-factory defaults for Object & Array
        if (false) {
          warn('Invalid default value for prop "' + key + '": ' + 'Props with type Object/Array must use a factory function ' + 'to return the default value.', vm);
        }
        // the raw prop value was also undefined from previous render,
        // return previous default value to avoid unnecessary watcher trigger
        if (vm && vm.$options.propsData && vm.$options.propsData[key] === undefined && vm._props[key] !== undefined) {
          return vm._props[key];
        }
        // call factory function for non-Function types
        // a value is Function if its prototype is function even across different execution context
        return typeof def === 'function' && getType(prop.type) !== 'Function' ? def.call(vm) : def;
      }

      /**
       * Use function string name to check built-in types,
       * because a simple equality check will fail when running
       * across different vms / iframes.
       */
      function getType(fn) {
        var match = fn && fn.toString().match(/^\s*function (\w+)/);
        return match ? match[1] : '';
      }

      function isType(type, fn) {
        if (!Array.isArray(fn)) {
          return getType(fn) === getType(type);
        }
        for (var i = 0, len = fn.length; i < len; i++) {
          if (getType(fn[i]) === getType(type)) {
            return true;
          }
        }
        /* istanbul ignore next */
        return false;
      }

      /*  */

      /* not type checking this file because flow doesn't play well with Proxy */

      var mark;
      var measure;

      /*  */

      var VNode = function VNode(tag, data, children, text, elm, context, componentOptions, asyncFactory) {
        this.tag = tag;
        this.data = data;
        this.children = children;
        this.text = text;
        this.elm = elm;
        this.ns = undefined;
        this.context = context;
        this.functionalContext = undefined;
        this.key = data && data.key;
        this.componentOptions = componentOptions;
        this.componentInstance = undefined;
        this.parent = undefined;
        this.raw = false;
        this.isStatic = false;
        this.isRootInsert = true;
        this.isComment = false;
        this.isCloned = false;
        this.isOnce = false;
        this.asyncFactory = asyncFactory;
        this.asyncMeta = undefined;
        this.isAsyncPlaceholder = false;
      };

      var prototypeAccessors = { child: {} };

      // DEPRECATED: alias for componentInstance for backwards compat.
      /* istanbul ignore next */
      prototypeAccessors.child.get = function () {
        return this.componentInstance;
      };

      Object.defineProperties(VNode.prototype, prototypeAccessors);

      var createEmptyVNode = function createEmptyVNode(text) {
        if (text === void 0) text = '';

        var node = new VNode();
        node.text = text;
        node.isComment = true;
        return node;
      };

      function createTextVNode(val) {
        return new VNode(undefined, undefined, undefined, String(val));
      }

      // optimized shallow clone
      // used for static nodes and slot nodes because they may be reused across
      // multiple renders, cloning them avoids errors when DOM manipulations rely
      // on their elm reference.
      function cloneVNode(vnode) {
        var cloned = new VNode(vnode.tag, vnode.data, vnode.children, vnode.text, vnode.elm, vnode.context, vnode.componentOptions, vnode.asyncFactory);
        cloned.ns = vnode.ns;
        cloned.isStatic = vnode.isStatic;
        cloned.key = vnode.key;
        cloned.isComment = vnode.isComment;
        cloned.isCloned = true;
        return cloned;
      }

      function cloneVNodes(vnodes) {
        var len = vnodes.length;
        var res = new Array(len);
        for (var i = 0; i < len; i++) {
          res[i] = cloneVNode(vnodes[i]);
        }
        return res;
      }

      /*  */

      var normalizeEvent = cached(function (name) {
        var passive = name.charAt(0) === '&';
        name = passive ? name.slice(1) : name;
        var once$$1 = name.charAt(0) === '~'; // Prefixed last, checked first
        name = once$$1 ? name.slice(1) : name;
        var capture = name.charAt(0) === '!';
        name = capture ? name.slice(1) : name;
        return {
          name: name,
          once: once$$1,
          capture: capture,
          passive: passive
        };
      });

      function createFnInvoker(fns) {
        function invoker() {
          var arguments$1 = arguments;

          var fns = invoker.fns;
          if (Array.isArray(fns)) {
            var cloned = fns.slice();
            for (var i = 0; i < cloned.length; i++) {
              cloned[i].apply(null, arguments$1);
            }
          } else {
            // return handler return value for single handlers
            return fns.apply(null, arguments);
          }
        }
        invoker.fns = fns;
        return invoker;
      }

      function updateListeners(on, oldOn, add, remove$$1, vm) {
        var name, cur, old, event;
        for (name in on) {
          cur = on[name];
          old = oldOn[name];
          event = normalizeEvent(name);
          if (isUndef(cur)) {
            "production" !== 'production' && warn("Invalid handler for event \"" + event.name + "\": got " + String(cur), vm);
          } else if (isUndef(old)) {
            if (isUndef(cur.fns)) {
              cur = on[name] = createFnInvoker(cur);
            }
            add(event.name, cur, event.once, event.capture, event.passive);
          } else if (cur !== old) {
            old.fns = cur;
            on[name] = old;
          }
        }
        for (name in oldOn) {
          if (isUndef(on[name])) {
            event = normalizeEvent(name);
            remove$$1(event.name, oldOn[name], event.capture);
          }
        }
      }

      /*  */

      /*  */

      function extractPropsFromVNodeData(data, Ctor, tag) {
        // we are only extracting raw values here.
        // validation and default values are handled in the child
        // component itself.
        var propOptions = Ctor.options.props;
        if (isUndef(propOptions)) {
          return;
        }
        var res = {};
        var attrs = data.attrs;
        var props = data.props;
        if (isDef(attrs) || isDef(props)) {
          for (var key in propOptions) {
            var altKey = hyphenate(key);
            checkProp(res, props, key, altKey, true) || checkProp(res, attrs, key, altKey, false);
          }
        }
        return res;
      }

      function checkProp(res, hash, key, altKey, preserve) {
        if (isDef(hash)) {
          if (hasOwn(hash, key)) {
            res[key] = hash[key];
            if (!preserve) {
              delete hash[key];
            }
            return true;
          } else if (hasOwn(hash, altKey)) {
            res[key] = hash[altKey];
            if (!preserve) {
              delete hash[altKey];
            }
            return true;
          }
        }
        return false;
      }

      /*  */

      // The template compiler attempts to minimize the need for normalization by
      // statically analyzing the template at compile time.
      //
      // For plain HTML markup, normalization can be completely skipped because the
      // generated render function is guaranteed to return Array<VNode>. There are
      // two cases where extra normalization is needed:

      // 1. When the children contains components - because a functional component
      // may return an Array instead of a single root. In this case, just a simple
      // normalization is needed - if any child is an Array, we flatten the whole
      // thing with Array.prototype.concat. It is guaranteed to be only 1-level deep
      // because functional components already normalize their own children.
      function simpleNormalizeChildren(children) {
        for (var i = 0; i < children.length; i++) {
          if (Array.isArray(children[i])) {
            return Array.prototype.concat.apply([], children);
          }
        }
        return children;
      }

      // 2. When the children contains constructs that always generated nested Arrays,
      // e.g. <template>, <slot>, v-for, or when the children is provided by user
      // with hand-written render functions / JSX. In such cases a full normalization
      // is needed to cater to all possible types of children values.
      function normalizeChildren(children) {
        return isPrimitive(children) ? [createTextVNode(children)] : Array.isArray(children) ? normalizeArrayChildren(children) : undefined;
      }

      function isTextNode(node) {
        return isDef(node) && isDef(node.text) && isFalse(node.isComment);
      }

      function normalizeArrayChildren(children, nestedIndex) {
        var res = [];
        var i, c, last;
        for (i = 0; i < children.length; i++) {
          c = children[i];
          if (isUndef(c) || typeof c === 'boolean') {
            continue;
          }
          last = res[res.length - 1];
          //  nested
          if (Array.isArray(c)) {
            res.push.apply(res, normalizeArrayChildren(c, (nestedIndex || '') + "_" + i));
          } else if (isPrimitive(c)) {
            if (isTextNode(last)) {
              // merge adjacent text nodes
              // this is necessary for SSR hydration because text nodes are
              // essentially merged when rendered to HTML strings
              last.text += String(c);
            } else if (c !== '') {
              // convert primitive to vnode
              res.push(createTextVNode(c));
            }
          } else {
            if (isTextNode(c) && isTextNode(last)) {
              // merge adjacent text nodes
              res[res.length - 1] = createTextVNode(last.text + c.text);
            } else {
              // default key for nested array children (likely generated by v-for)
              if (isTrue(children._isVList) && isDef(c.tag) && isUndef(c.key) && isDef(nestedIndex)) {
                c.key = "__vlist" + nestedIndex + "_" + i + "__";
              }
              res.push(c);
            }
          }
        }
        return res;
      }

      /*  */

      function ensureCtor(comp, base) {
        if (comp.__esModule && comp.default) {
          comp = comp.default;
        }
        return isObject(comp) ? base.extend(comp) : comp;
      }

      function createAsyncPlaceholder(factory, data, context, children, tag) {
        var node = createEmptyVNode();
        node.asyncFactory = factory;
        node.asyncMeta = { data: data, context: context, children: children, tag: tag };
        return node;
      }

      function resolveAsyncComponent(factory, baseCtor, context) {
        if (isTrue(factory.error) && isDef(factory.errorComp)) {
          return factory.errorComp;
        }

        if (isDef(factory.resolved)) {
          return factory.resolved;
        }

        if (isTrue(factory.loading) && isDef(factory.loadingComp)) {
          return factory.loadingComp;
        }

        if (isDef(factory.contexts)) {
          // already pending
          factory.contexts.push(context);
        } else {
          var contexts = factory.contexts = [context];
          var sync = true;

          var forceRender = function forceRender() {
            for (var i = 0, l = contexts.length; i < l; i++) {
              contexts[i].$forceUpdate();
            }
          };

          var resolve = once(function (res) {
            // cache resolved
            factory.resolved = ensureCtor(res, baseCtor);
            // invoke callbacks only if this is not a synchronous resolve
            // (async resolves are shimmed as synchronous during SSR)
            if (!sync) {
              forceRender();
            }
          });

          var reject = once(function (reason) {
            "production" !== 'production' && warn("Failed to resolve async component: " + String(factory) + (reason ? "\nReason: " + reason : ''));
            if (isDef(factory.errorComp)) {
              factory.error = true;
              forceRender();
            }
          });

          var res = factory(resolve, reject);

          if (isObject(res)) {
            if (typeof res.then === 'function') {
              // () => Promise
              if (isUndef(factory.resolved)) {
                res.then(resolve, reject);
              }
            } else if (isDef(res.component) && typeof res.component.then === 'function') {
              res.component.then(resolve, reject);

              if (isDef(res.error)) {
                factory.errorComp = ensureCtor(res.error, baseCtor);
              }

              if (isDef(res.loading)) {
                factory.loadingComp = ensureCtor(res.loading, baseCtor);
                if (res.delay === 0) {
                  factory.loading = true;
                } else {
                  setTimeout(function () {
                    if (isUndef(factory.resolved) && isUndef(factory.error)) {
                      factory.loading = true;
                      forceRender();
                    }
                  }, res.delay || 200);
                }
              }

              if (isDef(res.timeout)) {
                setTimeout(function () {
                  if (isUndef(factory.resolved)) {
                    reject(null);
                  }
                }, res.timeout);
              }
            }
          }

          sync = false;
          // return in case resolved synchronously
          return factory.loading ? factory.loadingComp : factory.resolved;
        }
      }

      /*  */

      function getFirstComponentChild(children) {
        if (Array.isArray(children)) {
          for (var i = 0; i < children.length; i++) {
            var c = children[i];
            if (isDef(c) && isDef(c.componentOptions)) {
              return c;
            }
          }
        }
      }

      /*  */

      /*  */

      function initEvents(vm) {
        vm._events = Object.create(null);
        vm._hasHookEvent = false;
        // init parent attached events
        var listeners = vm.$options._parentListeners;
        if (listeners) {
          updateComponentListeners(vm, listeners);
        }
      }

      var target;

      function add(event, fn, once$$1) {
        if (once$$1) {
          target.$once(event, fn);
        } else {
          target.$on(event, fn);
        }
      }

      function remove$1(event, fn) {
        target.$off(event, fn);
      }

      function updateComponentListeners(vm, listeners, oldListeners) {
        target = vm;
        updateListeners(listeners, oldListeners || {}, add, remove$1, vm);
      }

      function eventsMixin(Vue) {
        var hookRE = /^hook:/;
        Vue.prototype.$on = function (event, fn) {
          var this$1 = this;

          var vm = this;
          if (Array.isArray(event)) {
            for (var i = 0, l = event.length; i < l; i++) {
              this$1.$on(event[i], fn);
            }
          } else {
            (vm._events[event] || (vm._events[event] = [])).push(fn);
            // optimize hook:event cost by using a boolean flag marked at registration
            // instead of a hash lookup
            if (hookRE.test(event)) {
              vm._hasHookEvent = true;
            }
          }
          return vm;
        };

        Vue.prototype.$once = function (event, fn) {
          var vm = this;
          function on() {
            vm.$off(event, on);
            fn.apply(vm, arguments);
          }
          on.fn = fn;
          vm.$on(event, on);
          return vm;
        };

        Vue.prototype.$off = function (event, fn) {
          var this$1 = this;

          var vm = this;
          // all
          if (!arguments.length) {
            vm._events = Object.create(null);
            return vm;
          }
          // array of events
          if (Array.isArray(event)) {
            for (var i$1 = 0, l = event.length; i$1 < l; i$1++) {
              this$1.$off(event[i$1], fn);
            }
            return vm;
          }
          // specific event
          var cbs = vm._events[event];
          if (!cbs) {
            return vm;
          }
          if (arguments.length === 1) {
            vm._events[event] = null;
            return vm;
          }
          // specific handler
          var cb;
          var i = cbs.length;
          while (i--) {
            cb = cbs[i];
            if (cb === fn || cb.fn === fn) {
              cbs.splice(i, 1);
              break;
            }
          }
          return vm;
        };

        Vue.prototype.$emit = function (event) {
          var vm = this;
          var cbs = vm._events[event];
          if (cbs) {
            cbs = cbs.length > 1 ? toArray(cbs) : cbs;
            var args = toArray(arguments, 1);
            for (var i = 0, l = cbs.length; i < l; i++) {
              try {
                cbs[i].apply(vm, args);
              } catch (e) {
                handleError(e, vm, "event handler for \"" + event + "\"");
              }
            }
          }
          return vm;
        };
      }

      /*  */

      /**
       * Runtime helper for resolving raw children VNodes into a slot object.
       */
      function resolveSlots(children, context) {
        var slots = {};
        if (!children) {
          return slots;
        }
        var defaultSlot = [];
        for (var i = 0, l = children.length; i < l; i++) {
          var child = children[i];
          // named slots should only be respected if the vnode was rendered in the
          // same context.
          if ((child.context === context || child.functionalContext === context) && child.data && child.data.slot != null) {
            var name = child.data.slot;
            var slot = slots[name] || (slots[name] = []);
            if (child.tag === 'template') {
              slot.push.apply(slot, child.children);
            } else {
              slot.push(child);
            }
          } else {
            defaultSlot.push(child);
          }
        }
        // ignore whitespace
        if (!defaultSlot.every(isWhitespace)) {
          slots.default = defaultSlot;
        }
        return slots;
      }

      function isWhitespace(node) {
        return node.isComment || node.text === ' ';
      }

      function resolveScopedSlots(fns, // see flow/vnode
      res) {
        res = res || {};
        for (var i = 0; i < fns.length; i++) {
          if (Array.isArray(fns[i])) {
            resolveScopedSlots(fns[i], res);
          } else {
            res[fns[i].key] = fns[i].fn;
          }
        }
        return res;
      }

      /*  */

      var activeInstance = null;

      function initLifecycle(vm) {
        var options = vm.$options;

        // locate first non-abstract parent
        var parent = options.parent;
        if (parent && !options.abstract) {
          while (parent.$options.abstract && parent.$parent) {
            parent = parent.$parent;
          }
          parent.$children.push(vm);
        }

        vm.$parent = parent;
        vm.$root = parent ? parent.$root : vm;

        vm.$children = [];
        vm.$refs = {};

        vm._watcher = null;
        vm._inactive = null;
        vm._directInactive = false;
        vm._isMounted = false;
        vm._isDestroyed = false;
        vm._isBeingDestroyed = false;
      }

      function lifecycleMixin(Vue) {
        Vue.prototype._update = function (vnode, hydrating) {
          var vm = this;
          if (vm._isMounted) {
            callHook(vm, 'beforeUpdate');
          }
          var prevEl = vm.$el;
          var prevVnode = vm._vnode;
          var prevActiveInstance = activeInstance;
          activeInstance = vm;
          vm._vnode = vnode;
          // Vue.prototype.__patch__ is injected in entry points
          // based on the rendering backend used.
          if (!prevVnode) {
            // initial render
            vm.$el = vm.__patch__(vm.$el, vnode, hydrating, false /* removeOnly */
            , vm.$options._parentElm, vm.$options._refElm);
            // no need for the ref nodes after initial patch
            // this prevents keeping a detached DOM tree in memory (#5851)
            vm.$options._parentElm = vm.$options._refElm = null;
          } else {
            // updates
            vm.$el = vm.__patch__(prevVnode, vnode);
          }
          activeInstance = prevActiveInstance;
          // update __vue__ reference
          if (prevEl) {
            prevEl.__vue__ = null;
          }
          if (vm.$el) {
            vm.$el.__vue__ = vm;
          }
          // if parent is an HOC, update its $el as well
          if (vm.$vnode && vm.$parent && vm.$vnode === vm.$parent._vnode) {
            vm.$parent.$el = vm.$el;
          }
          // updated hook is called by the scheduler to ensure that children are
          // updated in a parent's updated hook.
        };

        Vue.prototype.$forceUpdate = function () {
          var vm = this;
          if (vm._watcher) {
            vm._watcher.update();
          }
        };

        Vue.prototype.$destroy = function () {
          var vm = this;
          if (vm._isBeingDestroyed) {
            return;
          }
          callHook(vm, 'beforeDestroy');
          vm._isBeingDestroyed = true;
          // remove self from parent
          var parent = vm.$parent;
          if (parent && !parent._isBeingDestroyed && !vm.$options.abstract) {
            remove(parent.$children, vm);
          }
          // teardown watchers
          if (vm._watcher) {
            vm._watcher.teardown();
          }
          var i = vm._watchers.length;
          while (i--) {
            vm._watchers[i].teardown();
          }
          // remove reference from data ob
          // frozen object may not have observer.
          if (vm._data.__ob__) {
            vm._data.__ob__.vmCount--;
          }
          // call the last hook...
          vm._isDestroyed = true;
          // invoke destroy hooks on current rendered tree
          vm.__patch__(vm._vnode, null);
          // fire destroyed hook
          callHook(vm, 'destroyed');
          // turn off all instance listeners.
          vm.$off();
          // remove __vue__ reference
          if (vm.$el) {
            vm.$el.__vue__ = null;
          }
        };
      }

      function mountComponent(vm, el, hydrating) {
        vm.$el = el;
        if (!vm.$options.render) {
          vm.$options.render = createEmptyVNode;
        }
        callHook(vm, 'beforeMount');

        var updateComponent;
        /* istanbul ignore if */
        if (false) {
          updateComponent = function updateComponent() {
            var name = vm._name;
            var id = vm._uid;
            var startTag = "vue-perf-start:" + id;
            var endTag = "vue-perf-end:" + id;

            mark(startTag);
            var vnode = vm._render();
            mark(endTag);
            measure(name + " render", startTag, endTag);

            mark(startTag);
            vm._update(vnode, hydrating);
            mark(endTag);
            measure(name + " patch", startTag, endTag);
          };
        } else {
          updateComponent = function updateComponent() {
            vm._update(vm._render(), hydrating);
          };
        }

        vm._watcher = new Watcher(vm, updateComponent, noop);
        hydrating = false;

        // manually mounted instance, call mounted on self
        // mounted is called for render-created child components in its inserted hook
        if (vm.$vnode == null) {
          vm._isMounted = true;
          callHook(vm, 'mounted');
        }
        return vm;
      }

      function updateChildComponent(vm, propsData, listeners, parentVnode, renderChildren) {
        var hasChildren = !!(renderChildren || // has new static slots
        vm.$options._renderChildren || // has old static slots
        parentVnode.data.scopedSlots || // has new scoped slots
        vm.$scopedSlots !== emptyObject // has old scoped slots
        );

        vm.$options._parentVnode = parentVnode;
        vm.$vnode = parentVnode; // update vm's placeholder node without re-render

        if (vm._vnode) {
          // update child tree's parent
          vm._vnode.parent = parentVnode;
        }
        vm.$options._renderChildren = renderChildren;

        // update $attrs and $listensers hash
        // these are also reactive so they may trigger child update if the child
        // used them during render
        vm.$attrs = parentVnode.data && parentVnode.data.attrs;
        vm.$listeners = listeners;

        // update props
        if (propsData && vm.$options.props) {
          observerState.shouldConvert = false;
          var props = vm._props;
          var propKeys = vm.$options._propKeys || [];
          for (var i = 0; i < propKeys.length; i++) {
            var key = propKeys[i];
            props[key] = validateProp(key, vm.$options.props, propsData, vm);
          }
          observerState.shouldConvert = true;
          // keep a copy of raw propsData
          vm.$options.propsData = propsData;
        }

        // update listeners
        if (listeners) {
          var oldListeners = vm.$options._parentListeners;
          vm.$options._parentListeners = listeners;
          updateComponentListeners(vm, listeners, oldListeners);
        }
        // resolve slots + force update if has children
        if (hasChildren) {
          vm.$slots = resolveSlots(renderChildren, parentVnode.context);
          vm.$forceUpdate();
        }
      }

      function isInInactiveTree(vm) {
        while (vm && (vm = vm.$parent)) {
          if (vm._inactive) {
            return true;
          }
        }
        return false;
      }

      function activateChildComponent(vm, direct) {
        if (direct) {
          vm._directInactive = false;
          if (isInInactiveTree(vm)) {
            return;
          }
        } else if (vm._directInactive) {
          return;
        }
        if (vm._inactive || vm._inactive === null) {
          vm._inactive = false;
          for (var i = 0; i < vm.$children.length; i++) {
            activateChildComponent(vm.$children[i]);
          }
          callHook(vm, 'activated');
        }
      }

      function deactivateChildComponent(vm, direct) {
        if (direct) {
          vm._directInactive = true;
          if (isInInactiveTree(vm)) {
            return;
          }
        }
        if (!vm._inactive) {
          vm._inactive = true;
          for (var i = 0; i < vm.$children.length; i++) {
            deactivateChildComponent(vm.$children[i]);
          }
          callHook(vm, 'deactivated');
        }
      }

      function callHook(vm, hook) {
        var handlers = vm.$options[hook];
        if (handlers) {
          for (var i = 0, j = handlers.length; i < j; i++) {
            try {
              handlers[i].call(vm);
            } catch (e) {
              handleError(e, vm, hook + " hook");
            }
          }
        }
        if (vm._hasHookEvent) {
          vm.$emit('hook:' + hook);
        }
      }

      /*  */

      var MAX_UPDATE_COUNT = 100;

      var queue = [];
      var activatedChildren = [];
      var has = {};
      var circular = {};
      var waiting = false;
      var flushing = false;
      var index = 0;

      /**
       * Reset the scheduler's state.
       */
      function resetSchedulerState() {
        index = queue.length = activatedChildren.length = 0;
        has = {};
        waiting = flushing = false;
      }

      /**
       * Flush both queues and run the watchers.
       */
      function flushSchedulerQueue() {
        flushing = true;
        var watcher, id;

        // Sort queue before flush.
        // This ensures that:
        // 1. Components are updated from parent to child. (because parent is always
        //    created before the child)
        // 2. A component's user watchers are run before its render watcher (because
        //    user watchers are created before the render watcher)
        // 3. If a component is destroyed during a parent component's watcher run,
        //    its watchers can be skipped.
        queue.sort(function (a, b) {
          return a.id - b.id;
        });

        // do not cache length because more watchers might be pushed
        // as we run existing watchers
        for (index = 0; index < queue.length; index++) {
          watcher = queue[index];
          id = watcher.id;
          has[id] = null;
          watcher.run();
          // in dev build, check and stop circular updates.
          if (false) {
            circular[id] = (circular[id] || 0) + 1;
            if (circular[id] > MAX_UPDATE_COUNT) {
              warn('You may have an infinite update loop ' + (watcher.user ? "in watcher with expression \"" + watcher.expression + "\"" : "in a component render function."), watcher.vm);
              break;
            }
          }
        }

        // keep copies of post queues before resetting state
        var activatedQueue = activatedChildren.slice();
        var updatedQueue = queue.slice();

        resetSchedulerState();

        // call component updated and activated hooks
        callActivatedHooks(activatedQueue);
        callUpdatedHooks(updatedQueue);

        // devtool hook
        /* istanbul ignore if */
        if (devtools && config.devtools) {
          devtools.emit('flush');
        }
      }

      function callUpdatedHooks(queue) {
        var i = queue.length;
        while (i--) {
          var watcher = queue[i];
          var vm = watcher.vm;
          if (vm._watcher === watcher && vm._isMounted) {
            callHook(vm, 'updated');
          }
        }
      }

      /**
       * Queue a kept-alive component that was activated during patch.
       * The queue will be processed after the entire tree has been patched.
       */
      function queueActivatedComponent(vm) {
        // setting _inactive to false here so that a render function can
        // rely on checking whether it's in an inactive tree (e.g. router-view)
        vm._inactive = false;
        activatedChildren.push(vm);
      }

      function callActivatedHooks(queue) {
        for (var i = 0; i < queue.length; i++) {
          queue[i]._inactive = true;
          activateChildComponent(queue[i], true /* true */);
        }
      }

      /**
       * Push a watcher into the watcher queue.
       * Jobs with duplicate IDs will be skipped unless it's
       * pushed when the queue is being flushed.
       */
      function queueWatcher(watcher) {
        var id = watcher.id;
        if (has[id] == null) {
          has[id] = true;
          if (!flushing) {
            queue.push(watcher);
          } else {
            // if already flushing, splice the watcher based on its id
            // if already past its id, it will be run next immediately.
            var i = queue.length - 1;
            while (i > index && queue[i].id > watcher.id) {
              i--;
            }
            queue.splice(i + 1, 0, watcher);
          }
          // queue the flush
          if (!waiting) {
            waiting = true;
            nextTick(flushSchedulerQueue);
          }
        }
      }

      /*  */

      var uid$2 = 0;

      /**
       * A watcher parses an expression, collects dependencies,
       * and fires callback when the expression value changes.
       * This is used for both the $watch() api and directives.
       */
      var Watcher = function Watcher(vm, expOrFn, cb, options) {
        this.vm = vm;
        vm._watchers.push(this);
        // options
        if (options) {
          this.deep = !!options.deep;
          this.user = !!options.user;
          this.lazy = !!options.lazy;
          this.sync = !!options.sync;
        } else {
          this.deep = this.user = this.lazy = this.sync = false;
        }
        this.cb = cb;
        this.id = ++uid$2; // uid for batching
        this.active = true;
        this.dirty = this.lazy; // for lazy watchers
        this.deps = [];
        this.newDeps = [];
        this.depIds = new _Set();
        this.newDepIds = new _Set();
        this.expression = '';
        // parse expression for getter
        if (typeof expOrFn === 'function') {
          this.getter = expOrFn;
        } else {
          this.getter = parsePath(expOrFn);
          if (!this.getter) {
            this.getter = function () {};
            "production" !== 'production' && warn("Failed watching path: \"" + expOrFn + "\" " + 'Watcher only accepts simple dot-delimited paths. ' + 'For full control, use a function instead.', vm);
          }
        }
        this.value = this.lazy ? undefined : this.get();
      };

      /**
       * Evaluate the getter, and re-collect dependencies.
       */
      Watcher.prototype.get = function get() {
        pushTarget(this);
        var value;
        var vm = this.vm;
        try {
          value = this.getter.call(vm, vm);
        } catch (e) {
          if (this.user) {
            handleError(e, vm, "getter for watcher \"" + this.expression + "\"");
          } else {
            throw e;
          }
        } finally {
          // "touch" every property so they are all tracked as
          // dependencies for deep watching
          if (this.deep) {
            traverse(value);
          }
          popTarget();
          this.cleanupDeps();
        }
        return value;
      };

      /**
       * Add a dependency to this directive.
       */
      Watcher.prototype.addDep = function addDep(dep) {
        var id = dep.id;
        if (!this.newDepIds.has(id)) {
          this.newDepIds.add(id);
          this.newDeps.push(dep);
          if (!this.depIds.has(id)) {
            dep.addSub(this);
          }
        }
      };

      /**
       * Clean up for dependency collection.
       */
      Watcher.prototype.cleanupDeps = function cleanupDeps() {
        var this$1 = this;

        var i = this.deps.length;
        while (i--) {
          var dep = this$1.deps[i];
          if (!this$1.newDepIds.has(dep.id)) {
            dep.removeSub(this$1);
          }
        }
        var tmp = this.depIds;
        this.depIds = this.newDepIds;
        this.newDepIds = tmp;
        this.newDepIds.clear();
        tmp = this.deps;
        this.deps = this.newDeps;
        this.newDeps = tmp;
        this.newDeps.length = 0;
      };

      /**
       * Subscriber interface.
       * Will be called when a dependency changes.
       */
      Watcher.prototype.update = function update() {
        /* istanbul ignore else */
        if (this.lazy) {
          this.dirty = true;
        } else if (this.sync) {
          this.run();
        } else {
          queueWatcher(this);
        }
      };

      /**
       * Scheduler job interface.
       * Will be called by the scheduler.
       */
      Watcher.prototype.run = function run() {
        if (this.active) {
          var value = this.get();
          if (value !== this.value ||
          // Deep watchers and watchers on Object/Arrays should fire even
          // when the value is the same, because the value may
          // have mutated.
          isObject(value) || this.deep) {
            // set new value
            var oldValue = this.value;
            this.value = value;
            if (this.user) {
              try {
                this.cb.call(this.vm, value, oldValue);
              } catch (e) {
                handleError(e, this.vm, "callback for watcher \"" + this.expression + "\"");
              }
            } else {
              this.cb.call(this.vm, value, oldValue);
            }
          }
        }
      };

      /**
       * Evaluate the value of the watcher.
       * This only gets called for lazy watchers.
       */
      Watcher.prototype.evaluate = function evaluate() {
        this.value = this.get();
        this.dirty = false;
      };

      /**
       * Depend on all deps collected by this watcher.
       */
      Watcher.prototype.depend = function depend() {
        var this$1 = this;

        var i = this.deps.length;
        while (i--) {
          this$1.deps[i].depend();
        }
      };

      /**
       * Remove self from all dependencies' subscriber list.
       */
      Watcher.prototype.teardown = function teardown() {
        var this$1 = this;

        if (this.active) {
          // remove self from vm's watcher list
          // this is a somewhat expensive operation so we skip it
          // if the vm is being destroyed.
          if (!this.vm._isBeingDestroyed) {
            remove(this.vm._watchers, this);
          }
          var i = this.deps.length;
          while (i--) {
            this$1.deps[i].removeSub(this$1);
          }
          this.active = false;
        }
      };

      /**
       * Recursively traverse an object to evoke all converted
       * getters, so that every nested property inside the object
       * is collected as a "deep" dependency.
       */
      var seenObjects = new _Set();
      function traverse(val) {
        seenObjects.clear();
        _traverse(val, seenObjects);
      }

      function _traverse(val, seen) {
        var i, keys;
        var isA = Array.isArray(val);
        if (!isA && !isObject(val) || !Object.isExtensible(val)) {
          return;
        }
        if (val.__ob__) {
          var depId = val.__ob__.dep.id;
          if (seen.has(depId)) {
            return;
          }
          seen.add(depId);
        }
        if (isA) {
          i = val.length;
          while (i--) {
            _traverse(val[i], seen);
          }
        } else {
          keys = Object.keys(val);
          i = keys.length;
          while (i--) {
            _traverse(val[keys[i]], seen);
          }
        }
      }

      /*  */

      var sharedPropertyDefinition = {
        enumerable: true,
        configurable: true,
        get: noop,
        set: noop
      };

      function proxy(target, sourceKey, key) {
        sharedPropertyDefinition.get = function proxyGetter() {
          return this[sourceKey][key];
        };
        sharedPropertyDefinition.set = function proxySetter(val) {
          this[sourceKey][key] = val;
        };
        Object.defineProperty(target, key, sharedPropertyDefinition);
      }

      function initState(vm) {
        vm._watchers = [];
        var opts = vm.$options;
        if (opts.props) {
          initProps(vm, opts.props);
        }
        if (opts.methods) {
          initMethods(vm, opts.methods);
        }
        if (opts.data) {
          initData(vm);
        } else {
          observe(vm._data = {}, true /* asRootData */);
        }
        if (opts.computed) {
          initComputed(vm, opts.computed);
        }
        if (opts.watch && opts.watch !== nativeWatch) {
          initWatch(vm, opts.watch);
        }
      }

      function checkOptionType(vm, name) {
        var option = vm.$options[name];
        if (!isPlainObject(option)) {
          warn("component option \"" + name + "\" should be an object.", vm);
        }
      }

      function initProps(vm, propsOptions) {
        var propsData = vm.$options.propsData || {};
        var props = vm._props = {};
        // cache prop keys so that future props updates can iterate using Array
        // instead of dynamic object key enumeration.
        var keys = vm.$options._propKeys = [];
        var isRoot = !vm.$parent;
        // root instance props should be converted
        observerState.shouldConvert = isRoot;
        var loop = function loop(key) {
          keys.push(key);
          var value = validateProp(key, propsOptions, propsData, vm);
          /* istanbul ignore else */
          {
            defineReactive$$1(props, key, value);
          }
          // static props are already proxied on the component's prototype
          // during Vue.extend(). We only need to proxy props defined at
          // instantiation here.
          if (!(key in vm)) {
            proxy(vm, "_props", key);
          }
        };

        for (var key in propsOptions) {
          loop(key);
        }observerState.shouldConvert = true;
      }

      function initData(vm) {
        var data = vm.$options.data;
        data = vm._data = typeof data === 'function' ? getData(data, vm) : data || {};
        if (!isPlainObject(data)) {
          data = {};
          "production" !== 'production' && warn('data functions should return an object:\n' + 'https://vuejs.org/v2/guide/components.html#data-Must-Be-a-Function', vm);
        }
        // proxy data on instance
        var keys = Object.keys(data);
        var props = vm.$options.props;
        var methods = vm.$options.methods;
        var i = keys.length;
        while (i--) {
          var key = keys[i];
          if (props && hasOwn(props, key)) {
            "production" !== 'production' && warn("The data property \"" + key + "\" is already declared as a prop. " + "Use prop default value instead.", vm);
          } else if (!isReserved(key)) {
            proxy(vm, "_data", key);
          }
        }
        // observe data
        observe(data, true /* asRootData */);
      }

      function getData(data, vm) {
        try {
          return data.call(vm);
        } catch (e) {
          handleError(e, vm, "data()");
          return {};
        }
      }

      var computedWatcherOptions = { lazy: true };

      function initComputed(vm, computed) {
        "production" !== 'production' && checkOptionType(vm, 'computed');
        var watchers = vm._computedWatchers = Object.create(null);

        for (var key in computed) {
          var userDef = computed[key];
          var getter = typeof userDef === 'function' ? userDef : userDef.get;
          watchers[key] = new Watcher(vm, getter, noop, computedWatcherOptions);

          // component-defined computed properties are already defined on the
          // component prototype. We only need to define computed properties defined
          // at instantiation here.
          if (!(key in vm)) {
            defineComputed(vm, key, userDef);
          } else {}
        }
      }

      function defineComputed(target, key, userDef) {
        if (typeof userDef === 'function') {
          sharedPropertyDefinition.get = createComputedGetter(key);
          sharedPropertyDefinition.set = noop;
        } else {
          sharedPropertyDefinition.get = userDef.get ? userDef.cache !== false ? createComputedGetter(key) : userDef.get : noop;
          sharedPropertyDefinition.set = userDef.set ? userDef.set : noop;
        }
        Object.defineProperty(target, key, sharedPropertyDefinition);
      }

      function createComputedGetter(key) {
        return function computedGetter() {
          var watcher = this._computedWatchers && this._computedWatchers[key];
          if (watcher) {
            if (watcher.dirty) {
              watcher.evaluate();
            }
            if (Dep.target) {
              watcher.depend();
            }
            return watcher.value;
          }
        };
      }

      function initMethods(vm, methods) {
        "production" !== 'production' && checkOptionType(vm, 'methods');
        var props = vm.$options.props;
        for (var key in methods) {
          vm[key] = methods[key] == null ? noop : bind(methods[key], vm);
        }
      }

      function initWatch(vm, watch) {
        "production" !== 'production' && checkOptionType(vm, 'watch');
        for (var key in watch) {
          var handler = watch[key];
          if (Array.isArray(handler)) {
            for (var i = 0; i < handler.length; i++) {
              createWatcher(vm, key, handler[i]);
            }
          } else {
            createWatcher(vm, key, handler);
          }
        }
      }

      function createWatcher(vm, keyOrFn, handler, options) {
        if (isPlainObject(handler)) {
          options = handler;
          handler = handler.handler;
        }
        if (typeof handler === 'string') {
          handler = vm[handler];
        }
        return vm.$watch(keyOrFn, handler, options);
      }

      function stateMixin(Vue) {
        // flow somehow has problems with directly declared definition object
        // when using Object.defineProperty, so we have to procedurally build up
        // the object here.
        var dataDef = {};
        dataDef.get = function () {
          return this._data;
        };
        var propsDef = {};
        propsDef.get = function () {
          return this._props;
        };
        Object.defineProperty(Vue.prototype, '$data', dataDef);
        Object.defineProperty(Vue.prototype, '$props', propsDef);

        Vue.prototype.$set = set;
        Vue.prototype.$delete = del;

        Vue.prototype.$watch = function (expOrFn, cb, options) {
          var vm = this;
          if (isPlainObject(cb)) {
            return createWatcher(vm, expOrFn, cb, options);
          }
          options = options || {};
          options.user = true;
          var watcher = new Watcher(vm, expOrFn, cb, options);
          if (options.immediate) {
            cb.call(vm, watcher.value);
          }
          return function unwatchFn() {
            watcher.teardown();
          };
        };
      }

      /*  */

      function initProvide(vm) {
        var provide = vm.$options.provide;
        if (provide) {
          vm._provided = typeof provide === 'function' ? provide.call(vm) : provide;
        }
      }

      function initInjections(vm) {
        var result = resolveInject(vm.$options.inject, vm);
        if (result) {
          observerState.shouldConvert = false;
          Object.keys(result).forEach(function (key) {
            /* istanbul ignore else */
            {
              defineReactive$$1(vm, key, result[key]);
            }
          });
          observerState.shouldConvert = true;
        }
      }

      function resolveInject(inject, vm) {
        if (inject) {
          // inject is :any because flow is not smart enough to figure out cached
          var result = Object.create(null);
          var keys = hasSymbol ? Reflect.ownKeys(inject) : Object.keys(inject);

          for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var provideKey = inject[key];
            var source = vm;
            while (source) {
              if (source._provided && provideKey in source._provided) {
                result[key] = source._provided[provideKey];
                break;
              }
              source = source.$parent;
            }
            if (false) {
              warn("Injection \"" + key + "\" not found", vm);
            }
          }
          return result;
        }
      }

      /*  */

      function createFunctionalComponent(Ctor, propsData, data, context, children) {
        var props = {};
        var propOptions = Ctor.options.props;
        if (isDef(propOptions)) {
          for (var key in propOptions) {
            props[key] = validateProp(key, propOptions, propsData || {});
          }
        } else {
          if (isDef(data.attrs)) {
            mergeProps(props, data.attrs);
          }
          if (isDef(data.props)) {
            mergeProps(props, data.props);
          }
        }
        // ensure the createElement function in functional components
        // gets a unique context - this is necessary for correct named slot check
        var _context = Object.create(context);
        var h = function h(a, b, c, d) {
          return createElement(_context, a, b, c, d, true);
        };
        var vnode = Ctor.options.render.call(null, h, {
          data: data,
          props: props,
          children: children,
          parent: context,
          listeners: data.on || {},
          injections: resolveInject(Ctor.options.inject, context),
          slots: function slots() {
            return resolveSlots(children, context);
          }
        });
        if (vnode instanceof VNode) {
          vnode.functionalContext = context;
          vnode.functionalOptions = Ctor.options;
          if (data.slot) {
            (vnode.data || (vnode.data = {})).slot = data.slot;
          }
        }
        return vnode;
      }

      function mergeProps(to, from) {
        for (var key in from) {
          to[camelize(key)] = from[key];
        }
      }

      /*  */

      // hooks to be invoked on component VNodes during patch
      var componentVNodeHooks = {
        init: function init(vnode, hydrating, parentElm, refElm) {
          if (!vnode.componentInstance || vnode.componentInstance._isDestroyed) {
            var child = vnode.componentInstance = createComponentInstanceForVnode(vnode, activeInstance, parentElm, refElm);
            child.$mount(hydrating ? vnode.elm : undefined, hydrating);
          } else if (vnode.data.keepAlive) {
            // kept-alive components, treat as a patch
            var mountedNode = vnode; // work around flow
            componentVNodeHooks.prepatch(mountedNode, mountedNode);
          }
        },

        prepatch: function prepatch(oldVnode, vnode) {
          var options = vnode.componentOptions;
          var child = vnode.componentInstance = oldVnode.componentInstance;
          updateChildComponent(child, options.propsData, // updated props
          options.listeners, // updated listeners
          vnode, // new parent vnode
          options.children // new children
          );
        },

        insert: function insert(vnode) {
          var context = vnode.context;
          var componentInstance = vnode.componentInstance;

          if (!componentInstance._isMounted) {
            componentInstance._isMounted = true;
            callHook(componentInstance, 'mounted');
          }
          if (vnode.data.keepAlive) {
            if (context._isMounted) {
              // vue-router#1212
              // During updates, a kept-alive component's child components may
              // change, so directly walking the tree here may call activated hooks
              // on incorrect children. Instead we push them into a queue which will
              // be processed after the whole patch process ended.
              queueActivatedComponent(componentInstance);
            } else {
              activateChildComponent(componentInstance, true /* direct */);
            }
          }
        },

        destroy: function destroy(vnode) {
          var componentInstance = vnode.componentInstance;
          if (!componentInstance._isDestroyed) {
            if (!vnode.data.keepAlive) {
              componentInstance.$destroy();
            } else {
              deactivateChildComponent(componentInstance, true /* direct */);
            }
          }
        }
      };

      var hooksToMerge = Object.keys(componentVNodeHooks);

      function createComponent(Ctor, data, context, children, tag) {
        if (isUndef(Ctor)) {
          return;
        }

        var baseCtor = context.$options._base;

        // plain options object: turn it into a constructor
        if (isObject(Ctor)) {
          Ctor = baseCtor.extend(Ctor);
        }

        // if at this stage it's not a constructor or an async component factory,
        // reject.
        if (typeof Ctor !== 'function') {
          return;
        }

        // async component
        var asyncFactory;
        if (isUndef(Ctor.cid)) {
          asyncFactory = Ctor;
          Ctor = resolveAsyncComponent(asyncFactory, baseCtor, context);
          if (Ctor === undefined) {
            // return a placeholder node for async component, which is rendered
            // as a comment node but preserves all the raw information for the node.
            // the information will be used for async server-rendering and hydration.
            return createAsyncPlaceholder(asyncFactory, data, context, children, tag);
          }
        }

        data = data || {};

        // resolve constructor options in case global mixins are applied after
        // component constructor creation
        resolveConstructorOptions(Ctor);

        // transform component v-model data into props & events
        if (isDef(data.model)) {
          transformModel(Ctor.options, data);
        }

        // extract props
        var propsData = extractPropsFromVNodeData(data, Ctor, tag);

        // functional component
        if (isTrue(Ctor.options.functional)) {
          return createFunctionalComponent(Ctor, propsData, data, context, children);
        }

        // keep listeners
        var listeners = data.on;

        if (isTrue(Ctor.options.abstract)) {
          // abstract components do not keep anything
          // other than props & listeners & slot

          // work around flow
          var slot = data.slot;
          data = {};
          if (slot) {
            data.slot = slot;
          }
        }

        // merge component management hooks onto the placeholder node
        mergeHooks(data);

        // return a placeholder vnode
        var name = Ctor.options.name || tag;
        var vnode = new VNode("vue-component-" + Ctor.cid + (name ? "-" + name : ''), data, undefined, undefined, undefined, context, { Ctor: Ctor, propsData: propsData, listeners: listeners, tag: tag, children: children }, asyncFactory);
        return vnode;
      }

      function createComponentInstanceForVnode(vnode, // we know it's MountedComponentVNode but flow doesn't
      parent, // activeInstance in lifecycle state
      parentElm, refElm) {
        var vnodeComponentOptions = vnode.componentOptions;
        var options = {
          _isComponent: true,
          parent: parent,
          propsData: vnodeComponentOptions.propsData,
          _componentTag: vnodeComponentOptions.tag,
          _parentVnode: vnode,
          _parentListeners: vnodeComponentOptions.listeners,
          _renderChildren: vnodeComponentOptions.children,
          _parentElm: parentElm || null,
          _refElm: refElm || null
        };
        // check inline-template render functions
        var inlineTemplate = vnode.data.inlineTemplate;
        if (isDef(inlineTemplate)) {
          options.render = inlineTemplate.render;
          options.staticRenderFns = inlineTemplate.staticRenderFns;
        }
        return new vnodeComponentOptions.Ctor(options);
      }

      function mergeHooks(data) {
        if (!data.hook) {
          data.hook = {};
        }
        for (var i = 0; i < hooksToMerge.length; i++) {
          var key = hooksToMerge[i];
          var fromParent = data.hook[key];
          var ours = componentVNodeHooks[key];
          data.hook[key] = fromParent ? mergeHook$1(ours, fromParent) : ours;
        }
      }

      function mergeHook$1(one, two) {
        return function (a, b, c, d) {
          one(a, b, c, d);
          two(a, b, c, d);
        };
      }

      // transform component v-model info (value and callback) into
      // prop and event handler respectively.
      function transformModel(options, data) {
        var prop = options.model && options.model.prop || 'value';
        var event = options.model && options.model.event || 'input';(data.props || (data.props = {}))[prop] = data.model.value;
        var on = data.on || (data.on = {});
        if (isDef(on[event])) {
          on[event] = [data.model.callback].concat(on[event]);
        } else {
          on[event] = data.model.callback;
        }
      }

      /*  */

      var SIMPLE_NORMALIZE = 1;
      var ALWAYS_NORMALIZE = 2;

      // wrapper function for providing a more flexible interface
      // without getting yelled at by flow
      function createElement(context, tag, data, children, normalizationType, alwaysNormalize) {
        if (Array.isArray(data) || isPrimitive(data)) {
          normalizationType = children;
          children = data;
          data = undefined;
        }
        if (isTrue(alwaysNormalize)) {
          normalizationType = ALWAYS_NORMALIZE;
        }
        return _createElement(context, tag, data, children, normalizationType);
      }

      function _createElement(context, tag, data, children, normalizationType) {
        if (isDef(data) && isDef(data.__ob__)) {
          "production" !== 'production' && warn("Avoid using observed data object as vnode data: " + JSON.stringify(data) + "\n" + 'Always create fresh vnode data objects in each render!', context);
          return createEmptyVNode();
        }
        // object syntax in v-bind
        if (isDef(data) && isDef(data.is)) {
          tag = data.is;
        }
        if (!tag) {
          // in case of component :is set to falsy value
          return createEmptyVNode();
        }
        // warn against non-primitive key
        if (false) {
          warn('Avoid using non-primitive value as key, ' + 'use string/number value instead.', context);
        }
        // support single function children as default scoped slot
        if (Array.isArray(children) && typeof children[0] === 'function') {
          data = data || {};
          data.scopedSlots = { default: children[0] };
          children.length = 0;
        }
        if (normalizationType === ALWAYS_NORMALIZE) {
          children = normalizeChildren(children);
        } else if (normalizationType === SIMPLE_NORMALIZE) {
          children = simpleNormalizeChildren(children);
        }
        var vnode, ns;
        if (typeof tag === 'string') {
          var Ctor;
          ns = config.getTagNamespace(tag);
          if (config.isReservedTag(tag)) {
            // platform built-in elements
            vnode = new VNode(config.parsePlatformTagName(tag), data, children, undefined, undefined, context);
          } else if (isDef(Ctor = resolveAsset(context.$options, 'components', tag))) {
            // component
            vnode = createComponent(Ctor, data, context, children, tag);
          } else {
            // unknown or unlisted namespaced elements
            // check at runtime because it may get assigned a namespace when its
            // parent normalizes children
            vnode = new VNode(tag, data, children, undefined, undefined, context);
          }
        } else {
          // direct component options / constructor
          vnode = createComponent(tag, data, context, children);
        }
        if (isDef(vnode)) {
          if (ns) {
            applyNS(vnode, ns);
          }
          return vnode;
        } else {
          return createEmptyVNode();
        }
      }

      function applyNS(vnode, ns) {
        vnode.ns = ns;
        if (vnode.tag === 'foreignObject') {
          // use default namespace inside foreignObject
          return;
        }
        if (isDef(vnode.children)) {
          for (var i = 0, l = vnode.children.length; i < l; i++) {
            var child = vnode.children[i];
            if (isDef(child.tag) && isUndef(child.ns)) {
              applyNS(child, ns);
            }
          }
        }
      }

      /*  */

      /**
       * Runtime helper for rendering v-for lists.
       */
      function renderList(val, render) {
        var ret, i, l, keys, key;
        if (Array.isArray(val) || typeof val === 'string') {
          ret = new Array(val.length);
          for (i = 0, l = val.length; i < l; i++) {
            ret[i] = render(val[i], i);
          }
        } else if (typeof val === 'number') {
          ret = new Array(val);
          for (i = 0; i < val; i++) {
            ret[i] = render(i + 1, i);
          }
        } else if (isObject(val)) {
          keys = Object.keys(val);
          ret = new Array(keys.length);
          for (i = 0, l = keys.length; i < l; i++) {
            key = keys[i];
            ret[i] = render(val[key], key, i);
          }
        }
        if (isDef(ret)) {
          ret._isVList = true;
        }
        return ret;
      }

      /*  */

      /**
       * Runtime helper for rendering <slot>
       */
      function renderSlot(name, fallback, props, bindObject) {
        var scopedSlotFn = this.$scopedSlots[name];
        if (scopedSlotFn) {
          // scoped slot
          props = props || {};
          if (bindObject) {
            props = extend(extend({}, bindObject), props);
          }
          return scopedSlotFn(props) || fallback;
        } else {
          var slotNodes = this.$slots[name];
          // warn duplicate slot usage
          if (slotNodes && "production" !== 'production') {
            slotNodes._rendered && warn("Duplicate presence of slot \"" + name + "\" found in the same render tree " + "- this will likely cause render errors.", this);
            slotNodes._rendered = true;
          }
          return slotNodes || fallback;
        }
      }

      /*  */

      /**
       * Runtime helper for resolving filters
       */
      function resolveFilter(id) {
        return resolveAsset(this.$options, 'filters', id, true) || identity;
      }

      /*  */

      /**
       * Runtime helper for checking keyCodes from config.
       */
      function checkKeyCodes(eventKeyCode, key, builtInAlias) {
        var keyCodes = config.keyCodes[key] || builtInAlias;
        if (Array.isArray(keyCodes)) {
          return keyCodes.indexOf(eventKeyCode) === -1;
        } else {
          return keyCodes !== eventKeyCode;
        }
      }

      /*  */

      /**
       * Runtime helper for merging v-bind="object" into a VNode's data.
       */
      function bindObjectProps(data, tag, value, asProp, isSync) {
        if (value) {
          if (!isObject(value)) {
            "production" !== 'production' && warn('v-bind without argument expects an Object or Array value', this);
          } else {
            if (Array.isArray(value)) {
              value = toObject(value);
            }
            var hash;
            var loop = function loop(key) {
              if (key === 'class' || key === 'style' || isReservedAttribute(key)) {
                hash = data;
              } else {
                var type = data.attrs && data.attrs.type;
                hash = asProp || config.mustUseProp(tag, type, key) ? data.domProps || (data.domProps = {}) : data.attrs || (data.attrs = {});
              }
              if (!(key in hash)) {
                hash[key] = value[key];

                if (isSync) {
                  var on = data.on || (data.on = {});
                  on["update:" + key] = function ($event) {
                    value[key] = $event;
                  };
                }
              }
            };

            for (var key in value) {
              loop(key);
            }
          }
        }
        return data;
      }

      /*  */

      /**
       * Runtime helper for rendering static trees.
       */
      function renderStatic(index, isInFor) {
        var tree = this._staticTrees[index];
        // if has already-rendered static tree and not inside v-for,
        // we can reuse the same tree by doing a shallow clone.
        if (tree && !isInFor) {
          return Array.isArray(tree) ? cloneVNodes(tree) : cloneVNode(tree);
        }
        // otherwise, render a fresh tree.
        tree = this._staticTrees[index] = this.$options.staticRenderFns[index].call(this._renderProxy);
        markStatic(tree, "__static__" + index, false);
        return tree;
      }

      /**
       * Runtime helper for v-once.
       * Effectively it means marking the node as static with a unique key.
       */
      function markOnce(tree, index, key) {
        markStatic(tree, "__once__" + index + (key ? "_" + key : ""), true);
        return tree;
      }

      function markStatic(tree, key, isOnce) {
        if (Array.isArray(tree)) {
          for (var i = 0; i < tree.length; i++) {
            if (tree[i] && typeof tree[i] !== 'string') {
              markStaticNode(tree[i], key + "_" + i, isOnce);
            }
          }
        } else {
          markStaticNode(tree, key, isOnce);
        }
      }

      function markStaticNode(node, key, isOnce) {
        node.isStatic = true;
        node.key = key;
        node.isOnce = isOnce;
      }

      /*  */

      function bindObjectListeners(data, value) {
        if (value) {
          if (!isPlainObject(value)) {
            "production" !== 'production' && warn('v-on without argument expects an Object value', this);
          } else {
            var on = data.on = data.on ? extend({}, data.on) : {};
            for (var key in value) {
              var existing = on[key];
              var ours = value[key];
              on[key] = existing ? [].concat(ours, existing) : ours;
            }
          }
        }
        return data;
      }

      /*  */

      function initRender(vm) {
        vm._vnode = null; // the root of the child tree
        vm._staticTrees = null;
        var parentVnode = vm.$vnode = vm.$options._parentVnode; // the placeholder node in parent tree
        var renderContext = parentVnode && parentVnode.context;
        vm.$slots = resolveSlots(vm.$options._renderChildren, renderContext);
        vm.$scopedSlots = emptyObject;
        // bind the createElement fn to this instance
        // so that we get proper render context inside it.
        // args order: tag, data, children, normalizationType, alwaysNormalize
        // internal version is used by render functions compiled from templates
        vm._c = function (a, b, c, d) {
          return createElement(vm, a, b, c, d, false);
        };
        // normalization is always applied for the public version, used in
        // user-written render functions.
        vm.$createElement = function (a, b, c, d) {
          return createElement(vm, a, b, c, d, true);
        };

        // $attrs & $listeners are exposed for easier HOC creation.
        // they need to be reactive so that HOCs using them are always updated
        var parentData = parentVnode && parentVnode.data;
        /* istanbul ignore else */
        {
          defineReactive$$1(vm, '$attrs', parentData && parentData.attrs, null, true);
          defineReactive$$1(vm, '$listeners', parentData && parentData.on, null, true);
        }
      }

      function renderMixin(Vue) {
        Vue.prototype.$nextTick = function (fn) {
          return nextTick(fn, this);
        };

        Vue.prototype._render = function () {
          var vm = this;
          var ref = vm.$options;
          var render = ref.render;
          var staticRenderFns = ref.staticRenderFns;
          var _parentVnode = ref._parentVnode;

          if (vm._isMounted) {
            // clone slot nodes on re-renders
            for (var key in vm.$slots) {
              vm.$slots[key] = cloneVNodes(vm.$slots[key]);
            }
          }

          vm.$scopedSlots = _parentVnode && _parentVnode.data.scopedSlots || emptyObject;

          if (staticRenderFns && !vm._staticTrees) {
            vm._staticTrees = [];
          }
          // set parent vnode. this allows render functions to have access
          // to the data on the placeholder node.
          vm.$vnode = _parentVnode;
          // render self
          var vnode;
          try {
            vnode = render.call(vm._renderProxy, vm.$createElement);
          } catch (e) {
            handleError(e, vm, "render function");
            // return error render result,
            // or previous vnode to prevent render error causing blank component
            /* istanbul ignore else */
            {
              vnode = vm._vnode;
            }
          }
          // return empty vnode in case the render function errored out
          if (!(vnode instanceof VNode)) {
            if (false) {
              warn('Multiple root nodes returned from render function. Render function ' + 'should return a single root node.', vm);
            }
            vnode = createEmptyVNode();
          }
          // set parent
          vnode.parent = _parentVnode;
          return vnode;
        };

        // internal render helpers.
        // these are exposed on the instance prototype to reduce generated render
        // code size.
        Vue.prototype._o = markOnce;
        Vue.prototype._n = toNumber;
        Vue.prototype._s = toString;
        Vue.prototype._l = renderList;
        Vue.prototype._t = renderSlot;
        Vue.prototype._q = looseEqual;
        Vue.prototype._i = looseIndexOf;
        Vue.prototype._m = renderStatic;
        Vue.prototype._f = resolveFilter;
        Vue.prototype._k = checkKeyCodes;
        Vue.prototype._b = bindObjectProps;
        Vue.prototype._v = createTextVNode;
        Vue.prototype._e = createEmptyVNode;
        Vue.prototype._u = resolveScopedSlots;
        Vue.prototype._g = bindObjectListeners;
      }

      /*  */

      var uid = 0;

      function initMixin(Vue) {
        Vue.prototype._init = function (options) {
          var vm = this;
          // a uid
          vm._uid = uid++;

          var startTag, endTag;
          /* istanbul ignore if */
          if (false) {
            startTag = "vue-perf-init:" + vm._uid;
            endTag = "vue-perf-end:" + vm._uid;
            mark(startTag);
          }

          // a flag to avoid this being observed
          vm._isVue = true;
          // merge options
          if (options && options._isComponent) {
            // optimize internal component instantiation
            // since dynamic options merging is pretty slow, and none of the
            // internal component options needs special treatment.
            initInternalComponent(vm, options);
          } else {
            vm.$options = mergeOptions(resolveConstructorOptions(vm.constructor), options || {}, vm);
          }
          /* istanbul ignore else */
          {
            vm._renderProxy = vm;
          }
          // expose real self
          vm._self = vm;
          initLifecycle(vm);
          initEvents(vm);
          initRender(vm);
          callHook(vm, 'beforeCreate');
          initInjections(vm); // resolve injections before data/props
          initState(vm);
          initProvide(vm); // resolve provide after data/props
          callHook(vm, 'created');

          /* istanbul ignore if */
          if (false) {
            vm._name = formatComponentName(vm, false);
            mark(endTag);
            measure(vm._name + " init", startTag, endTag);
          }

          if (vm.$options.el) {
            vm.$mount(vm.$options.el);
          }
        };
      }

      function initInternalComponent(vm, options) {
        var opts = vm.$options = Object.create(vm.constructor.options);
        // doing this because it's faster than dynamic enumeration.
        opts.parent = options.parent;
        opts.propsData = options.propsData;
        opts._parentVnode = options._parentVnode;
        opts._parentListeners = options._parentListeners;
        opts._renderChildren = options._renderChildren;
        opts._componentTag = options._componentTag;
        opts._parentElm = options._parentElm;
        opts._refElm = options._refElm;
        if (options.render) {
          opts.render = options.render;
          opts.staticRenderFns = options.staticRenderFns;
        }
      }

      function resolveConstructorOptions(Ctor) {
        var options = Ctor.options;
        if (Ctor.super) {
          var superOptions = resolveConstructorOptions(Ctor.super);
          var cachedSuperOptions = Ctor.superOptions;
          if (superOptions !== cachedSuperOptions) {
            // super option changed,
            // need to resolve new options.
            Ctor.superOptions = superOptions;
            // check if there are any late-modified/attached options (#4976)
            var modifiedOptions = resolveModifiedOptions(Ctor);
            // update base extend options
            if (modifiedOptions) {
              extend(Ctor.extendOptions, modifiedOptions);
            }
            options = Ctor.options = mergeOptions(superOptions, Ctor.extendOptions);
            if (options.name) {
              options.components[options.name] = Ctor;
            }
          }
        }
        return options;
      }

      function resolveModifiedOptions(Ctor) {
        var modified;
        var latest = Ctor.options;
        var extended = Ctor.extendOptions;
        var sealed = Ctor.sealedOptions;
        for (var key in latest) {
          if (latest[key] !== sealed[key]) {
            if (!modified) {
              modified = {};
            }
            modified[key] = dedupe(latest[key], extended[key], sealed[key]);
          }
        }
        return modified;
      }

      function dedupe(latest, extended, sealed) {
        // compare latest and sealed to ensure lifecycle hooks won't be duplicated
        // between merges
        if (Array.isArray(latest)) {
          var res = [];
          sealed = Array.isArray(sealed) ? sealed : [sealed];
          extended = Array.isArray(extended) ? extended : [extended];
          for (var i = 0; i < latest.length; i++) {
            // push original options and not sealed options to exclude duplicated options
            if (extended.indexOf(latest[i]) >= 0 || sealed.indexOf(latest[i]) < 0) {
              res.push(latest[i]);
            }
          }
          return res;
        } else {
          return latest;
        }
      }

      function Vue$3(options) {
        if (false) {
          warn('Vue is a constructor and should be called with the `new` keyword');
        }
        this._init(options);
      }

      initMixin(Vue$3);
      stateMixin(Vue$3);
      eventsMixin(Vue$3);
      lifecycleMixin(Vue$3);
      renderMixin(Vue$3);

      /*  */

      function initUse(Vue) {
        Vue.use = function (plugin) {
          var installedPlugins = this._installedPlugins || (this._installedPlugins = []);
          if (installedPlugins.indexOf(plugin) > -1) {
            return this;
          }

          // additional parameters
          var args = toArray(arguments, 1);
          args.unshift(this);
          if (typeof plugin.install === 'function') {
            plugin.install.apply(plugin, args);
          } else if (typeof plugin === 'function') {
            plugin.apply(null, args);
          }
          installedPlugins.push(plugin);
          return this;
        };
      }

      /*  */

      function initMixin$1(Vue) {
        Vue.mixin = function (mixin) {
          this.options = mergeOptions(this.options, mixin);
          return this;
        };
      }

      /*  */

      function initExtend(Vue) {
        /**
         * Each instance constructor, including Vue, has a unique
         * cid. This enables us to create wrapped "child
         * constructors" for prototypal inheritance and cache them.
         */
        Vue.cid = 0;
        var cid = 1;

        /**
         * Class inheritance
         */
        Vue.extend = function (extendOptions) {
          extendOptions = extendOptions || {};
          var Super = this;
          var SuperId = Super.cid;
          var cachedCtors = extendOptions._Ctor || (extendOptions._Ctor = {});
          if (cachedCtors[SuperId]) {
            return cachedCtors[SuperId];
          }

          var name = extendOptions.name || Super.options.name;
          var Sub = function VueComponent(options) {
            this._init(options);
          };
          Sub.prototype = Object.create(Super.prototype);
          Sub.prototype.constructor = Sub;
          Sub.cid = cid++;
          Sub.options = mergeOptions(Super.options, extendOptions);
          Sub['super'] = Super;

          // For props and computed properties, we define the proxy getters on
          // the Vue instances at extension time, on the extended prototype. This
          // avoids Object.defineProperty calls for each instance created.
          if (Sub.options.props) {
            initProps$1(Sub);
          }
          if (Sub.options.computed) {
            initComputed$1(Sub);
          }

          // allow further extension/mixin/plugin usage
          Sub.extend = Super.extend;
          Sub.mixin = Super.mixin;
          Sub.use = Super.use;

          // create asset registers, so extended classes
          // can have their private assets too.
          ASSET_TYPES.forEach(function (type) {
            Sub[type] = Super[type];
          });
          // enable recursive self-lookup
          if (name) {
            Sub.options.components[name] = Sub;
          }

          // keep a reference to the super options at extension time.
          // later at instantiation we can check if Super's options have
          // been updated.
          Sub.superOptions = Super.options;
          Sub.extendOptions = extendOptions;
          Sub.sealedOptions = extend({}, Sub.options);

          // cache constructor
          cachedCtors[SuperId] = Sub;
          return Sub;
        };
      }

      function initProps$1(Comp) {
        var props = Comp.options.props;
        for (var key in props) {
          proxy(Comp.prototype, "_props", key);
        }
      }

      function initComputed$1(Comp) {
        var computed = Comp.options.computed;
        for (var key in computed) {
          defineComputed(Comp.prototype, key, computed[key]);
        }
      }

      /*  */

      function initAssetRegisters(Vue) {
        /**
         * Create asset registration methods.
         */
        ASSET_TYPES.forEach(function (type) {
          Vue[type] = function (id, definition) {
            if (!definition) {
              return this.options[type + 's'][id];
            } else {
              /* istanbul ignore if */
              if (type === 'component' && isPlainObject(definition)) {
                definition.name = definition.name || id;
                definition = this.options._base.extend(definition);
              }
              if (type === 'directive' && typeof definition === 'function') {
                definition = { bind: definition, update: definition };
              }
              this.options[type + 's'][id] = definition;
              return definition;
            }
          };
        });
      }

      /*  */

      var patternTypes = [String, RegExp, Array];

      function getComponentName(opts) {
        return opts && (opts.Ctor.options.name || opts.tag);
      }

      function matches(pattern, name) {
        if (Array.isArray(pattern)) {
          return pattern.indexOf(name) > -1;
        } else if (typeof pattern === 'string') {
          return pattern.split(',').indexOf(name) > -1;
        } else if (isRegExp(pattern)) {
          return pattern.test(name);
        }
        /* istanbul ignore next */
        return false;
      }

      function pruneCache(cache, current, filter) {
        for (var key in cache) {
          var cachedNode = cache[key];
          if (cachedNode) {
            var name = getComponentName(cachedNode.componentOptions);
            if (name && !filter(name)) {
              if (cachedNode !== current) {
                pruneCacheEntry(cachedNode);
              }
              cache[key] = null;
            }
          }
        }
      }

      function pruneCacheEntry(vnode) {
        if (vnode) {
          vnode.componentInstance.$destroy();
        }
      }

      var KeepAlive = {
        name: 'keep-alive',
        abstract: true,

        props: {
          include: patternTypes,
          exclude: patternTypes
        },

        created: function created() {
          this.cache = Object.create(null);
        },

        destroyed: function destroyed() {
          var this$1 = this;

          for (var key in this$1.cache) {
            pruneCacheEntry(this$1.cache[key]);
          }
        },

        watch: {
          include: function include(val) {
            pruneCache(this.cache, this._vnode, function (name) {
              return matches(val, name);
            });
          },
          exclude: function exclude(val) {
            pruneCache(this.cache, this._vnode, function (name) {
              return !matches(val, name);
            });
          }
        },

        render: function render() {
          var vnode = getFirstComponentChild(this.$slots.default);
          var componentOptions = vnode && vnode.componentOptions;
          if (componentOptions) {
            // check pattern
            var name = getComponentName(componentOptions);
            if (name && (this.include && !matches(this.include, name) || this.exclude && matches(this.exclude, name))) {
              return vnode;
            }
            var key = vnode.key == null
            // same constructor may get registered as different local components
            // so cid alone is not enough (#3269)
            ? componentOptions.Ctor.cid + (componentOptions.tag ? "::" + componentOptions.tag : '') : vnode.key;
            if (this.cache[key]) {
              vnode.componentInstance = this.cache[key].componentInstance;
            } else {
              this.cache[key] = vnode;
            }
            vnode.data.keepAlive = true;
          }
          return vnode;
        }
      };

      var builtInComponents = {
        KeepAlive: KeepAlive
      };

      /*  */

      function initGlobalAPI(Vue) {
        // config
        var configDef = {};
        configDef.get = function () {
          return config;
        };
        Object.defineProperty(Vue, 'config', configDef);

        // exposed util methods.
        // NOTE: these are not considered part of the public API - avoid relying on
        // them unless you are aware of the risk.
        Vue.util = {
          warn: warn,
          extend: extend,
          mergeOptions: mergeOptions,
          defineReactive: defineReactive$$1
        };

        Vue.set = set;
        Vue.delete = del;
        Vue.nextTick = nextTick;

        Vue.options = Object.create(null);
        ASSET_TYPES.forEach(function (type) {
          Vue.options[type + 's'] = Object.create(null);
        });

        // this is used to identify the "base" constructor to extend all plain-object
        // components with in Weex's multi-instance scenarios.
        Vue.options._base = Vue;

        extend(Vue.options.components, builtInComponents);

        initUse(Vue);
        initMixin$1(Vue);
        initExtend(Vue);
        initAssetRegisters(Vue);
      }

      initGlobalAPI(Vue$3);

      Object.defineProperty(Vue$3.prototype, '$isServer', {
        get: isServerRendering
      });

      Object.defineProperty(Vue$3.prototype, '$ssrContext', {
        get: function get() {
          /* istanbul ignore next */
          return this.$vnode && this.$vnode.ssrContext;
        }
      });

      Vue$3.version = '2.4.1';
      Vue$3.mpvueVersion = '2.0.5';

      /* globals renderer */

      var isReservedTag = makeMap('template,script,style,element,content,slot,link,meta,svg,view,' + 'a,div,img,image,text,span,richtext,input,switch,textarea,spinner,select,' + 'slider,slider-neighbor,indicator,trisition,trisition-group,canvas,' + 'list,cell,header,loading,loading-indicator,refresh,scrollable,scroller,' + 'video,web,embed,tabbar,tabheader,datepicker,timepicker,marquee,countdown', true);

      // these are reserved for web because they are directly compiled away
      // during template compilation
      var isReservedAttr = makeMap('style,class');

      // Elements that you can, intentionally, leave open (and which close themselves)
      // more flexable than web
      var canBeLeftOpenTag = makeMap('web,spinner,switch,video,textarea,canvas,' + 'indicator,marquee,countdown', true);

      var isUnaryTag = makeMap('embed,img,image,input,link,meta', true);

      function mustUseProp() {/* console.log('mustUseProp') */}
      function getTagNamespace() {/* console.log('getTagNamespace') */}
      function isUnknownElement() {/* console.log('isUnknownElement') */}

      function getComKey(vm) {
        return vm && vm.$attrs ? vm.$attrs['mpcomid'] : '0';
      }

      // 用于小程序的 event type 到 web 的 event
      var eventTypeMap = {
        tap: ['tap', 'click'],
        touchstart: ['touchstart'],
        touchmove: ['touchmove'],
        touchcancel: ['touchcancel'],
        touchend: ['touchend'],
        longtap: ['longtap'],
        input: ['input'],
        blur: ['change', 'blur'],
        submit: ['submit'],
        focus: ['focus'],
        scrolltoupper: ['scrolltoupper'],
        scrolltolower: ['scrolltolower'],
        scroll: ['scroll']
      };

      /*  */

      // import { namespaceMap } from 'mp/util/index'

      var obj = {};

      function createElement$1(tagName, vnode) {
        return obj;
      }

      function createElementNS(namespace, tagName) {
        return obj;
      }

      function createTextNode(text) {
        return obj;
      }

      function createComment(text) {
        return obj;
      }

      function insertBefore(parentNode, newNode, referenceNode) {}

      function removeChild(node, child) {}

      function appendChild(node, child) {}

      function parentNode(node) {
        return obj;
      }

      function nextSibling(node) {
        return obj;
      }

      function tagName(node) {
        return 'div';
      }

      function setTextContent(node, text) {
        return obj;
      }

      function setAttribute(node, key, val) {
        return obj;
      }

      var nodeOps = Object.freeze({
        createElement: createElement$1,
        createElementNS: createElementNS,
        createTextNode: createTextNode,
        createComment: createComment,
        insertBefore: insertBefore,
        removeChild: removeChild,
        appendChild: appendChild,
        parentNode: parentNode,
        nextSibling: nextSibling,
        tagName: tagName,
        setTextContent: setTextContent,
        setAttribute: setAttribute
      });

      /*  */

      var ref = {
        create: function create(_, vnode) {
          registerRef(vnode);
        },
        update: function update(oldVnode, vnode) {
          if (oldVnode.data.ref !== vnode.data.ref) {
            registerRef(oldVnode, true);
            registerRef(vnode);
          }
        },
        destroy: function destroy(vnode) {
          registerRef(vnode, true);
        }
      };

      function registerRef(vnode, isRemoval) {
        var key = vnode.data.ref;
        if (!key) {
          return;
        }

        var vm = vnode.context;
        var ref = vnode.componentInstance || vnode.elm;
        var refs = vm.$refs;
        if (isRemoval) {
          if (Array.isArray(refs[key])) {
            remove(refs[key], ref);
          } else if (refs[key] === ref) {
            refs[key] = undefined;
          }
        } else {
          if (vnode.data.refInFor) {
            if (!Array.isArray(refs[key])) {
              refs[key] = [ref];
            } else if (refs[key].indexOf(ref) < 0) {
              // $flow-disable-line
              refs[key].push(ref);
            }
          } else {
            refs[key] = ref;
          }
        }
      }

      /**
       * Virtual DOM patching algorithm based on Snabbdom by
       * Simon Friis Vindum (@paldepind)
       * Licensed under the MIT License
       * https://github.com/paldepind/snabbdom/blob/master/LICENSE
       *
       * modified by Evan You (@yyx990803)
       *
      
      /*
       * Not type-checking this because this file is perf-critical and the cost
       * of making flow understand it is not worth it.
       */

      var emptyNode = new VNode('', {}, []);

      var hooks = ['create', 'activate', 'update', 'remove', 'destroy'];

      function sameVnode(a, b) {
        return a.key === b.key && (a.tag === b.tag && a.isComment === b.isComment && isDef(a.data) === isDef(b.data) && sameInputType(a, b) || isTrue(a.isAsyncPlaceholder) && a.asyncFactory === b.asyncFactory && isUndef(b.asyncFactory.error));
      }

      // Some browsers do not support dynamically changing type for <input>
      // so they need to be treated as different nodes
      function sameInputType(a, b) {
        if (a.tag !== 'input') {
          return true;
        }
        var i;
        var typeA = isDef(i = a.data) && isDef(i = i.attrs) && i.type;
        var typeB = isDef(i = b.data) && isDef(i = i.attrs) && i.type;
        return typeA === typeB;
      }

      function createKeyToOldIdx(children, beginIdx, endIdx) {
        var i, key;
        var map = {};
        for (i = beginIdx; i <= endIdx; ++i) {
          key = children[i].key;
          if (isDef(key)) {
            map[key] = i;
          }
        }
        return map;
      }

      function createPatchFunction(backend) {
        var i, j;
        var cbs = {};

        var modules = backend.modules;
        var nodeOps = backend.nodeOps;

        for (i = 0; i < hooks.length; ++i) {
          cbs[hooks[i]] = [];
          for (j = 0; j < modules.length; ++j) {
            if (isDef(modules[j][hooks[i]])) {
              cbs[hooks[i]].push(modules[j][hooks[i]]);
            }
          }
        }

        function emptyNodeAt(elm) {
          return new VNode(nodeOps.tagName(elm).toLowerCase(), {}, [], undefined, elm);
        }

        function createRmCb(childElm, listeners) {
          function remove$$1() {
            if (--remove$$1.listeners === 0) {
              removeNode(childElm);
            }
          }
          remove$$1.listeners = listeners;
          return remove$$1;
        }

        function removeNode(el) {
          var parent = nodeOps.parentNode(el);
          // element may have already been removed due to v-html / v-text
          if (isDef(parent)) {
            nodeOps.removeChild(parent, el);
          }
        }

        var inPre = 0;
        function createElm(vnode, insertedVnodeQueue, parentElm, refElm, nested) {
          vnode.isRootInsert = !nested; // for transition enter check
          if (createComponent(vnode, insertedVnodeQueue, parentElm, refElm)) {
            return;
          }

          var data = vnode.data;
          var children = vnode.children;
          var tag = vnode.tag;
          if (isDef(tag)) {
            vnode.elm = vnode.ns ? nodeOps.createElementNS(vnode.ns, tag) : nodeOps.createElement(tag, vnode);
            setScope(vnode);

            /* istanbul ignore if */
            {
              createChildren(vnode, children, insertedVnodeQueue);
              if (isDef(data)) {
                invokeCreateHooks(vnode, insertedVnodeQueue);
              }
              insert(parentElm, vnode.elm, refElm);
            }

            if (false) {
              inPre--;
            }
          } else if (isTrue(vnode.isComment)) {
            vnode.elm = nodeOps.createComment(vnode.text);
            insert(parentElm, vnode.elm, refElm);
          } else {
            vnode.elm = nodeOps.createTextNode(vnode.text);
            insert(parentElm, vnode.elm, refElm);
          }
        }

        function createComponent(vnode, insertedVnodeQueue, parentElm, refElm) {
          var i = vnode.data;
          if (isDef(i)) {
            var isReactivated = isDef(vnode.componentInstance) && i.keepAlive;
            if (isDef(i = i.hook) && isDef(i = i.init)) {
              i(vnode, false /* hydrating */, parentElm, refElm);
            }
            // after calling the init hook, if the vnode is a child component
            // it should've created a child instance and mounted it. the child
            // component also has set the placeholder vnode's elm.
            // in that case we can just return the element and be done.
            if (isDef(vnode.componentInstance)) {
              initComponent(vnode, insertedVnodeQueue);
              if (isTrue(isReactivated)) {
                reactivateComponent(vnode, insertedVnodeQueue, parentElm, refElm);
              }
              return true;
            }
          }
        }

        function initComponent(vnode, insertedVnodeQueue) {
          if (isDef(vnode.data.pendingInsert)) {
            insertedVnodeQueue.push.apply(insertedVnodeQueue, vnode.data.pendingInsert);
            vnode.data.pendingInsert = null;
          }
          vnode.elm = vnode.componentInstance.$el;
          if (isPatchable(vnode)) {
            invokeCreateHooks(vnode, insertedVnodeQueue);
            setScope(vnode);
          } else {
            // empty component root.
            // skip all element-related modules except for ref (#3455)
            registerRef(vnode);
            // make sure to invoke the insert hook
            insertedVnodeQueue.push(vnode);
          }
        }

        function reactivateComponent(vnode, insertedVnodeQueue, parentElm, refElm) {
          var i;
          // hack for #4339: a reactivated component with inner transition
          // does not trigger because the inner node's created hooks are not called
          // again. It's not ideal to involve module-specific logic in here but
          // there doesn't seem to be a better way to do it.
          var innerNode = vnode;
          while (innerNode.componentInstance) {
            innerNode = innerNode.componentInstance._vnode;
            if (isDef(i = innerNode.data) && isDef(i = i.transition)) {
              for (i = 0; i < cbs.activate.length; ++i) {
                cbs.activate[i](emptyNode, innerNode);
              }
              insertedVnodeQueue.push(innerNode);
              break;
            }
          }
          // unlike a newly created component,
          // a reactivated keep-alive component doesn't insert itself
          insert(parentElm, vnode.elm, refElm);
        }

        function insert(parent, elm, ref$$1) {
          if (isDef(parent)) {
            if (isDef(ref$$1)) {
              if (ref$$1.parentNode === parent) {
                nodeOps.insertBefore(parent, elm, ref$$1);
              }
            } else {
              nodeOps.appendChild(parent, elm);
            }
          }
        }

        function createChildren(vnode, children, insertedVnodeQueue) {
          if (Array.isArray(children)) {
            for (var i = 0; i < children.length; ++i) {
              createElm(children[i], insertedVnodeQueue, vnode.elm, null, true);
            }
          } else if (isPrimitive(vnode.text)) {
            nodeOps.appendChild(vnode.elm, nodeOps.createTextNode(vnode.text));
          }
        }

        function isPatchable(vnode) {
          while (vnode.componentInstance) {
            vnode = vnode.componentInstance._vnode;
          }
          return isDef(vnode.tag);
        }

        function invokeCreateHooks(vnode, insertedVnodeQueue) {
          for (var i$1 = 0; i$1 < cbs.create.length; ++i$1) {
            cbs.create[i$1](emptyNode, vnode);
          }
          i = vnode.data.hook; // Reuse variable
          if (isDef(i)) {
            if (isDef(i.create)) {
              i.create(emptyNode, vnode);
            }
            if (isDef(i.insert)) {
              insertedVnodeQueue.push(vnode);
            }
          }
        }

        // set scope id attribute for scoped CSS.
        // this is implemented as a special case to avoid the overhead
        // of going through the normal attribute patching process.
        function setScope(vnode) {
          var i;
          var ancestor = vnode;
          while (ancestor) {
            if (isDef(i = ancestor.context) && isDef(i = i.$options._scopeId)) {
              nodeOps.setAttribute(vnode.elm, i, '');
            }
            ancestor = ancestor.parent;
          }
          // for slot content they should also get the scopeId from the host instance.
          if (isDef(i = activeInstance) && i !== vnode.context && isDef(i = i.$options._scopeId)) {
            nodeOps.setAttribute(vnode.elm, i, '');
          }
        }

        function addVnodes(parentElm, refElm, vnodes, startIdx, endIdx, insertedVnodeQueue) {
          for (; startIdx <= endIdx; ++startIdx) {
            createElm(vnodes[startIdx], insertedVnodeQueue, parentElm, refElm);
          }
        }

        function invokeDestroyHook(vnode) {
          var i, j;
          var data = vnode.data;
          if (isDef(data)) {
            if (isDef(i = data.hook) && isDef(i = i.destroy)) {
              i(vnode);
            }
            for (i = 0; i < cbs.destroy.length; ++i) {
              cbs.destroy[i](vnode);
            }
          }
          if (isDef(i = vnode.children)) {
            for (j = 0; j < vnode.children.length; ++j) {
              invokeDestroyHook(vnode.children[j]);
            }
          }
        }

        function removeVnodes(parentElm, vnodes, startIdx, endIdx) {
          for (; startIdx <= endIdx; ++startIdx) {
            var ch = vnodes[startIdx];
            if (isDef(ch)) {
              if (isDef(ch.tag)) {
                removeAndInvokeRemoveHook(ch);
                invokeDestroyHook(ch);
              } else {
                // Text node
                removeNode(ch.elm);
              }
            }
          }
        }

        function removeAndInvokeRemoveHook(vnode, rm) {
          if (isDef(rm) || isDef(vnode.data)) {
            var i;
            var listeners = cbs.remove.length + 1;
            if (isDef(rm)) {
              // we have a recursively passed down rm callback
              // increase the listeners count
              rm.listeners += listeners;
            } else {
              // directly removing
              rm = createRmCb(vnode.elm, listeners);
            }
            // recursively invoke hooks on child component root node
            if (isDef(i = vnode.componentInstance) && isDef(i = i._vnode) && isDef(i.data)) {
              removeAndInvokeRemoveHook(i, rm);
            }
            for (i = 0; i < cbs.remove.length; ++i) {
              cbs.remove[i](vnode, rm);
            }
            if (isDef(i = vnode.data.hook) && isDef(i = i.remove)) {
              i(vnode, rm);
            } else {
              rm();
            }
          } else {
            removeNode(vnode.elm);
          }
        }

        function updateChildren(parentElm, oldCh, newCh, insertedVnodeQueue, removeOnly) {
          var oldStartIdx = 0;
          var newStartIdx = 0;
          var oldEndIdx = oldCh.length - 1;
          var oldStartVnode = oldCh[0];
          var oldEndVnode = oldCh[oldEndIdx];
          var newEndIdx = newCh.length - 1;
          var newStartVnode = newCh[0];
          var newEndVnode = newCh[newEndIdx];
          var oldKeyToIdx, idxInOld, elmToMove, refElm;

          // removeOnly is a special flag used only by <transition-group>
          // to ensure removed elements stay in correct relative positions
          // during leaving transitions
          var canMove = !removeOnly;

          while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
            if (isUndef(oldStartVnode)) {
              oldStartVnode = oldCh[++oldStartIdx]; // Vnode has been moved left
            } else if (isUndef(oldEndVnode)) {
              oldEndVnode = oldCh[--oldEndIdx];
            } else if (sameVnode(oldStartVnode, newStartVnode)) {
              patchVnode(oldStartVnode, newStartVnode, insertedVnodeQueue);
              oldStartVnode = oldCh[++oldStartIdx];
              newStartVnode = newCh[++newStartIdx];
            } else if (sameVnode(oldEndVnode, newEndVnode)) {
              patchVnode(oldEndVnode, newEndVnode, insertedVnodeQueue);
              oldEndVnode = oldCh[--oldEndIdx];
              newEndVnode = newCh[--newEndIdx];
            } else if (sameVnode(oldStartVnode, newEndVnode)) {
              // Vnode moved right
              patchVnode(oldStartVnode, newEndVnode, insertedVnodeQueue);
              canMove && nodeOps.insertBefore(parentElm, oldStartVnode.elm, nodeOps.nextSibling(oldEndVnode.elm));
              oldStartVnode = oldCh[++oldStartIdx];
              newEndVnode = newCh[--newEndIdx];
            } else if (sameVnode(oldEndVnode, newStartVnode)) {
              // Vnode moved left
              patchVnode(oldEndVnode, newStartVnode, insertedVnodeQueue);
              canMove && nodeOps.insertBefore(parentElm, oldEndVnode.elm, oldStartVnode.elm);
              oldEndVnode = oldCh[--oldEndIdx];
              newStartVnode = newCh[++newStartIdx];
            } else {
              if (isUndef(oldKeyToIdx)) {
                oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
              }
              idxInOld = isDef(newStartVnode.key) ? oldKeyToIdx[newStartVnode.key] : null;
              if (isUndef(idxInOld)) {
                // New element
                createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm);
                newStartVnode = newCh[++newStartIdx];
              } else {
                elmToMove = oldCh[idxInOld];
                /* istanbul ignore if */
                if (false) {
                  warn('It seems there are duplicate keys that is causing an update error. ' + 'Make sure each v-for item has a unique key.');
                }
                if (sameVnode(elmToMove, newStartVnode)) {
                  patchVnode(elmToMove, newStartVnode, insertedVnodeQueue);
                  oldCh[idxInOld] = undefined;
                  canMove && nodeOps.insertBefore(parentElm, elmToMove.elm, oldStartVnode.elm);
                  newStartVnode = newCh[++newStartIdx];
                } else {
                  // same key but different element. treat as new element
                  createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm);
                  newStartVnode = newCh[++newStartIdx];
                }
              }
            }
          }
          if (oldStartIdx > oldEndIdx) {
            refElm = isUndef(newCh[newEndIdx + 1]) ? null : newCh[newEndIdx + 1].elm;
            addVnodes(parentElm, refElm, newCh, newStartIdx, newEndIdx, insertedVnodeQueue);
          } else if (newStartIdx > newEndIdx) {
            removeVnodes(parentElm, oldCh, oldStartIdx, oldEndIdx);
          }
        }

        function patchVnode(oldVnode, vnode, insertedVnodeQueue, removeOnly) {
          if (oldVnode === vnode) {
            return;
          }

          var elm = vnode.elm = oldVnode.elm;

          if (isTrue(oldVnode.isAsyncPlaceholder)) {
            if (isDef(vnode.asyncFactory.resolved)) {
              hydrate(oldVnode.elm, vnode, insertedVnodeQueue);
            } else {
              vnode.isAsyncPlaceholder = true;
            }
            return;
          }

          // reuse element for static trees.
          // note we only do this if the vnode is cloned -
          // if the new node is not cloned it means the render functions have been
          // reset by the hot-reload-api and we need to do a proper re-render.
          if (isTrue(vnode.isStatic) && isTrue(oldVnode.isStatic) && vnode.key === oldVnode.key && (isTrue(vnode.isCloned) || isTrue(vnode.isOnce))) {
            vnode.componentInstance = oldVnode.componentInstance;
            return;
          }

          var i;
          var data = vnode.data;
          if (isDef(data) && isDef(i = data.hook) && isDef(i = i.prepatch)) {
            i(oldVnode, vnode);
          }

          var oldCh = oldVnode.children;
          var ch = vnode.children;
          if (isDef(data) && isPatchable(vnode)) {
            for (i = 0; i < cbs.update.length; ++i) {
              cbs.update[i](oldVnode, vnode);
            }
            if (isDef(i = data.hook) && isDef(i = i.update)) {
              i(oldVnode, vnode);
            }
          }
          if (isUndef(vnode.text)) {
            if (isDef(oldCh) && isDef(ch)) {
              if (oldCh !== ch) {
                updateChildren(elm, oldCh, ch, insertedVnodeQueue, removeOnly);
              }
            } else if (isDef(ch)) {
              if (isDef(oldVnode.text)) {
                nodeOps.setTextContent(elm, '');
              }
              addVnodes(elm, null, ch, 0, ch.length - 1, insertedVnodeQueue);
            } else if (isDef(oldCh)) {
              removeVnodes(elm, oldCh, 0, oldCh.length - 1);
            } else if (isDef(oldVnode.text)) {
              nodeOps.setTextContent(elm, '');
            }
          } else if (oldVnode.text !== vnode.text) {
            nodeOps.setTextContent(elm, vnode.text);
          }
          if (isDef(data)) {
            if (isDef(i = data.hook) && isDef(i = i.postpatch)) {
              i(oldVnode, vnode);
            }
          }
        }

        function invokeInsertHook(vnode, queue, initial) {
          // delay insert hooks for component root nodes, invoke them after the
          // element is really inserted
          if (isTrue(initial) && isDef(vnode.parent)) {
            vnode.parent.data.pendingInsert = queue;
          } else {
            for (var i = 0; i < queue.length; ++i) {
              queue[i].data.hook.insert(queue[i]);
            }
          }
        }

        var bailed = false;
        // list of modules that can skip create hook during hydration because they
        // are already rendered on the client or has no need for initialization
        var isRenderedModule = makeMap('attrs,style,class,staticClass,staticStyle,key');

        // Note: this is a browser-only function so we can assume elms are DOM nodes.
        function hydrate(elm, vnode, insertedVnodeQueue) {
          if (isTrue(vnode.isComment) && isDef(vnode.asyncFactory)) {
            vnode.elm = elm;
            vnode.isAsyncPlaceholder = true;
            return true;
          }
          vnode.elm = elm;
          var tag = vnode.tag;
          var data = vnode.data;
          var children = vnode.children;
          if (isDef(data)) {
            if (isDef(i = data.hook) && isDef(i = i.init)) {
              i(vnode, true /* hydrating */);
            }
            if (isDef(i = vnode.componentInstance)) {
              // child component. it should have hydrated its own tree.
              initComponent(vnode, insertedVnodeQueue);
              return true;
            }
          }
          if (isDef(tag)) {
            if (isDef(children)) {
              // empty element, allow client to pick up and populate children
              if (!elm.hasChildNodes()) {
                createChildren(vnode, children, insertedVnodeQueue);
              } else {
                var childrenMatch = true;
                var childNode = elm.firstChild;
                for (var i$1 = 0; i$1 < children.length; i$1++) {
                  if (!childNode || !hydrate(childNode, children[i$1], insertedVnodeQueue)) {
                    childrenMatch = false;
                    break;
                  }
                  childNode = childNode.nextSibling;
                }
                // if childNode is not null, it means the actual childNodes list is
                // longer than the virtual children list.
                if (!childrenMatch || childNode) {
                  if (false) {
                    bailed = true;
                    console.warn('Parent: ', elm);
                    console.warn('Mismatching childNodes vs. VNodes: ', elm.childNodes, children);
                  }
                  return false;
                }
              }
            }
            if (isDef(data)) {
              for (var key in data) {
                if (!isRenderedModule(key)) {
                  invokeCreateHooks(vnode, insertedVnodeQueue);
                  break;
                }
              }
            }
          } else if (elm.data !== vnode.text) {
            elm.data = vnode.text;
          }
          return true;
        }

        return function patch(oldVnode, vnode, hydrating, removeOnly, parentElm, refElm) {
          if (isUndef(vnode)) {
            if (isDef(oldVnode)) {
              invokeDestroyHook(oldVnode);
            }
            return;
          }

          var isInitialPatch = false;
          var insertedVnodeQueue = [];

          if (isUndef(oldVnode)) {
            // empty mount (likely as component), create new root element
            isInitialPatch = true;
            createElm(vnode, insertedVnodeQueue, parentElm, refElm);
          } else {
            var isRealElement = isDef(oldVnode.nodeType);
            if (!isRealElement && sameVnode(oldVnode, vnode)) {
              // patch existing root node
              patchVnode(oldVnode, vnode, insertedVnodeQueue, removeOnly);
            } else {
              if (isRealElement) {
                // mounting to a real element
                // check if this is server-rendered content and if we can perform
                // a successful hydration.
                if (oldVnode.nodeType === 1 && oldVnode.hasAttribute(SSR_ATTR)) {
                  oldVnode.removeAttribute(SSR_ATTR);
                  hydrating = true;
                }
                if (isTrue(hydrating)) {
                  if (hydrate(oldVnode, vnode, insertedVnodeQueue)) {
                    invokeInsertHook(vnode, insertedVnodeQueue, true);
                    return oldVnode;
                  } else {}
                }
                // either not server-rendered, or hydration failed.
                // create an empty node and replace it
                oldVnode = emptyNodeAt(oldVnode);
              }
              // replacing existing element
              var oldElm = oldVnode.elm;
              var parentElm$1 = nodeOps.parentNode(oldElm);
              createElm(vnode, insertedVnodeQueue,
              // extremely rare edge case: do not insert if old element is in a
              // leaving transition. Only happens when combining transition +
              // keep-alive + HOCs. (#4590)
              oldElm._leaveCb ? null : parentElm$1, nodeOps.nextSibling(oldElm));

              if (isDef(vnode.parent)) {
                // component root element replaced.
                // update parent placeholder node element, recursively
                var ancestor = vnode.parent;
                while (ancestor) {
                  ancestor.elm = vnode.elm;
                  ancestor = ancestor.parent;
                }
                if (isPatchable(vnode)) {
                  for (var i = 0; i < cbs.create.length; ++i) {
                    cbs.create[i](emptyNode, vnode.parent);
                  }
                }
              }

              if (isDef(parentElm$1)) {
                removeVnodes(parentElm$1, [oldVnode], 0, 0);
              } else if (isDef(oldVnode.tag)) {
                invokeDestroyHook(oldVnode);
              }
            }
          }

          invokeInsertHook(vnode, insertedVnodeQueue, isInitialPatch);
          return vnode.elm;
        };
      }

      /*  */

      // import baseModules from 'core/vdom/modules/index'
      // const platformModules = []
      // import platformModules from 'web/runtime/modules/index'

      // the directive module should be applied last, after all
      // built-in modules have been applied.
      // const modules = platformModules.concat(baseModules)
      var modules = [ref];

      var corePatch = createPatchFunction({ nodeOps: nodeOps, modules: modules });

      function patch() {
        corePatch.apply(this, arguments);
        this.$updateDataToMP();
      }

      function callHook$1(vm, hook, params) {
        var handlers = vm.$options[hook];
        if (hook === 'onError' && handlers) {
          handlers = [handlers];
        } else if (hook === 'onPageNotFound' && handlers) {
          handlers = [handlers];
        }

        var ret;
        if (handlers) {
          for (var i = 0, j = handlers.length; i < j; i++) {
            try {
              ret = handlers[i].call(vm, params);
            } catch (e) {
              handleError(e, vm, hook + " hook");
            }
          }
        }
        if (vm._hasHookEvent) {
          vm.$emit('hook:' + hook);
        }

        // for child
        if (vm.$children.length) {
          vm.$children.forEach(function (v) {
            return callHook$1(v, hook, params);
          });
        }

        return ret;
      }

      // mpType 小程序实例的类型，可能的值是 'app', 'page'
      // rootVueVM 是 vue 的根组件实例，子组件中访问 this.$root 可得
      function getGlobalData(app, rootVueVM) {
        var mp = rootVueVM.$mp;
        if (app && app.globalData) {
          mp.appOptions = app.globalData.appOptions;
        }
      }

      // 格式化 properties 属性，并给每个属性加上 observer 方法

      // properties 的 一些类型 https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/component.html
      // properties: {
      //   paramA: Number,
      //   myProperty: { // 属性名
      //     type: String, // 类型（必填），目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      //     value: '', // 属性初始值（可选），如果未指定则会根据类型选择一个
      //     observer: function(newVal, oldVal, changedPath) {
      //        // 属性被改变时执行的函数（可选），也可以写成在methods段中定义的方法名字符串, 如：'_propertyChange'
      //        // 通常 newVal 就是新设置的数据， oldVal 是旧数据
      //     }
      //   },
      // }

      // props 的一些类型 https://cn.vuejs.org/v2/guide/components-props.html#ad
      // props: {
      //   // 基础的类型检查 (`null` 匹配任何类型)
      //   propA: Number,
      //   // 多个可能的类型
      //   propB: [String, Number],
      //   // 必填的字符串
      //   propC: {
      //     type: String,
      //     required: true
      //   },
      //   // 带有默认值的数字
      //   propD: {
      //     type: Number,
      //     default: 100
      //   },
      //   // 带有默认值的对象
      //   propE: {
      //     type: Object,
      //     // 对象或数组且一定会从一个工厂函数返回默认值
      //     default: function () {
      //       return { message: 'hello' }
      //     }
      //   },
      //   // 自定义验证函数
      //   propF: {
      //     validator: function (value) {
      //       // 这个值必须匹配下列字符串中的一个
      //       return ['success', 'warning', 'danger'].indexOf(value) !== -1
      //     }
      //   }
      // }

      // core/util/options
      function normalizeProps$1(props, res, vm) {
        if (!props) {
          return;
        }
        var i, val, name;
        if (Array.isArray(props)) {
          i = props.length;
          while (i--) {
            val = props[i];
            if (typeof val === 'string') {
              name = camelize(val);
              res[name] = { type: null };
            } else {}
          }
        } else if (isPlainObject(props)) {
          for (var key in props) {
            val = props[key];
            name = camelize(key);
            res[name] = isPlainObject(val) ? val : { type: val };
          }
        }

        // fix vueProps to properties
        for (var key$1 in res) {
          if (res.hasOwnProperty(key$1)) {
            var item = res[key$1];
            if (item.default) {
              item.value = item.default;
            }
            var oldObserver = item.observer;
            item.observer = function (newVal, oldVal) {
              vm[name] = newVal;
              // 先修改值再触发原始的 observer，跟 watch 行为保持一致
              if (typeof oldObserver === 'function') {
                oldObserver.call(vm, newVal, oldVal);
              }
            };
          }
        }

        return res;
      }

      function normalizeProperties(vm) {
        var properties = vm.$options.properties;
        var vueProps = vm.$options.props;
        var res = {};

        normalizeProps$1(properties, res, vm);
        normalizeProps$1(vueProps, res, vm);

        return res;
      }

      /**
       * 把 properties 中的属性 proxy 到 vm 上
       */
      function initMpProps(vm) {
        var mpProps = vm._mpProps = {};
        var keys = Object.keys(vm.$options.properties || {});
        keys.forEach(function (key) {
          if (!(key in vm)) {
            proxy(vm, '_mpProps', key);
            mpProps[key] = undefined; // for observe
          }
        });
        observe(mpProps, true);
      }

      function initMP(mpType, next) {
        var rootVueVM = this.$root;
        if (!rootVueVM.$mp) {
          rootVueVM.$mp = {};
        }

        var mp = rootVueVM.$mp;

        // Please do not register multiple Pages
        // if (mp.registered) {
        if (mp.status) {
          // 处理子组件的小程序生命周期
          if (mpType === 'app') {
            callHook$1(this, 'onLaunch', mp.appOptions);
          } else {
            callHook$1(this, 'onLoad', mp.query);
            callHook$1(this, 'onReady');
          }
          return next();
        }
        // mp.registered = true

        mp.mpType = mpType;
        mp.status = 'register';

        if (mpType === 'app') {
          global.App({
            // 页面的初始数据
            globalData: {
              appOptions: {}
            },

            handleProxy: function handleProxy(e) {
              return rootVueVM.$handleProxyWithVue(e);
            },

            // Do something initial when launch.
            onLaunch: function onLaunch(options) {
              if (options === void 0) options = {};

              mp.app = this;
              mp.status = 'launch';
              this.globalData.appOptions = mp.appOptions = options;
              callHook$1(rootVueVM, 'onLaunch', options);
              next();
            },

            // Do something when app show.
            onShow: function onShow(options) {
              if (options === void 0) options = {};

              mp.status = 'show';
              this.globalData.appOptions = mp.appOptions = options;
              callHook$1(rootVueVM, 'onShow', options);
            },

            // Do something when app hide.
            onHide: function onHide() {
              mp.status = 'hide';
              callHook$1(rootVueVM, 'onHide');
            },

            onError: function onError(err) {
              callHook$1(rootVueVM, 'onError', err);
            },

            onPageNotFound: function onPageNotFound(err) {
              callHook$1(rootVueVM, 'onPageNotFound', err);
            }
          });
        } else if (mpType === 'component') {
          initMpProps(rootVueVM);

          global.Component({
            // 小程序原生的组件属性
            properties: normalizeProperties(rootVueVM),
            // 页面的初始数据
            data: {
              $root: {}
            },
            methods: {
              handleProxy: function handleProxy(e) {
                return rootVueVM.$handleProxyWithVue(e);
              }
            },
            // mp lifecycle for vue
            // 组件生命周期函数，在组件实例进入页面节点树时执行，注意此时不能调用 setData
            created: function created() {
              mp.status = 'created';
              mp.page = this;
            },
            // 组件生命周期函数，在组件实例进入页面节点树时执行
            attached: function attached() {
              mp.status = 'attached';
              callHook$1(rootVueVM, 'attached');
            },
            // 组件生命周期函数，在组件布局完成后执行，此时可以获取节点信息（使用 SelectorQuery ）
            ready: function ready() {
              mp.status = 'ready';

              callHook$1(rootVueVM, 'ready');
              next();

              // 只有页面需要 setData
              rootVueVM.$nextTick(function () {
                rootVueVM._initDataToMP();
              });
            },
            // 组件生命周期函数，在组件实例被移动到节点树另一个位置时执行
            moved: function moved() {
              callHook$1(rootVueVM, 'moved');
            },
            // 组件生命周期函数，在组件实例被从页面节点树移除时执行
            detached: function detached() {
              mp.status = 'detached';
              callHook$1(rootVueVM, 'detached');
            }
          });
        } else {
          var app = global.getApp();
          global.Page({
            // 页面的初始数据
            data: {
              $root: {}
            },

            handleProxy: function handleProxy(e) {
              return rootVueVM.$handleProxyWithVue(e);
            },

            // mp lifecycle for vue
            // 生命周期函数--监听页面加载
            onLoad: function onLoad(query) {
              mp.page = this;
              mp.query = query;
              mp.status = 'load';
              getGlobalData(app, rootVueVM);
              callHook$1(rootVueVM, 'onLoad', query);
            },

            // 生命周期函数--监听页面显示
            onShow: function onShow() {
              mp.page = this;
              mp.status = 'show';
              callHook$1(rootVueVM, 'onShow');

              // 只有页面需要 setData
              rootVueVM.$nextTick(function () {
                rootVueVM._initDataToMP();
              });
            },

            // 生命周期函数--监听页面初次渲染完成
            onReady: function onReady() {
              mp.status = 'ready';

              callHook$1(rootVueVM, 'onReady');
              next();
            },

            // 生命周期函数--监听页面隐藏
            onHide: function onHide() {
              mp.status = 'hide';
              callHook$1(rootVueVM, 'onHide');
              mp.page = null;
            },

            // 生命周期函数--监听页面卸载
            onUnload: function onUnload() {
              mp.status = 'unload';
              callHook$1(rootVueVM, 'onUnload');
              mp.page = null;
            },

            // 页面相关事件处理函数--监听用户下拉动作
            onPullDownRefresh: function onPullDownRefresh() {
              callHook$1(rootVueVM, 'onPullDownRefresh');
            },

            // 页面上拉触底事件的处理函数
            onReachBottom: function onReachBottom() {
              callHook$1(rootVueVM, 'onReachBottom');
            },

            // 用户点击右上角分享
            onShareAppMessage: rootVueVM.$options.onShareAppMessage ? function (options) {
              return callHook$1(rootVueVM, 'onShareAppMessage', options);
            } : null,

            // Do something when page scroll
            onPageScroll: function onPageScroll(options) {
              callHook$1(rootVueVM, 'onPageScroll', options);
            },

            // 当前是 tab 页时，点击 tab 时触发
            onTabItemTap: function onTabItemTap(options) {
              callHook$1(rootVueVM, 'onTabItemTap', options);
            }
          });
        }
      }

      var updateDataTotal = 0; // 总共更新的数据量
      function diffLog(updateData) {
        updateData = JSON.stringify(updateData);
        if (!Vue$3._mpvueTraceTimer) {
          Vue$3._mpvueTraceTimer = setTimeout(function () {
            clearTimeout(Vue$3._mpvueTraceTimer);
            updateDataTotal = (updateDataTotal / 1024).toFixed(1);
            console.log('这次操作引发500ms内数据更新量:' + updateDataTotal + 'kb');
            Vue$3._mpvueTraceTimer = 0;
            updateDataTotal = 0;
          }, 500);
        } else if (Vue$3._mpvueTraceTimer) {
          updateData = updateData.replace(/[^\u0000-\u00ff]/g, 'aa'); // 中文占2字节，中文替换成两个字母计算占用空间
          updateDataTotal += updateData.length;
        }
      }

      var KEY_SEP$1 = '_';

      function getDeepData(keyList, viewData) {
        if (keyList.length > 1) {
          var _key = keyList.splice(0, 1);
          var _viewData = viewData[_key];
          if (_viewData) {
            return getDeepData(keyList, _viewData);
          } else {
            return null;
          }
        } else {
          if (viewData[keyList[0]]) {
            return viewData[keyList[0]];
          } else {
            return null;
          }
        }
      }

      function compareAndSetDeepData(key, newData, vm, data, forceUpdate) {
        // 比较引用类型数据
        try {
          var keyList = key.split('.');
          // page.__viewData__老版小程序不存在，使用mpvue里绑的data比对
          var oldData = getDeepData(keyList, vm.$root.$mp.page.data);
          if (oldData === null || JSON.stringify(oldData) !== JSON.stringify(newData) || forceUpdate) {
            data[key] = newData;
          }
        } catch (e) {
          console.log(e, key, newData, vm);
        }
      }

      function cleanKeyPath(vm) {
        if (vm.__mpKeyPath) {
          Object.keys(vm.__mpKeyPath).forEach(function (_key) {
            delete vm.__mpKeyPath[_key]['__keyPath'];
          });
        }
      }

      function minifyDeepData(rootKey, originKey, vmData, data, _mpValueSet, vm) {
        try {
          if (vmData instanceof Array) {
            // 数组
            compareAndSetDeepData(rootKey + '.' + originKey, vmData, vm, data, true);
          } else {
            // Object
            var _keyPathOnThis = {}; // 存储这层对象的keyPath
            if (vmData.__keyPath && !vmData.__newReference) {
              // 有更新列表 ，按照更新列表更新
              _keyPathOnThis = vmData.__keyPath;
              Object.keys(vmData).forEach(function (_key) {
                if (vmData[_key] instanceof Object) {
                  // 引用类型 递归
                  if (_key === '__keyPath') {
                    return;
                  }
                  minifyDeepData(rootKey + '.' + originKey, _key, vmData[_key], data, null, vm);
                } else {
                  // 更新列表中的 加入data
                  if (_keyPathOnThis[_key] === true) {
                    if (originKey) {
                      data[rootKey + '.' + originKey + '.' + _key] = vmData[_key];
                    } else {
                      data[rootKey + '.' + _key] = vmData[_key];
                    }
                  }
                }
              });
              // 根节点可能有父子引用同一个引用类型数据，依赖树都遍历完后清理
              vm['__mpKeyPath'] = vm['__mpKeyPath'] || {};
              vm['__mpKeyPath'][vmData.__ob__.dep.id] = vmData;
            } else {
              // 没有更新列表
              compareAndSetDeepData(rootKey + '.' + originKey, vmData, vm, data);
            }
            // 标记是否是通过this.Obj = {} 赋值印发的改动，解决少更新问题#1305
            vmData.__newReference = false;
          }
        } catch (e) {
          console.log(e, rootKey, originKey, vmData, data);
        }
      }

      function getRootKey(vm, rootKey) {
        if (!vm.$parent.$attrs) {
          rootKey = '$root.0' + KEY_SEP$1 + rootKey;
          return rootKey;
        } else {
          rootKey = vm.$parent.$attrs.mpcomid + KEY_SEP$1 + rootKey;
          return getRootKey(vm.$parent, rootKey);
        }
      }

      function diffData(vm, data) {
        var vmData = vm._data || {};
        var vmProps = vm._props || {};
        var rootKey = '';
        if (!vm.$attrs) {
          rootKey = '$root.0';
        } else {
          rootKey = getRootKey(vm, vm.$attrs.mpcomid);
        }
        Vue$3.nextTick(function () {
          cleanKeyPath(vm);
        });
        // console.log(rootKey)

        // 值类型变量不考虑优化，还是直接更新
        var __keyPathOnThis = vmData.__keyPath || vm.__keyPath || {};
        delete vm.__keyPath;
        delete vmData.__keyPath;
        delete vmProps.__keyPath;
        if (vm._mpValueSet === 'done') {
          // 第二次赋值才进行缩减操作
          Object.keys(vmData).forEach(function (vmDataItemKey) {
            if (vmData[vmDataItemKey] instanceof Object) {
              // 引用类型
              minifyDeepData(rootKey, vmDataItemKey, vmData[vmDataItemKey], data, vm._mpValueSet, vm);
            } else if (vmData[vmDataItemKey] !== undefined) {
              // _data上的值属性只有要更新的时候才赋值
              if (__keyPathOnThis[vmDataItemKey] === true) {
                data[rootKey + '.' + vmDataItemKey] = vmData[vmDataItemKey];
              }
            }
          });

          Object.keys(vmProps).forEach(function (vmPropsItemKey) {
            if (vmProps[vmPropsItemKey] instanceof Object) {
              // 引用类型
              minifyDeepData(rootKey, vmPropsItemKey, vmProps[vmPropsItemKey], data, vm._mpValueSet, vm);
            } else if (vmProps[vmPropsItemKey] !== undefined) {
              data[rootKey + '.' + vmPropsItemKey] = vmProps[vmPropsItemKey];
            }
            // _props上的值属性只有要更新的时候才赋值
          });

          // 检查完data和props,最后补上_mpProps & _computedWatchers
          var vmMpProps = vm._mpProps || {};
          var vmComputedWatchers = vm._computedWatchers || {};
          Object.keys(vmMpProps).forEach(function (mpItemKey) {
            data[rootKey + '.' + mpItemKey] = vm[mpItemKey];
          });
          Object.keys(vmComputedWatchers).forEach(function (computedItemKey) {
            data[rootKey + '.' + computedItemKey] = vm[computedItemKey];
          });
          // 更新的时候要删除$root.0:{},否则会覆盖原正确数据
          delete data[rootKey];
        }
        if (vm._mpValueSet === undefined) {
          // 第一次设置数据成功后，标记位置true,再更新到这个节点如果没有keyPath数组认为不需要更新
          vm._mpValueSet = 'done';
        }
        if (Vue$3.config._mpTrace) {
          // console.log('更新VM节点', vm)
          // console.log('实际传到Page.setData数据', data)
          diffLog(data);
        }
      }

      // 节流方法，性能优化
      // 全局的命名约定，为了节省编译的包大小一律采取形象的缩写，说明如下。
      // $c === $child
      // $k === $comKey

      // 新型的被拍平的数据结构
      // {
      //   $root: {
      //     '1-1'{
      //       // ... data
      //     },
      //     '1.2-1': {
      //       // ... data1
      //     },
      //     '1.2-2': {
      //       // ... data2
      //     }
      //   }
      // }

      var KEY_SEP = '_';

      function getVmData(vm) {
        // 确保当前 vm 所有数据被同步
        var dataKeys = [].concat(Object.keys(vm._data || {}), Object.keys(vm._props || {}), Object.keys(vm._mpProps || {}), Object.keys(vm._computedWatchers || {}));
        return dataKeys.reduce(function (res, key) {
          res[key] = vm[key];
          return res;
        }, {});
      }

      function getParentComKey(vm, res) {
        if (res === void 0) res = [];

        var ref = vm || {};
        var $parent = ref.$parent;
        if (!$parent) {
          return res;
        }
        res.unshift(getComKey($parent));
        if ($parent.$parent) {
          return getParentComKey($parent, res);
        }
        return res;
      }

      function formatVmData(vm) {
        var $p = getParentComKey(vm).join(KEY_SEP);
        var $k = $p + ($p ? KEY_SEP : '') + getComKey(vm);

        // getVmData 这儿获取当前组件内的所有数据，包含 props、computed 的数据
        // 改动 vue.runtime 所获的的核心能力
        var data = Object.assign(getVmData(vm), { $k: $k, $kk: "" + $k + KEY_SEP, $p: $p });
        var key = '$root.' + $k;
        var res = {};
        res[key] = data;
        return res;
      }

      function collectVmData(vm, res) {
        if (res === void 0) res = {};

        var vms = vm.$children;
        if (vms && vms.length) {
          vms.forEach(function (v) {
            return collectVmData(v, res);
          });
        }
        return Object.assign(res, formatVmData(vm));
      }

      /**
       * 频率控制 返回函数连续调用时，func 执行频率限定为 次 / wait
       * 自动合并 data
       *
       * @param  {function}   func      传入函数
       * @param  {number}     wait      表示时间窗口的间隔
       * @param  {object}     options   如果想忽略开始边界上的调用，传入{leading: false}。
       *                                如果想忽略结尾边界上的调用，传入{trailing: false}
       * @return {function}             返回客户调用函数
       */
      function throttle(func, wait, options) {
        var context, args, result;
        var timeout = null;
        // 上次执行时间点
        var previous = 0;
        if (!options) {
          options = {};
        }
        // 延迟执行函数
        function later() {
          // 若设定了开始边界不执行选项，上次执行时间始终为0
          previous = options.leading === false ? 0 : Date.now();
          timeout = null;
          result = func.apply(context, args);
          if (!timeout) {
            context = args = null;
          }
        }
        return function (handle, data) {
          var now = Date.now();
          // 首次执行时，如果设定了开始边界不执行选项，将上次执行时间设定为当前时间。
          if (!previous && options.leading === false) {
            previous = now;
          }
          // 延迟执行时间间隔
          var remaining = wait - (now - previous);
          context = this;
          args = args ? [handle, Object.assign(args[1], data)] : [handle, data];
          // 延迟时间间隔remaining小于等于0，表示上次执行至此所间隔时间已经超过一个时间窗口
          // remaining大于时间窗口wait，表示客户端系统时间被调整过
          if (remaining <= 0 || remaining > wait) {
            clearTimeout(timeout);
            timeout = null;
            previous = now;
            result = func.apply(context, args);
            if (!timeout) {
              context = args = null;
            }
            // 如果延迟执行不存在，且没有设定结尾边界不执行选项
          } else if (!timeout && options.trailing !== false) {
            timeout = setTimeout(later, remaining);
          }
          return result;
        };
      }

      // 优化频繁的 setData: https://mp.weixin.qq.com/debug/wxadoc/dev/framework/performance/tips.html
      var throttleSetData = throttle(function (handle, data) {
        handle(data);
      }, 50);

      function getPage(vm) {
        var rootVueVM = vm.$root;
        var ref = rootVueVM.$mp || {};
        var mpType = ref.mpType;if (mpType === void 0) mpType = '';
        var page = ref.page;

        // 优化后台态页面进行 setData: https://mp.weixin.qq.com/debug/wxadoc/dev/framework/performance/tips.html
        if (mpType === 'app' || !page || typeof page.setData !== 'function') {
          return;
        }
        return page;
      }

      // 优化js变量动态变化时候引起全量更新
      // 优化每次 setData 都传递大量新数据
      function updateDataToMP() {
        var page = getPage(this);
        if (!page) {
          return;
        }

        var data = formatVmData(this);
        diffData(this, data);
        throttleSetData(page.setData.bind(page), data);
      }

      function initDataToMP() {
        var page = getPage(this);
        if (!page) {
          return;
        }

        var data = collectVmData(this.$root);
        page.setData(data);
      }

      // 虚拟dom的compid与真实dom的comkey匹配，多层嵌套的先补齐虚拟dom的compid直到完全匹配为止
      function isVmKeyMatchedCompkey(k, comkey) {
        if (!k || !comkey) {
          return false;
        }
        // 完全匹配 comkey = '1_0_1', k = '1_0_1'
        // 部分匹配 comkey = '1_0_10_1', k = '1_0_10'
        // k + KEY_SEP防止k = '1_0_1'误匹配comkey = '1_0_10_1'
        return comkey === k || comkey.indexOf(k + KEY_SEP$2) === 0;
      }

      function getVM(vm, comkeys) {
        if (comkeys === void 0) comkeys = [];

        var keys = comkeys.slice(1);
        if (!keys.length) {
          return vm;
        }

        // bugfix #1375: 虚拟dom的compid和真实dom的comkey在组件嵌套时匹配出错，comid会丢失前缀，需要从父节点补充
        var comkey = keys.join(KEY_SEP$2);
        var comidPrefix = '';
        return keys.reduce(function (res, key) {
          var len = res.$children.length;
          for (var i = 0; i < len; i++) {
            var v = res.$children[i];
            var k = getComKey(v);
            if (comidPrefix) {
              k = comidPrefix + KEY_SEP$2 + k;
            }
            // 找到匹配的父节点
            if (isVmKeyMatchedCompkey(k, comkey)) {
              comidPrefix = k;
              res = v;
              return res;
            }
          }
          return res;
        }, vm);
      }

      function getHandle(vnode, eventid, eventTypes) {
        if (eventTypes === void 0) eventTypes = [];

        var res = [];
        if (!vnode || !vnode.tag) {
          return res;
        }

        var ref = vnode || {};
        var data = ref.data;if (data === void 0) data = {};
        var children = ref.children;if (children === void 0) children = [];
        var componentInstance = ref.componentInstance;
        if (componentInstance) {
          // 增加 slot 情况的处理
          // Object.values 会多增加几行编译后的代码
          Object.keys(componentInstance.$slots).forEach(function (slotKey) {
            var slot = componentInstance.$slots[slotKey];
            var slots = Array.isArray(slot) ? slot : [slot];
            slots.forEach(function (node) {
              res = res.concat(getHandle(node, eventid, eventTypes));
            });
          });
        } else {
          // 避免遍历超出当前组件的 vm
          children.forEach(function (node) {
            res = res.concat(getHandle(node, eventid, eventTypes));
          });
        }

        var attrs = data.attrs;
        var on = data.on;
        if (attrs && on && attrs['eventid'] === eventid) {
          eventTypes.forEach(function (et) {
            var h = on[et];
            if (typeof h === 'function') {
              res.push(h);
            } else if (Array.isArray(h)) {
              res = res.concat(h);
            }
          });
          return res;
        }

        return res;
      }

      function getWebEventByMP(e) {
        var type = e.type;
        var timeStamp = e.timeStamp;
        var touches = e.touches;
        var detail = e.detail;if (detail === void 0) detail = {};
        var target = e.target;if (target === void 0) target = {};
        var currentTarget = e.currentTarget;if (currentTarget === void 0) currentTarget = {};
        var x = detail.x;
        var y = detail.y;
        var event = {
          mp: e,
          type: type,
          timeStamp: timeStamp,
          x: x,
          y: y,
          target: Object.assign({}, target, detail),
          currentTarget: currentTarget,
          stopPropagation: noop,
          preventDefault: noop
        };

        if (touches && touches.length) {
          Object.assign(event, touches[0]);
          event.touches = touches;
        }
        return event;
      }

      var KEY_SEP$2 = '_';
      function handleProxyWithVue(e) {
        var rootVueVM = this.$root;
        var type = e.type;
        var target = e.target;if (target === void 0) target = {};
        var currentTarget = e.currentTarget;
        var ref = currentTarget || target;
        var dataset = ref.dataset;if (dataset === void 0) dataset = {};
        var comkey = dataset.comkey;if (comkey === void 0) comkey = '';
        var eventid = dataset.eventid;
        var vm = getVM(rootVueVM, comkey.split(KEY_SEP$2));

        if (!vm) {
          return;
        }

        var webEventTypes = eventTypeMap[type] || [type];
        var handles = getHandle(vm._vnode, eventid, webEventTypes);

        // TODO, enevt 还需要处理更多
        // https://developer.mozilla.org/zh-CN/docs/Web/API/Event
        if (handles.length) {
          var event = getWebEventByMP(e);
          if (handles.length === 1) {
            var result = handles[0](event);
            return result;
          }
          handles.forEach(function (h) {
            return h(event);
          });
        }
      }

      // for platforms
      // import config from 'core/config'
      // install platform specific utils
      Vue$3.config.mustUseProp = mustUseProp;
      Vue$3.config.isReservedTag = isReservedTag;
      Vue$3.config.isReservedAttr = isReservedAttr;
      Vue$3.config.getTagNamespace = getTagNamespace;
      Vue$3.config.isUnknownElement = isUnknownElement;

      // install platform patch function
      Vue$3.prototype.__patch__ = patch;

      // public mount method
      Vue$3.prototype.$mount = function (el, hydrating) {
        var this$1 = this;

        // el = el && inBrowser ? query(el) : undefined
        // return mountComponent(this, el, hydrating)

        // 初始化小程序生命周期相关
        var options = this.$options;

        if (options && (options.render || options.mpType)) {
          var mpType = options.mpType;if (mpType === void 0) mpType = 'page';
          return this._initMP(mpType, function () {
            return mountComponent(this$1, undefined, undefined);
          });
        } else {
          return mountComponent(this, undefined, undefined);
        }
      };

      // for mp
      Vue$3.prototype._initMP = initMP;

      Vue$3.prototype.$updateDataToMP = updateDataToMP;
      Vue$3.prototype._initDataToMP = initDataToMP;

      Vue$3.prototype.$handleProxyWithVue = handleProxyWithVue;

      /*  */

      return Vue$3;
    });

    /* WEBPACK VAR INJECTION */
  }).call(exports, __webpack_require__(44));

  /***/
},
/* 2 */
/***/function (module, exports) {

  // https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
  var global = module.exports = typeof window != 'undefined' && window.Math == Math ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
  if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


  /***/
},
/* 3 */
/***/function (module, exports, __webpack_require__) {

  var store = __webpack_require__(32)('wks');
  var uid = __webpack_require__(33);
  var _Symbol = __webpack_require__(2).Symbol;
  var USE_SYMBOL = typeof _Symbol == 'function';

  var $exports = module.exports = function (name) {
    return store[name] || (store[name] = USE_SYMBOL && _Symbol[name] || (USE_SYMBOL ? _Symbol : uid)('Symbol.' + name));
  };

  $exports.store = store;

  /***/
},
/* 4 */
/***/function (module, exports) {

  var core = module.exports = { version: '2.6.5' };
  if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


  /***/
},
/* 5 */
/***/function (module, exports, __webpack_require__) {

  var isObject = __webpack_require__(8);
  module.exports = function (it) {
    if (!isObject(it)) throw TypeError(it + ' is not an object!');
    return it;
  };

  /***/
},
/* 6 */
/***/function (module, exports, __webpack_require__) {

  module.exports = { "default": __webpack_require__(111), __esModule: true };

  /***/
},
/* 7 */
/***/function (module, exports, __webpack_require__) {

  var dP = __webpack_require__(14);
  var createDesc = __webpack_require__(30);
  module.exports = __webpack_require__(9) ? function (object, key, value) {
    return dP.f(object, key, createDesc(1, value));
  } : function (object, key, value) {
    object[key] = value;
    return object;
  };

  /***/
},
/* 8 */
/***/function (module, exports) {

  module.exports = function (it) {
    return (typeof it === 'undefined' ? 'undefined' : _typeof2(it)) === 'object' ? it !== null : typeof it === 'function';
  };

  /***/
},
/* 9 */
/***/function (module, exports, __webpack_require__) {

  // Thank's IE8 for his funny defineProperty
  module.exports = !__webpack_require__(29)(function () {
    return Object.defineProperty({}, 'a', { get: function get() {
        return 7;
      } }).a != 7;
  });

  /***/
},
/* 10 */
/***/function (module, exports) {

  module.exports = {};

  /***/
},
/* 11 */
/***/function (module, exports, __webpack_require__) {

  var global = __webpack_require__(2);
  var core = __webpack_require__(4);
  var ctx = __webpack_require__(12);
  var hide = __webpack_require__(7);
  var has = __webpack_require__(15);
  var PROTOTYPE = 'prototype';

  var $export = function $export(type, name, source) {
    var IS_FORCED = type & $export.F;
    var IS_GLOBAL = type & $export.G;
    var IS_STATIC = type & $export.S;
    var IS_PROTO = type & $export.P;
    var IS_BIND = type & $export.B;
    var IS_WRAP = type & $export.W;
    var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
    var expProto = exports[PROTOTYPE];
    var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
    var key, own, out;
    if (IS_GLOBAL) source = name;
    for (key in source) {
      // contains in native
      own = !IS_FORCED && target && target[key] !== undefined;
      if (own && has(exports, key)) continue;
      // export native or passed
      out = own ? target[key] : source[key];
      // prevent global pollution for namespaces
      exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
      // bind timers to global for call from export context
      : IS_BIND && own ? ctx(out, global)
      // wrap global constructors for prevent change them in library
      : IS_WRAP && target[key] == out ? function (C) {
        var F = function F(a, b, c) {
          if (this instanceof C) {
            switch (arguments.length) {
              case 0:
                return new C();
              case 1:
                return new C(a);
              case 2:
                return new C(a, b);
            }return new C(a, b, c);
          }return C.apply(this, arguments);
        };
        F[PROTOTYPE] = C[PROTOTYPE];
        return F;
        // make static versions for prototype methods
      }(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
      // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
      if (IS_PROTO) {
        (exports.virtual || (exports.virtual = {}))[key] = out;
        // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
        if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
      }
    }
  };
  // type bitmap
  $export.F = 1; // forced
  $export.G = 2; // global
  $export.S = 4; // static
  $export.P = 8; // proto
  $export.B = 16; // bind
  $export.W = 32; // wrap
  $export.U = 64; // safe
  $export.R = 128; // real proto method for `library`
  module.exports = $export;

  /***/
},
/* 12 */
/***/function (module, exports, __webpack_require__) {

  // optional / simple context binding
  var aFunction = __webpack_require__(13);
  module.exports = function (fn, that, length) {
    aFunction(fn);
    if (that === undefined) return fn;
    switch (length) {
      case 1:
        return function (a) {
          return fn.call(that, a);
        };
      case 2:
        return function (a, b) {
          return fn.call(that, a, b);
        };
      case 3:
        return function (a, b, c) {
          return fn.call(that, a, b, c);
        };
    }
    return function () /* ...args */{
      return fn.apply(that, arguments);
    };
  };

  /***/
},
/* 13 */
/***/function (module, exports) {

  module.exports = function (it) {
    if (typeof it != 'function') throw TypeError(it + ' is not a function!');
    return it;
  };

  /***/
},
/* 14 */
/***/function (module, exports, __webpack_require__) {

  var anObject = __webpack_require__(5);
  var IE8_DOM_DEFINE = __webpack_require__(54);
  var toPrimitive = __webpack_require__(55);
  var dP = Object.defineProperty;

  exports.f = __webpack_require__(9) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
    anObject(O);
    P = toPrimitive(P, true);
    anObject(Attributes);
    if (IE8_DOM_DEFINE) try {
      return dP(O, P, Attributes);
    } catch (e) {/* empty */}
    if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
    if ('value' in Attributes) O[P] = Attributes.value;
    return O;
  };

  /***/
},
/* 15 */
/***/function (module, exports) {

  var hasOwnProperty = {}.hasOwnProperty;
  module.exports = function (it, key) {
    return hasOwnProperty.call(it, key);
  };

  /***/
},
/* 16 */
/***/function (module, exports) {

  var toString = {}.toString;

  module.exports = function (it) {
    return toString.call(it).slice(8, -1);
  };

  /***/
},
/* 17 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony export (immutable) */
  __webpack_exports__["f"] = formatTime;
  /* harmony export (immutable) */__webpack_exports__["d"] = dateNow;
  /* unused harmony export dateFeature */
  /* harmony export (immutable) */__webpack_exports__["e"] = datePast;
  /* harmony export (immutable) */__webpack_exports__["g"] = formatYYYYMMDD;
  /* unused harmony export formatTimestamp */
  /* harmony export (immutable) */__webpack_exports__["c"] = checkTaxNo;
  /* harmony export (immutable) */__webpack_exports__["a"] = checkNumber;
  /* harmony export (immutable) */__webpack_exports__["b"] = checkPhone;
  /* unused harmony export checkEmpty */
  function formatNumber(n) {
    var str = n.toString();
    return str[1] ? str : '0' + str;
  }

  function formatTime(date) {
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();

    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();

    var t1 = [year, month, day].map(formatNumber).join('/');
    var t2 = [hour, minute, second].map(formatNumber).join(':');

    return t1 + ' ' + t2;
  }

  function dateNow() {
    var date = new Date();
    date.setDate(date.getDate() + 1);
    return date.getTime();
  }

  function dateFeature() {
    var date = new Date();
    date.setFullYear(date.getFullYear() + 1);
    return date.getTime();
  }

  function datePast() {
    var date = new Date();
    date.setMonth(date.getMonth() - 3);
    return date.getTime();
  }

  // 时间戳 => YYYY-MM-DD
  function formatYYYYMMDD(date) {
    var unixTimestamp = new Date(date);
    var year = unixTimestamp.getFullYear();
    var month = unixTimestamp.getMonth() + 1;
    var day = unixTimestamp.getDate();
    return year + '-' + month + '-' + day;
  }

  // YYYY-MM-DD => 时间戳
  function formatTimestamp(date) {
    var timeStamp = new Date(date);
    return timeStamp.getTime();
  }

  // 当前时间 yyyymmdd
  function formatNow() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = '' + year + month + strDate;
    return currentdate;
  }

  // 过去三个月 yyyymmdd
  function formatPast() {
    var date = new Date();
    date.setMonth(date.getMonth() - 3);
    var year = date.getFullYear();

    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = '' + year + month + strDate;
    return currentdate;
  }

  // 明年 yyyymmdd
  function formatFeature() {
    var date = new Date();
    var year = date.getFullYear();
    year += 1;
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = '' + year + month + strDate;
    return currentdate;
  }

  function checkTaxNo(code) {
    var patrn = /^[0-9A-Z]+$/;
    // 大写校验
    if (patrn.test(code) === false) {
      return false;
    }
    if (code.length < 18 || code.length > 20) {
      return false;
    }
    return true;
  }
  function checkNumber(code) {
    var patrn = /^[0-9]+$/;
    // 数字校验
    if (patrn.test(code) === false) {
      return false;
    }
    return true;
  }
  function checkPhone(code) {
    var patrn = /^[0-9]+$/;
    // 数字校验
    if (patrn.test(code) === false) {
      return false;
    }
    if (code.length < 7 || code.length > 11) {
      return false;
    }
    return true;
  }
  function checkEmpty(code) {
    if (code.length === 0) {
      return false;
    }
    return true;
  }

  /* unused harmony default export */var _unused_webpack_default_export = {
    formatNumber: formatNumber,
    formatTime: formatTime,
    dateNow: dateNow,
    dateFeature: dateFeature,
    datePast: datePast,
    formatYYYYMMDD: formatYYYYMMDD,
    formatFeature: formatFeature,
    formatPast: formatPast,
    formatNow: formatNow,
    formatTimestamp: formatTimestamp,
    checkTaxNo: checkTaxNo,
    checkNumber: checkNumber
  };

  /***/
},
/* 18 */
/***/function (module, exports, __webpack_require__) {

  module.exports = { "default": __webpack_require__(50), __esModule: true };

  /***/
},
/* 19 */
/***/function (module, exports) {

  // 7.1.4 ToInteger
  var ceil = Math.ceil;
  var floor = Math.floor;
  module.exports = function (it) {
    return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
  };

  /***/
},
/* 20 */
/***/function (module, exports) {

  // 7.2.1 RequireObjectCoercible(argument)
  module.exports = function (it) {
    if (it == undefined) throw TypeError("Can't call method on  " + it);
    return it;
  };

  /***/
},
/* 21 */
/***/function (module, exports) {

  module.exports = true;

  /***/
},
/* 22 */
/***/function (module, exports, __webpack_require__) {

  var isObject = __webpack_require__(8);
  var document = __webpack_require__(2).document;
  // typeof document.createElement is 'object' in old IE
  var is = isObject(document) && isObject(document.createElement);
  module.exports = function (it) {
    return is ? document.createElement(it) : {};
  };

  /***/
},
/* 23 */
/***/function (module, exports, __webpack_require__) {

  // to indexed object, toObject with fallback for non-array-like ES3 strings
  var IObject = __webpack_require__(62);
  var defined = __webpack_require__(20);
  module.exports = function (it) {
    return IObject(defined(it));
  };

  /***/
},
/* 24 */
/***/function (module, exports, __webpack_require__) {

  var shared = __webpack_require__(32)('keys');
  var uid = __webpack_require__(33);
  module.exports = function (key) {
    return shared[key] || (shared[key] = uid(key));
  };

  /***/
},
/* 25 */
/***/function (module, exports, __webpack_require__) {

  var def = __webpack_require__(14).f;
  var has = __webpack_require__(15);
  var TAG = __webpack_require__(3)('toStringTag');

  module.exports = function (it, tag, stat) {
    if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
  };

  /***/
},
/* 26 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  // 25.4.1.5 NewPromiseCapability(C)

  var aFunction = __webpack_require__(13);

  function PromiseCapability(C) {
    var resolve, reject;
    this.promise = new C(function ($$resolve, $$reject) {
      if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
      resolve = $$resolve;
      reject = $$reject;
    });
    this.resolve = aFunction(resolve);
    this.reject = aFunction(reject);
  }

  module.exports.f = function (C) {
    return new PromiseCapability(C);
  };

  /***/
},,
/* 27 */
/* 28 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var LIBRARY = __webpack_require__(21);
  var $export = __webpack_require__(11);
  var redefine = __webpack_require__(56);
  var hide = __webpack_require__(7);
  var Iterators = __webpack_require__(10);
  var $iterCreate = __webpack_require__(57);
  var setToStringTag = __webpack_require__(25);
  var getPrototypeOf = __webpack_require__(65);
  var ITERATOR = __webpack_require__(3)('iterator');
  var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
  var FF_ITERATOR = '@@iterator';
  var KEYS = 'keys';
  var VALUES = 'values';

  var returnThis = function returnThis() {
    return this;
  };

  module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
    $iterCreate(Constructor, NAME, next);
    var getMethod = function getMethod(kind) {
      if (!BUGGY && kind in proto) return proto[kind];
      switch (kind) {
        case KEYS:
          return function keys() {
            return new Constructor(this, kind);
          };
        case VALUES:
          return function values() {
            return new Constructor(this, kind);
          };
      }return function entries() {
        return new Constructor(this, kind);
      };
    };
    var TAG = NAME + ' Iterator';
    var DEF_VALUES = DEFAULT == VALUES;
    var VALUES_BUG = false;
    var proto = Base.prototype;
    var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
    var $default = $native || getMethod(DEFAULT);
    var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
    var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
    var methods, key, IteratorPrototype;
    // Fix native
    if ($anyNative) {
      IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
      if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
        // Set @@toStringTag to native iterators
        setToStringTag(IteratorPrototype, TAG, true);
        // fix for some old engines
        if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
      }
    }
    // fix Array#{values, @@iterator}.name in V8 / FF
    if (DEF_VALUES && $native && $native.name !== VALUES) {
      VALUES_BUG = true;
      $default = function values() {
        return $native.call(this);
      };
    }
    // Define iterator
    if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
      hide(proto, ITERATOR, $default);
    }
    // Plug for library
    Iterators[NAME] = $default;
    Iterators[TAG] = returnThis;
    if (DEFAULT) {
      methods = {
        values: DEF_VALUES ? $default : getMethod(VALUES),
        keys: IS_SET ? $default : getMethod(KEYS),
        entries: $entries
      };
      if (FORCED) for (key in methods) {
        if (!(key in proto)) redefine(proto, key, methods[key]);
      } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
    }
    return methods;
  };

  /***/
},
/* 29 */
/***/function (module, exports) {

  module.exports = function (exec) {
    try {
      return !!exec();
    } catch (e) {
      return true;
    }
  };

  /***/
},
/* 30 */
/***/function (module, exports) {

  module.exports = function (bitmap, value) {
    return {
      enumerable: !(bitmap & 1),
      configurable: !(bitmap & 2),
      writable: !(bitmap & 4),
      value: value
    };
  };

  /***/
},
/* 31 */
/***/function (module, exports, __webpack_require__) {

  // 7.1.15 ToLength
  var toInteger = __webpack_require__(19);
  var min = Math.min;
  module.exports = function (it) {
    return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
  };

  /***/
},
/* 32 */
/***/function (module, exports, __webpack_require__) {

  var core = __webpack_require__(4);
  var global = __webpack_require__(2);
  var SHARED = '__core-js_shared__';
  var store = global[SHARED] || (global[SHARED] = {});

  (module.exports = function (key, value) {
    return store[key] || (store[key] = value !== undefined ? value : {});
  })('versions', []).push({
    version: core.version,
    mode: __webpack_require__(21) ? 'pure' : 'global',
    copyright: '© 2019 Denis Pushkarev (zloirock.ru)'
  });

  /***/
},
/* 33 */
/***/function (module, exports) {

  var id = 0;
  var px = Math.random();
  module.exports = function (key) {
    return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
  };

  /***/
},
/* 34 */
/***/function (module, exports) {

  // IE 8- don't enum bug keys
  module.exports = 'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'.split(',');

  /***/
},
/* 35 */
/***/function (module, exports, __webpack_require__) {

  var document = __webpack_require__(2).document;
  module.exports = document && document.documentElement;

  /***/
},
/* 36 */
/***/function (module, exports, __webpack_require__) {

  // getting tag from 19.1.3.6 Object.prototype.toString()
  var cof = __webpack_require__(16);
  var TAG = __webpack_require__(3)('toStringTag');
  // ES3 wrong here
  var ARG = cof(function () {
    return arguments;
  }()) == 'Arguments';

  // fallback for IE11 Script Access Denied error
  var tryGet = function tryGet(it, key) {
    try {
      return it[key];
    } catch (e) {/* empty */}
  };

  module.exports = function (it) {
    var O, T, B;
    return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
  };

  /***/
},
/* 37 */
/***/function (module, exports, __webpack_require__) {

  // 7.3.20 SpeciesConstructor(O, defaultConstructor)
  var anObject = __webpack_require__(5);
  var aFunction = __webpack_require__(13);
  var SPECIES = __webpack_require__(3)('species');
  module.exports = function (O, D) {
    var C = anObject(O).constructor;
    var S;
    return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
  };

  /***/
},
/* 38 */
/***/function (module, exports, __webpack_require__) {

  var ctx = __webpack_require__(12);
  var invoke = __webpack_require__(77);
  var html = __webpack_require__(35);
  var cel = __webpack_require__(22);
  var global = __webpack_require__(2);
  var process = global.process;
  var setTask = global.setImmediate;
  var clearTask = global.clearImmediate;
  var MessageChannel = global.MessageChannel;
  var Dispatch = global.Dispatch;
  var counter = 0;
  var queue = {};
  var ONREADYSTATECHANGE = 'onreadystatechange';
  var defer, channel, port;
  var run = function run() {
    var id = +this;
    // eslint-disable-next-line no-prototype-builtins
    if (queue.hasOwnProperty(id)) {
      var fn = queue[id];
      delete queue[id];
      fn();
    }
  };
  var listener = function listener(event) {
    run.call(event.data);
  };
  // Node.js 0.9+ & IE10+ has setImmediate, otherwise:
  if (!setTask || !clearTask) {
    setTask = function setImmediate(fn) {
      var args = [];
      var i = 1;
      while (arguments.length > i) {
        args.push(arguments[i++]);
      }queue[++counter] = function () {
        // eslint-disable-next-line no-new-func
        invoke(typeof fn == 'function' ? fn : Function(fn), args);
      };
      defer(counter);
      return counter;
    };
    clearTask = function clearImmediate(id) {
      delete queue[id];
    };
    // Node.js 0.8-
    if (__webpack_require__(16)(process) == 'process') {
      defer = function defer(id) {
        process.nextTick(ctx(run, id, 1));
      };
      // Sphere (JS game engine) Dispatch API
    } else if (Dispatch && Dispatch.now) {
      defer = function defer(id) {
        Dispatch.now(ctx(run, id, 1));
      };
      // Browsers with MessageChannel, includes WebWorkers
    } else if (MessageChannel) {
      channel = new MessageChannel();
      port = channel.port2;
      channel.port1.onmessage = listener;
      defer = ctx(port.postMessage, port, 1);
      // Browsers with postMessage, skip WebWorkers
      // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
    } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
      defer = function defer(id) {
        global.postMessage(id + '', '*');
      };
      global.addEventListener('message', listener, false);
      // IE8-
    } else if (ONREADYSTATECHANGE in cel('script')) {
      defer = function defer(id) {
        html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
          html.removeChild(this);
          run.call(id);
        };
      };
      // Rest old browsers
    } else {
      defer = function defer(id) {
        setTimeout(ctx(run, id, 1), 0);
      };
    }
  }
  module.exports = {
    set: setTask,
    clear: clearTask
  };

  /***/
},
/* 39 */
/***/function (module, exports) {

  module.exports = function (exec) {
    try {
      return { e: false, v: exec() };
    } catch (e) {
      return { e: true, v: e };
    }
  };

  /***/
},
/* 40 */
/***/function (module, exports, __webpack_require__) {

  var anObject = __webpack_require__(5);
  var isObject = __webpack_require__(8);
  var newPromiseCapability = __webpack_require__(26);

  module.exports = function (C, x) {
    anObject(C);
    if (isObject(x) && x.constructor === C) return x;
    var promiseCapability = newPromiseCapability.f(C);
    var resolve = promiseCapability.resolve;
    resolve(x);
    return promiseCapability.promise;
  };

  /***/
},,
/* 41 */
/* 42 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony export (binding) */
  __webpack_require__.d(__webpack_exports__, "a", function () {
    return KEYS;
  });
  var KEYS = {
    TOKEN_KEY: 'NJTOKEN',
    STATUS_KEY: 'STATUSKEY',
    SELECT_INVOCE: 'SELECT_INVOCE',
    SEARCH_BACK_KEY: 'SEARCH_BACK_KEY'
  };

  /* unused harmony default export */var _unused_webpack_default_export = {
    KEYS: KEYS
  };

  /***/
},,
/* 43 */
/* 44 */
/***/function (module, exports) {

  var g;

  // This works in non-strict mode
  g = function () {
    return typeof global !== 'undefined' ? global : this;
  }();

  try {
    // This works if eval is allowed (see CSP)
    g = g || Function("return this")() || (1, eval)("this");
  } catch (e) {
    // This works if the window reference is available
    if ((typeof window === 'undefined' ? 'undefined' : _typeof2(window)) === "object") g = window;
  }

  // g can still be undefined, but nothing to do about it...
  // We return undefined, instead of nothing here, so it's
  // easier to handle this case. if(!global) { ...}

  module.exports = g;

  /***/
},,,
/* 45 */
/* 46 */
/* 47 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* harmony export (immutable) */
  __webpack_exports__["a"] = listToStyles;
  /**
   * Translates the list format produced by css-loader into something
   * easier to manipulate.
   */
  function listToStyles(parentId, list) {
    var styles = [];
    var newStyles = {};
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      var id = item[0];
      var css = item[1];
      var media = item[2];
      var sourceMap = item[3];
      var part = {
        id: parentId + ':' + i,
        css: css,
        media: media,
        sourceMap: sourceMap
      };
      if (!newStyles[id]) {
        styles.push(newStyles[id] = { id: id, parts: [part] });
      } else {
        newStyles[id].parts.push(part);
      }
    }
    return styles;
  }

  /***/
},,,
/* 48 */
/* 49 */
/* 50 */
/***/function (module, exports, __webpack_require__) {

  __webpack_require__(51);
  __webpack_require__(52);
  __webpack_require__(67);
  __webpack_require__(71);
  __webpack_require__(83);
  __webpack_require__(84);
  module.exports = __webpack_require__(4).Promise;

  /***/
},
/* 51 */
/***/function (module, exports) {

  /***/},
/* 52 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var $at = __webpack_require__(53)(true);

  // 21.1.3.27 String.prototype[@@iterator]()
  __webpack_require__(28)(String, 'String', function (iterated) {
    this._t = String(iterated); // target
    this._i = 0; // next index
    // 21.1.5.2.1 %StringIteratorPrototype%.next()
  }, function () {
    var O = this._t;
    var index = this._i;
    var point;
    if (index >= O.length) return { value: undefined, done: true };
    point = $at(O, index);
    this._i += point.length;
    return { value: point, done: false };
  });

  /***/
},
/* 53 */
/***/function (module, exports, __webpack_require__) {

  var toInteger = __webpack_require__(19);
  var defined = __webpack_require__(20);
  // true  -> String#at
  // false -> String#codePointAt
  module.exports = function (TO_STRING) {
    return function (that, pos) {
      var s = String(defined(that));
      var i = toInteger(pos);
      var l = s.length;
      var a, b;
      if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
      a = s.charCodeAt(i);
      return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff ? TO_STRING ? s.charAt(i) : a : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
    };
  };

  /***/
},
/* 54 */
/***/function (module, exports, __webpack_require__) {

  module.exports = !__webpack_require__(9) && !__webpack_require__(29)(function () {
    return Object.defineProperty(__webpack_require__(22)('div'), 'a', { get: function get() {
        return 7;
      } }).a != 7;
  });

  /***/
},
/* 55 */
/***/function (module, exports, __webpack_require__) {

  // 7.1.1 ToPrimitive(input [, PreferredType])
  var isObject = __webpack_require__(8);
  // instead of the ES6 spec version, we didn't implement @@toPrimitive case
  // and the second argument - flag - preferred type is a string
  module.exports = function (it, S) {
    if (!isObject(it)) return it;
    var fn, val;
    if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
    if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    throw TypeError("Can't convert object to primitive value");
  };

  /***/
},
/* 56 */
/***/function (module, exports, __webpack_require__) {

  module.exports = __webpack_require__(7);

  /***/
},
/* 57 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var create = __webpack_require__(58);
  var descriptor = __webpack_require__(30);
  var setToStringTag = __webpack_require__(25);
  var IteratorPrototype = {};

  // 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
  __webpack_require__(7)(IteratorPrototype, __webpack_require__(3)('iterator'), function () {
    return this;
  });

  module.exports = function (Constructor, NAME, next) {
    Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
    setToStringTag(Constructor, NAME + ' Iterator');
  };

  /***/
},
/* 58 */
/***/function (module, exports, __webpack_require__) {

  // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
  var anObject = __webpack_require__(5);
  var dPs = __webpack_require__(59);
  var enumBugKeys = __webpack_require__(34);
  var IE_PROTO = __webpack_require__(24)('IE_PROTO');
  var Empty = function Empty() {/* empty */};
  var PROTOTYPE = 'prototype';

  // Create object with fake `null` prototype: use iframe Object with cleared prototype
  var _createDict = function createDict() {
    // Thrash, waste and sodomy: IE GC bug
    var iframe = __webpack_require__(22)('iframe');
    var i = enumBugKeys.length;
    var lt = '<';
    var gt = '>';
    var iframeDocument;
    iframe.style.display = 'none';
    __webpack_require__(35).appendChild(iframe);
    iframe.src = 'javascript:'; // eslint-disable-line no-script-url
    // createDict = iframe.contentWindow.Object;
    // html.removeChild(iframe);
    iframeDocument = iframe.contentWindow.document;
    iframeDocument.open();
    iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
    iframeDocument.close();
    _createDict = iframeDocument.F;
    while (i--) {
      delete _createDict[PROTOTYPE][enumBugKeys[i]];
    }return _createDict();
  };

  module.exports = Object.create || function create(O, Properties) {
    var result;
    if (O !== null) {
      Empty[PROTOTYPE] = anObject(O);
      result = new Empty();
      Empty[PROTOTYPE] = null;
      // add "__proto__" for Object.getPrototypeOf polyfill
      result[IE_PROTO] = O;
    } else result = _createDict();
    return Properties === undefined ? result : dPs(result, Properties);
  };

  /***/
},
/* 59 */
/***/function (module, exports, __webpack_require__) {

  var dP = __webpack_require__(14);
  var anObject = __webpack_require__(5);
  var getKeys = __webpack_require__(60);

  module.exports = __webpack_require__(9) ? Object.defineProperties : function defineProperties(O, Properties) {
    anObject(O);
    var keys = getKeys(Properties);
    var length = keys.length;
    var i = 0;
    var P;
    while (length > i) {
      dP.f(O, P = keys[i++], Properties[P]);
    }return O;
  };

  /***/
},
/* 60 */
/***/function (module, exports, __webpack_require__) {

  // 19.1.2.14 / 15.2.3.14 Object.keys(O)
  var $keys = __webpack_require__(61);
  var enumBugKeys = __webpack_require__(34);

  module.exports = Object.keys || function keys(O) {
    return $keys(O, enumBugKeys);
  };

  /***/
},
/* 61 */
/***/function (module, exports, __webpack_require__) {

  var has = __webpack_require__(15);
  var toIObject = __webpack_require__(23);
  var arrayIndexOf = __webpack_require__(63)(false);
  var IE_PROTO = __webpack_require__(24)('IE_PROTO');

  module.exports = function (object, names) {
    var O = toIObject(object);
    var i = 0;
    var result = [];
    var key;
    for (key in O) {
      if (key != IE_PROTO) has(O, key) && result.push(key);
    } // Don't enum bug & hidden keys
    while (names.length > i) {
      if (has(O, key = names[i++])) {
        ~arrayIndexOf(result, key) || result.push(key);
      }
    }return result;
  };

  /***/
},
/* 62 */
/***/function (module, exports, __webpack_require__) {

  // fallback for non-array-like ES3 and non-enumerable old V8 strings
  var cof = __webpack_require__(16);
  // eslint-disable-next-line no-prototype-builtins
  module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
    return cof(it) == 'String' ? it.split('') : Object(it);
  };

  /***/
},
/* 63 */
/***/function (module, exports, __webpack_require__) {

  // false -> Array#indexOf
  // true  -> Array#includes
  var toIObject = __webpack_require__(23);
  var toLength = __webpack_require__(31);
  var toAbsoluteIndex = __webpack_require__(64);
  module.exports = function (IS_INCLUDES) {
    return function ($this, el, fromIndex) {
      var O = toIObject($this);
      var length = toLength(O.length);
      var index = toAbsoluteIndex(fromIndex, length);
      var value;
      // Array#includes uses SameValueZero equality algorithm
      // eslint-disable-next-line no-self-compare
      if (IS_INCLUDES && el != el) while (length > index) {
        value = O[index++];
        // eslint-disable-next-line no-self-compare
        if (value != value) return true;
        // Array#indexOf ignores holes, Array#includes - not
      } else for (; length > index; index++) {
        if (IS_INCLUDES || index in O) {
          if (O[index] === el) return IS_INCLUDES || index || 0;
        }
      }return !IS_INCLUDES && -1;
    };
  };

  /***/
},
/* 64 */
/***/function (module, exports, __webpack_require__) {

  var toInteger = __webpack_require__(19);
  var max = Math.max;
  var min = Math.min;
  module.exports = function (index, length) {
    index = toInteger(index);
    return index < 0 ? max(index + length, 0) : min(index, length);
  };

  /***/
},
/* 65 */
/***/function (module, exports, __webpack_require__) {

  // 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
  var has = __webpack_require__(15);
  var toObject = __webpack_require__(66);
  var IE_PROTO = __webpack_require__(24)('IE_PROTO');
  var ObjectProto = Object.prototype;

  module.exports = Object.getPrototypeOf || function (O) {
    O = toObject(O);
    if (has(O, IE_PROTO)) return O[IE_PROTO];
    if (typeof O.constructor == 'function' && O instanceof O.constructor) {
      return O.constructor.prototype;
    }return O instanceof Object ? ObjectProto : null;
  };

  /***/
},
/* 66 */
/***/function (module, exports, __webpack_require__) {

  // 7.1.13 ToObject(argument)
  var defined = __webpack_require__(20);
  module.exports = function (it) {
    return Object(defined(it));
  };

  /***/
},
/* 67 */
/***/function (module, exports, __webpack_require__) {

  __webpack_require__(68);
  var global = __webpack_require__(2);
  var hide = __webpack_require__(7);
  var Iterators = __webpack_require__(10);
  var TO_STRING_TAG = __webpack_require__(3)('toStringTag');

  var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' + 'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' + 'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' + 'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' + 'TextTrackList,TouchList').split(',');

  for (var i = 0; i < DOMIterables.length; i++) {
    var NAME = DOMIterables[i];
    var Collection = global[NAME];
    var proto = Collection && Collection.prototype;
    if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = Iterators.Array;
  }

  /***/
},
/* 68 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var addToUnscopables = __webpack_require__(69);
  var step = __webpack_require__(70);
  var Iterators = __webpack_require__(10);
  var toIObject = __webpack_require__(23);

  // 22.1.3.4 Array.prototype.entries()
  // 22.1.3.13 Array.prototype.keys()
  // 22.1.3.29 Array.prototype.values()
  // 22.1.3.30 Array.prototype[@@iterator]()
  module.exports = __webpack_require__(28)(Array, 'Array', function (iterated, kind) {
    this._t = toIObject(iterated); // target
    this._i = 0; // next index
    this._k = kind; // kind
    // 22.1.5.2.1 %ArrayIteratorPrototype%.next()
  }, function () {
    var O = this._t;
    var kind = this._k;
    var index = this._i++;
    if (!O || index >= O.length) {
      this._t = undefined;
      return step(1);
    }
    if (kind == 'keys') return step(0, index);
    if (kind == 'values') return step(0, O[index]);
    return step(0, [index, O[index]]);
  }, 'values');

  // argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
  Iterators.Arguments = Iterators.Array;

  addToUnscopables('keys');
  addToUnscopables('values');
  addToUnscopables('entries');

  /***/
},
/* 69 */
/***/function (module, exports) {

  module.exports = function () {/* empty */};

  /***/
},
/* 70 */
/***/function (module, exports) {

  module.exports = function (done, value) {
    return { value: value, done: !!done };
  };

  /***/
},
/* 71 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var LIBRARY = __webpack_require__(21);
  var global = __webpack_require__(2);
  var ctx = __webpack_require__(12);
  var classof = __webpack_require__(36);
  var $export = __webpack_require__(11);
  var isObject = __webpack_require__(8);
  var aFunction = __webpack_require__(13);
  var anInstance = __webpack_require__(72);
  var forOf = __webpack_require__(73);
  var speciesConstructor = __webpack_require__(37);
  var task = __webpack_require__(38).set;
  var microtask = __webpack_require__(78)();
  var newPromiseCapabilityModule = __webpack_require__(26);
  var perform = __webpack_require__(39);
  var userAgent = __webpack_require__(79);
  var promiseResolve = __webpack_require__(40);
  var PROMISE = 'Promise';
  var TypeError = global.TypeError;
  var process = global.process;
  var versions = process && process.versions;
  var v8 = versions && versions.v8 || '';
  var $Promise = global[PROMISE];
  var isNode = classof(process) == 'process';
  var empty = function empty() {/* empty */};
  var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
  var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

  var USE_NATIVE = !!function () {
    try {
      // correct subclassing with @@species support
      var promise = $Promise.resolve(1);
      var FakePromise = (promise.constructor = {})[__webpack_require__(3)('species')] = function (exec) {
        exec(empty, empty);
      };
      // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
      return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise
      // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
      // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
      // we can't detect it synchronously, so just check versions
      && v8.indexOf('6.6') !== 0 && userAgent.indexOf('Chrome/66') === -1;
    } catch (e) {/* empty */}
  }();

  // helpers
  var isThenable = function isThenable(it) {
    var then;
    return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
  };
  var notify = function notify(promise, isReject) {
    if (promise._n) return;
    promise._n = true;
    var chain = promise._c;
    microtask(function () {
      var value = promise._v;
      var ok = promise._s == 1;
      var i = 0;
      var run = function run(reaction) {
        var handler = ok ? reaction.ok : reaction.fail;
        var resolve = reaction.resolve;
        var reject = reaction.reject;
        var domain = reaction.domain;
        var result, then, exited;
        try {
          if (handler) {
            if (!ok) {
              if (promise._h == 2) onHandleUnhandled(promise);
              promise._h = 1;
            }
            if (handler === true) result = value;else {
              if (domain) domain.enter();
              result = handler(value); // may throw
              if (domain) {
                domain.exit();
                exited = true;
              }
            }
            if (result === reaction.promise) {
              reject(TypeError('Promise-chain cycle'));
            } else if (then = isThenable(result)) {
              then.call(result, resolve, reject);
            } else resolve(result);
          } else reject(value);
        } catch (e) {
          if (domain && !exited) domain.exit();
          reject(e);
        }
      };
      while (chain.length > i) {
        run(chain[i++]);
      } // variable length - can't use forEach
      promise._c = [];
      promise._n = false;
      if (isReject && !promise._h) onUnhandled(promise);
    });
  };
  var onUnhandled = function onUnhandled(promise) {
    task.call(global, function () {
      var value = promise._v;
      var unhandled = isUnhandled(promise);
      var result, handler, console;
      if (unhandled) {
        result = perform(function () {
          if (isNode) {
            process.emit('unhandledRejection', value, promise);
          } else if (handler = global.onunhandledrejection) {
            handler({ promise: promise, reason: value });
          } else if ((console = global.console) && console.error) {
            console.error('Unhandled promise rejection', value);
          }
        });
        // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
        promise._h = isNode || isUnhandled(promise) ? 2 : 1;
      }promise._a = undefined;
      if (unhandled && result.e) throw result.v;
    });
  };
  var isUnhandled = function isUnhandled(promise) {
    return promise._h !== 1 && (promise._a || promise._c).length === 0;
  };
  var onHandleUnhandled = function onHandleUnhandled(promise) {
    task.call(global, function () {
      var handler;
      if (isNode) {
        process.emit('rejectionHandled', promise);
      } else if (handler = global.onrejectionhandled) {
        handler({ promise: promise, reason: promise._v });
      }
    });
  };
  var $reject = function $reject(value) {
    var promise = this;
    if (promise._d) return;
    promise._d = true;
    promise = promise._w || promise; // unwrap
    promise._v = value;
    promise._s = 2;
    if (!promise._a) promise._a = promise._c.slice();
    notify(promise, true);
  };
  var $resolve = function $resolve(value) {
    var promise = this;
    var then;
    if (promise._d) return;
    promise._d = true;
    promise = promise._w || promise; // unwrap
    try {
      if (promise === value) throw TypeError("Promise can't be resolved itself");
      if (then = isThenable(value)) {
        microtask(function () {
          var wrapper = { _w: promise, _d: false }; // wrap
          try {
            then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
          } catch (e) {
            $reject.call(wrapper, e);
          }
        });
      } else {
        promise._v = value;
        promise._s = 1;
        notify(promise, false);
      }
    } catch (e) {
      $reject.call({ _w: promise, _d: false }, e); // wrap
    }
  };

  // constructor polyfill
  if (!USE_NATIVE) {
    // 25.4.3.1 Promise(executor)
    $Promise = function Promise(executor) {
      anInstance(this, $Promise, PROMISE, '_h');
      aFunction(executor);
      Internal.call(this);
      try {
        executor(ctx($resolve, this, 1), ctx($reject, this, 1));
      } catch (err) {
        $reject.call(this, err);
      }
    };
    // eslint-disable-next-line no-unused-vars
    Internal = function Promise(executor) {
      this._c = []; // <- awaiting reactions
      this._a = undefined; // <- checked in isUnhandled reactions
      this._s = 0; // <- state
      this._d = false; // <- done
      this._v = undefined; // <- value
      this._h = 0; // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
      this._n = false; // <- notify
    };
    Internal.prototype = __webpack_require__(80)($Promise.prototype, {
      // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
      then: function then(onFulfilled, onRejected) {
        var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
        reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
        reaction.fail = typeof onRejected == 'function' && onRejected;
        reaction.domain = isNode ? process.domain : undefined;
        this._c.push(reaction);
        if (this._a) this._a.push(reaction);
        if (this._s) notify(this, false);
        return reaction.promise;
      },
      // 25.4.5.1 Promise.prototype.catch(onRejected)
      'catch': function _catch(onRejected) {
        return this.then(undefined, onRejected);
      }
    });
    OwnPromiseCapability = function OwnPromiseCapability() {
      var promise = new Internal();
      this.promise = promise;
      this.resolve = ctx($resolve, promise, 1);
      this.reject = ctx($reject, promise, 1);
    };
    newPromiseCapabilityModule.f = newPromiseCapability = function newPromiseCapability(C) {
      return C === $Promise || C === Wrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C);
    };
  }

  $export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
  __webpack_require__(25)($Promise, PROMISE);
  __webpack_require__(81)(PROMISE);
  Wrapper = __webpack_require__(4)[PROMISE];

  // statics
  $export($export.S + $export.F * !USE_NATIVE, PROMISE, {
    // 25.4.4.5 Promise.reject(r)
    reject: function reject(r) {
      var capability = newPromiseCapability(this);
      var $$reject = capability.reject;
      $$reject(r);
      return capability.promise;
    }
  });
  $export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
    // 25.4.4.6 Promise.resolve(x)
    resolve: function resolve(x) {
      return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
    }
  });
  $export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(82)(function (iter) {
    $Promise.all(iter)['catch'](empty);
  })), PROMISE, {
    // 25.4.4.1 Promise.all(iterable)
    all: function all(iterable) {
      var C = this;
      var capability = newPromiseCapability(C);
      var resolve = capability.resolve;
      var reject = capability.reject;
      var result = perform(function () {
        var values = [];
        var index = 0;
        var remaining = 1;
        forOf(iterable, false, function (promise) {
          var $index = index++;
          var alreadyCalled = false;
          values.push(undefined);
          remaining++;
          C.resolve(promise).then(function (value) {
            if (alreadyCalled) return;
            alreadyCalled = true;
            values[$index] = value;
            --remaining || resolve(values);
          }, reject);
        });
        --remaining || resolve(values);
      });
      if (result.e) reject(result.v);
      return capability.promise;
    },
    // 25.4.4.4 Promise.race(iterable)
    race: function race(iterable) {
      var C = this;
      var capability = newPromiseCapability(C);
      var reject = capability.reject;
      var result = perform(function () {
        forOf(iterable, false, function (promise) {
          C.resolve(promise).then(capability.resolve, reject);
        });
      });
      if (result.e) reject(result.v);
      return capability.promise;
    }
  });

  /***/
},
/* 72 */
/***/function (module, exports) {

  module.exports = function (it, Constructor, name, forbiddenField) {
    if (!(it instanceof Constructor) || forbiddenField !== undefined && forbiddenField in it) {
      throw TypeError(name + ': incorrect invocation!');
    }return it;
  };

  /***/
},
/* 73 */
/***/function (module, exports, __webpack_require__) {

  var ctx = __webpack_require__(12);
  var call = __webpack_require__(74);
  var isArrayIter = __webpack_require__(75);
  var anObject = __webpack_require__(5);
  var toLength = __webpack_require__(31);
  var getIterFn = __webpack_require__(76);
  var BREAK = {};
  var RETURN = {};
  var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
    var iterFn = ITERATOR ? function () {
      return iterable;
    } : getIterFn(iterable);
    var f = ctx(fn, that, entries ? 2 : 1);
    var index = 0;
    var length, step, iterator, result;
    if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
    // fast case for arrays with default iterator
    if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
      result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
      if (result === BREAK || result === RETURN) return result;
    } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
      result = call(iterator, f, step.value, entries);
      if (result === BREAK || result === RETURN) return result;
    }
  };
  exports.BREAK = BREAK;
  exports.RETURN = RETURN;

  /***/
},
/* 74 */
/***/function (module, exports, __webpack_require__) {

  // call something on iterator step with safe closing on error
  var anObject = __webpack_require__(5);
  module.exports = function (iterator, fn, value, entries) {
    try {
      return entries ? fn(anObject(value)[0], value[1]) : fn(value);
      // 7.4.6 IteratorClose(iterator, completion)
    } catch (e) {
      var ret = iterator['return'];
      if (ret !== undefined) anObject(ret.call(iterator));
      throw e;
    }
  };

  /***/
},
/* 75 */
/***/function (module, exports, __webpack_require__) {

  // check on default Array iterator
  var Iterators = __webpack_require__(10);
  var ITERATOR = __webpack_require__(3)('iterator');
  var ArrayProto = Array.prototype;

  module.exports = function (it) {
    return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
  };

  /***/
},
/* 76 */
/***/function (module, exports, __webpack_require__) {

  var classof = __webpack_require__(36);
  var ITERATOR = __webpack_require__(3)('iterator');
  var Iterators = __webpack_require__(10);
  module.exports = __webpack_require__(4).getIteratorMethod = function (it) {
    if (it != undefined) return it[ITERATOR] || it['@@iterator'] || Iterators[classof(it)];
  };

  /***/
},
/* 77 */
/***/function (module, exports) {

  // fast apply, http://jsperf.lnkit.com/fast-apply/5
  module.exports = function (fn, args, that) {
    var un = that === undefined;
    switch (args.length) {
      case 0:
        return un ? fn() : fn.call(that);
      case 1:
        return un ? fn(args[0]) : fn.call(that, args[0]);
      case 2:
        return un ? fn(args[0], args[1]) : fn.call(that, args[0], args[1]);
      case 3:
        return un ? fn(args[0], args[1], args[2]) : fn.call(that, args[0], args[1], args[2]);
      case 4:
        return un ? fn(args[0], args[1], args[2], args[3]) : fn.call(that, args[0], args[1], args[2], args[3]);
    }return fn.apply(that, args);
  };

  /***/
},
/* 78 */
/***/function (module, exports, __webpack_require__) {

  var global = __webpack_require__(2);
  var macrotask = __webpack_require__(38).set;
  var Observer = global.MutationObserver || global.WebKitMutationObserver;
  var process = global.process;
  var Promise = global.Promise;
  var isNode = __webpack_require__(16)(process) == 'process';

  module.exports = function () {
    var head, last, notify;

    var flush = function flush() {
      var parent, fn;
      if (isNode && (parent = process.domain)) parent.exit();
      while (head) {
        fn = head.fn;
        head = head.next;
        try {
          fn();
        } catch (e) {
          if (head) notify();else last = undefined;
          throw e;
        }
      }last = undefined;
      if (parent) parent.enter();
    };

    // Node.js
    if (isNode) {
      notify = function notify() {
        process.nextTick(flush);
      };
      // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
    } else if (Observer && !(global.navigator && global.navigator.standalone)) {
      var toggle = true;
      var node = document.createTextNode('');
      new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
      notify = function notify() {
        node.data = toggle = !toggle;
      };
      // environments with maybe non-completely correct, but existent Promise
    } else if (Promise && Promise.resolve) {
      // Promise.resolve without an argument throws an error in LG WebOS 2
      var promise = Promise.resolve(undefined);
      notify = function notify() {
        promise.then(flush);
      };
      // for other environments - macrotask based on:
      // - setImmediate
      // - MessageChannel
      // - window.postMessag
      // - onreadystatechange
      // - setTimeout
    } else {
      notify = function notify() {
        // strange IE + webpack dev server bug - use .call(global)
        macrotask.call(global, flush);
      };
    }

    return function (fn) {
      var task = { fn: fn, next: undefined };
      if (last) last.next = task;
      if (!head) {
        head = task;
        notify();
      }last = task;
    };
  };

  /***/
},
/* 79 */
/***/function (module, exports, __webpack_require__) {

  var global = __webpack_require__(2);
  var navigator = global.navigator;

  module.exports = navigator && navigator.userAgent || '';

  /***/
},
/* 80 */
/***/function (module, exports, __webpack_require__) {

  var hide = __webpack_require__(7);
  module.exports = function (target, src, safe) {
    for (var key in src) {
      if (safe && target[key]) target[key] = src[key];else hide(target, key, src[key]);
    }return target;
  };

  /***/
},
/* 81 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  var global = __webpack_require__(2);
  var core = __webpack_require__(4);
  var dP = __webpack_require__(14);
  var DESCRIPTORS = __webpack_require__(9);
  var SPECIES = __webpack_require__(3)('species');

  module.exports = function (KEY) {
    var C = typeof core[KEY] == 'function' ? core[KEY] : global[KEY];
    if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
      configurable: true,
      get: function get() {
        return this;
      }
    });
  };

  /***/
},
/* 82 */
/***/function (module, exports, __webpack_require__) {

  var ITERATOR = __webpack_require__(3)('iterator');
  var SAFE_CLOSING = false;

  try {
    var riter = [7][ITERATOR]();
    riter['return'] = function () {
      SAFE_CLOSING = true;
    };
    // eslint-disable-next-line no-throw-literal
    Array.from(riter, function () {
      throw 2;
    });
  } catch (e) {/* empty */}

  module.exports = function (exec, skipClosing) {
    if (!skipClosing && !SAFE_CLOSING) return false;
    var safe = false;
    try {
      var arr = [7];
      var iter = arr[ITERATOR]();
      iter.next = function () {
        return { done: safe = true };
      };
      arr[ITERATOR] = function () {
        return iter;
      };
      exec(arr);
    } catch (e) {/* empty */}
    return safe;
  };

  /***/
},
/* 83 */
/***/function (module, exports, __webpack_require__) {

  "use strict";
  // https://github.com/tc39/proposal-promise-finally

  var $export = __webpack_require__(11);
  var core = __webpack_require__(4);
  var global = __webpack_require__(2);
  var speciesConstructor = __webpack_require__(37);
  var promiseResolve = __webpack_require__(40);

  $export($export.P + $export.R, 'Promise', { 'finally': function _finally(onFinally) {
      var C = speciesConstructor(this, core.Promise || global.Promise);
      var isFunction = typeof onFinally == 'function';
      return this.then(isFunction ? function (x) {
        return promiseResolve(C, onFinally()).then(function () {
          return x;
        });
      } : onFinally, isFunction ? function (e) {
        return promiseResolve(C, onFinally()).then(function () {
          throw e;
        });
      } : onFinally);
    } });

  /***/
},
/* 84 */
/***/function (module, exports, __webpack_require__) {

  "use strict";

  // https://github.com/tc39/proposal-promise-try

  var $export = __webpack_require__(11);
  var newPromiseCapability = __webpack_require__(26);
  var perform = __webpack_require__(39);

  $export($export.S, 'Promise', { 'try': function _try(callbackfn) {
      var promiseCapability = newPromiseCapability.f(this);
      var result = perform(callbackfn);
      (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
      return promiseCapability.promise;
    } });

  /***/
},,
/* 85 */
/* 86 */
/***/function (module, exports) {

  !function (n, t) {
    "object" == (typeof module === 'undefined' ? 'undefined' : _typeof2(module)) && module.exports ? module.exports = t() : n.onfire = t();
  }("undefined" != typeof window ? window : this, function () {
    function n(n, t, e, o) {
      if ((typeof n === 'undefined' ? 'undefined' : _typeof2(n)) !== p || (typeof t === 'undefined' ? 'undefined' : _typeof2(t)) !== a) throw new Error("args: " + p + ", " + a);return y(l, n) || (l[n] = {}), l[n][++d] = [t, e, o], [n, d];
    }function t(n, t) {
      for (var e in n) {
        y(n, e) && t(e, n[e]);
      }
    }function e(t, e, o) {
      return n(t, e, 0, o);
    }function o(t, e, o) {
      return n(t, e, 1, o);
    }function i(n, e) {
      y(l, n) && t(l[n], function (t, o) {
        o[0].apply(o[2], e), o[1] && delete l[n][t];
      });
    }function r(n) {
      var t = s(arguments, 1);setTimeout(function () {
        i(n, t);
      });
    }function u(n) {
      i(n, s(arguments, 1));
    }function f(n) {
      var e,
          o,
          i = !1,
          r = typeof n === 'undefined' ? 'undefined' : _typeof2(n);return r === p ? !!y(l, n) && (delete l[n], !0) : "object" === r ? (e = n[0], o = n[1], !(!y(l, e) || !y(l[e], o)) && (delete l[e][o], !0)) : r !== a || (t(l, function (e, o) {
        t(o, function (t, o) {
          o[0] === n && (delete l[e][t], i = !0);
        });
      }), i);
    }function c() {
      l = {};
    }var l = {},
        d = 0,
        p = "string",
        a = "function",
        y = Function.call.bind(Object.hasOwnProperty),
        s = Function.call.bind(Array.prototype.slice);return { on: e, one: o, un: f, fire: r, fireSync: u, clear: c };
  });

  /***/
},
/* 87 */
/***/function (module, exports, __webpack_require__) {

  (function webpackUniversalModuleDefinition(root, factory) {
    if (true) module.exports = factory();else if (typeof define === 'function' && define.amd) define([], factory);else {
      var a = factory();
      for (var i in a) {
        ((typeof exports === 'undefined' ? 'undefined' : _typeof2(exports)) === 'object' ? exports : root)[i] = a[i];
      }
    }
  })(this, function () {
    return (/******/function (modules) {
        // webpackBootstrap
        /******/ // The module cache
        /******/var installedModules = {};
        /******/
        /******/ // The require function
        /******/function __webpack_require__(moduleId) {
          /******/
          /******/ // Check if module is in cache
          /******/if (installedModules[moduleId]) {
            /******/return installedModules[moduleId].exports;
            /******/
          }
          /******/ // Create a new module (and put it into the cache)
          /******/var module = installedModules[moduleId] = {
            /******/i: moduleId,
            /******/l: false,
            /******/exports: {}
            /******/ };
          /******/
          /******/ // Execute the module function
          /******/modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
          /******/
          /******/ // Flag the module as loaded
          /******/module.l = true;
          /******/
          /******/ // Return the exports of the module
          /******/return module.exports;
          /******/
        }
        /******/
        /******/
        /******/ // expose the modules object (__webpack_modules__)
        /******/__webpack_require__.m = modules;
        /******/
        /******/ // expose the module cache
        /******/__webpack_require__.c = installedModules;
        /******/
        /******/ // identity function for calling harmony imports with the correct context
        /******/__webpack_require__.i = function (value) {
          return value;
        };
        /******/
        /******/ // define getter function for harmony exports
        /******/__webpack_require__.d = function (exports, name, getter) {
          /******/if (!__webpack_require__.o(exports, name)) {
            /******/Object.defineProperty(exports, name, {
              /******/configurable: false,
              /******/enumerable: true,
              /******/get: getter
              /******/ });
            /******/
          }
          /******/
        };
        /******/
        /******/ // getDefaultExport function for compatibility with non-harmony modules
        /******/__webpack_require__.n = function (module) {
          /******/var getter = module && module.__esModule ?
          /******/function getDefault() {
            return module['default'];
          } :
          /******/function getModuleExports() {
            return module;
          };
          /******/__webpack_require__.d(getter, 'a', getter);
          /******/return getter;
          /******/
        };
        /******/
        /******/ // Object.prototype.hasOwnProperty.call
        /******/__webpack_require__.o = function (object, property) {
          return Object.prototype.hasOwnProperty.call(object, property);
        };
        /******/
        /******/ // __webpack_public_path__
        /******/__webpack_require__.p = "";
        /******/
        /******/ // Load entry module and return exports
        /******/return __webpack_require__(__webpack_require__.s = 13);
        /******/
      }(
      /************************************************************************/
      /******/[
      /* 0 */
      /***/function (module, exports, __webpack_require__) {

        "use strict";

        var _typeof = typeof Symbol === "function" && _typeof2(Symbol.iterator) === "symbol" ? function (obj) {
          return typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        } : function (obj) {
          return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        };

        module.exports = {
          type: function type(ob) {
            return Object.prototype.toString.call(ob).slice(8, -1).toLowerCase();
          },
          isObject: function isObject(ob, real) {
            if (real) {
              return this.type(ob) === "object";
            } else {
              return ob && (typeof ob === 'undefined' ? 'undefined' : _typeof(ob)) === 'object';
            }
          },
          isFormData: function isFormData(val) {
            return typeof FormData !== 'undefined' && val instanceof FormData;
          },
          trim: function trim(str) {
            return str.replace(/(^\s*)|(\s*$)/g, '');
          },
          encode: function encode(val) {
            return encodeURIComponent(val).replace(/%40/gi, '@').replace(/%3A/gi, ':').replace(/%24/g, '$').replace(/%2C/gi, ',').replace(/%20/g, '+').replace(/%5B/gi, '[').replace(/%5D/gi, ']');
          },
          formatParams: function formatParams(data) {
            var str = "";
            var first = true;
            var that = this;
            if (!this.isObject(data)) {
              return data;
            }

            function _encode(sub, path) {
              var encode = that.encode;
              var type = that.type(sub);
              if (type == "array") {
                sub.forEach(function (e, i) {
                  if (!that.isObject(e)) i = "";
                  _encode(e, path + ('%5B' + i + '%5D'));
                });
              } else if (type == "object") {
                for (var key in sub) {
                  if (path) {
                    _encode(sub[key], path + "%5B" + encode(key) + "%5D");
                  } else {
                    _encode(sub[key], encode(key));
                  }
                }
              } else {
                if (!first) {
                  str += "&";
                }
                first = false;
                str += path + "=" + encode(sub);
              }
            }

            _encode(data, "");
            return str;
          },

          // Do not overwrite existing attributes
          merge: function merge(a, b) {
            for (var key in b) {
              if (!a.hasOwnProperty(key)) {
                a[key] = b[key];
              } else if (this.isObject(b[key], 1) && this.isObject(a[key], 1)) {
                this.merge(a[key], b[key]);
              }
            }
            return a;
          }
        };

        /***/
      },
      /* 1 */
      /***/function (module, exports, __webpack_require__) {

        function KEEP(_, cb) {
          cb();
        }
        "use strict";

        var _typeof = typeof Symbol === "function" && _typeof2(Symbol.iterator) === "symbol" ? function (obj) {
          return typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        } : function (obj) {
          return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj === 'undefined' ? 'undefined' : _typeof2(obj);
        };

        var _createClass = function () {
          function defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
            }
          }return function (Constructor, protoProps, staticProps) {
            if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
          };
        }();

        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
          }
        }

        /*
         * author: wendu
         * email: 824783146@qq.com
         **/

        var util = __webpack_require__(0);
        var isBrowser = typeof document !== "undefined";

        //EngineWrapper can help  generating  a  http engine quickly through a adapter
        function EngineWrapper(adapter) {
          var AjaxEngine = function () {
            function AjaxEngine() {
              _classCallCheck(this, AjaxEngine);

              this.requestHeaders = {};
              this.readyState = 0;
              this.timeout = 0; // 0 stands for no timeout
              this.responseURL = "";
              this.responseHeaders = {};
            }

            _createClass(AjaxEngine, [{
              key: "_call",
              value: function _call(name) {
                this[name] && this[name].apply(this, [].splice.call(arguments, 1));
              }
            }, {
              key: "_changeReadyState",
              value: function _changeReadyState(state) {
                this.readyState = state;
                this._call("onreadystatechange");
              }
            }, {
              key: "open",
              value: function open(method, url) {
                this.method = method;
                if (!url) {
                  url = location.href;
                } else {
                  url = util.trim(url);
                  if (url.indexOf("http") !== 0) {
                    // Normalize the request url
                    if (isBrowser) {
                      var t = document.createElement("a");
                      t.href = url;
                      url = t.href;
                    }
                  }
                }
                this.responseURL = url;
                this._changeReadyState(1);
              }
            }, {
              key: "send",
              value: function send(arg) {
                var _this = this;

                arg = arg || null;
                var self = this;
                if (adapter) {
                  var request = {
                    method: self.method,
                    url: self.responseURL,
                    headers: self.requestHeaders || {},
                    body: arg
                  };
                  util.merge(request, self._options || {});
                  if (request.method === "GET") {
                    request.body = null;
                  }
                  self._changeReadyState(3);
                  var timer;
                  self.timeout = self.timeout || 0;
                  if (self.timeout > 0) {
                    timer = setTimeout(function () {
                      if (self.readyState === 3) {
                        _this._call("onloadend");
                        self._changeReadyState(0);
                        self._call("ontimeout");
                      }
                    }, self.timeout);
                  }
                  request.timeout = self.timeout;
                  adapter(request, function (response) {

                    function getAndDelete(key) {
                      var t = response[key];
                      delete response[key];
                      return t;
                    }

                    // If the request has already timeout, return
                    if (self.readyState !== 3) return;
                    clearTimeout(timer);

                    // Make sure the type of status is integer
                    self.status = getAndDelete("statusCode") - 0;

                    var responseText = getAndDelete("responseText");
                    var statusMessage = getAndDelete("statusMessage");

                    // Network error, set the status code 0
                    if (!self.status) {
                      self.statusText = responseText;
                      self._call("onerror", { msg: statusMessage });
                    } else {
                      // Parsing the response headers to array in a object,  because
                      // there may be multiple values with the same header name
                      var responseHeaders = getAndDelete("headers");
                      var headers = {};
                      for (var field in responseHeaders) {
                        var value = responseHeaders[field];
                        var key = field.toLowerCase();
                        // Is array
                        if ((typeof value === "undefined" ? "undefined" : _typeof(value)) === "object") {
                          headers[key] = value;
                        } else {
                          headers[key] = headers[key] || [];
                          headers[key].push(value);
                        }
                      }
                      var cookies = headers["set-cookie"];
                      if (isBrowser && cookies) {
                        cookies.forEach(function (e) {
                          // Remove the http-Only property of the  cookie
                          // so that JavaScript can operate it.
                          document.cookie = e.replace(/;\s*httpOnly/ig, "");
                        });
                      }
                      self.responseHeaders = headers;
                      // Set the fields of engine from response
                      self.statusText = statusMessage || "";
                      self.response = self.responseText = responseText;
                      self._response = response;
                      self._changeReadyState(4);
                      self._call("onload");
                    }
                    self._call("onloadend");
                  });
                } else {
                  console.error("Ajax require adapter");
                }
              }
            }, {
              key: "setRequestHeader",
              value: function setRequestHeader(key, value) {
                this.requestHeaders[util.trim(key)] = value;
              }
            }, {
              key: "getResponseHeader",
              value: function getResponseHeader(key) {
                return (this.responseHeaders[key.toLowerCase()] || "").toString() || null;
              }
            }, {
              key: "getAllResponseHeaders",
              value: function getAllResponseHeaders() {
                var str = "";
                for (var key in this.responseHeaders) {
                  str += key + ":" + this.getResponseHeader(key) + "\r\n";
                }
                return str || null;
              }
            }, {
              key: "abort",
              value: function abort(msg) {
                this._changeReadyState(0);
                this._call("onerror", { msg: msg });
                this._call("onloadend");
              }
            }], [{
              key: "setAdapter",
              value: function setAdapter(requestAdapter) {
                adapter = requestAdapter;
              }
            }]);

            return AjaxEngine;
          }();

          return AjaxEngine;
        }

        // learn more about keep-loader: https://github.com/wendux/keep-loader
        ;
        module.exports = EngineWrapper;

        /***/
      },
      /* 2 */
      /***/function (module, exports, __webpack_require__) {

        function KEEP(_, cb) {
          cb();
        }
        "use strict";

        var _createClass = function () {
          function defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];descriptor.enumerable = descriptor.enumerable || false;descriptor.configurable = true;if ("value" in descriptor) descriptor.writable = true;Object.defineProperty(target, descriptor.key, descriptor);
            }
          }return function (Constructor, protoProps, staticProps) {
            if (protoProps) defineProperties(Constructor.prototype, protoProps);if (staticProps) defineProperties(Constructor, staticProps);return Constructor;
          };
        }();

        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
          }
        }

        var utils = __webpack_require__(0);
        var isBrowser = typeof document !== "undefined";

        var Fly = function () {
          function Fly(engine) {
            _classCallCheck(this, Fly);

            this.engine = engine || XMLHttpRequest;

            this.default = this; //For typeScript

            /**
             * Add  lock/unlock API for interceptor.
             *
             * Once an request/response interceptor is locked, the incoming request/response
             * will be added to a queue before they enter the interceptor, they will not be
             * continued  until the interceptor is unlocked.
             *
             * @param [interceptor] either is interceptors.request or interceptors.response
             */
            function wrap(interceptor) {
              var resolve;
              var reject;

              function _clear() {
                interceptor.p = resolve = reject = null;
              }

              utils.merge(interceptor, {
                lock: function lock() {
                  if (!resolve) {
                    interceptor.p = new Promise(function (_resolve, _reject) {
                      resolve = _resolve;
                      reject = _reject;
                    });
                  }
                },
                unlock: function unlock() {
                  if (resolve) {
                    resolve();
                    _clear();
                  }
                },
                clear: function clear() {
                  if (reject) {
                    reject("cancel");
                    _clear();
                  }
                }
              });
            }

            var interceptors = this.interceptors = {
              response: {
                use: function use(handler, onerror) {
                  this.handler = handler;
                  this.onerror = onerror;
                }
              },
              request: {
                use: function use(handler) {
                  this.handler = handler;
                }
              }
            };

            var irq = interceptors.request;
            var irp = interceptors.response;
            wrap(irp);
            wrap(irq);

            this.config = {
              method: "GET",
              baseURL: "",
              headers: {},
              timeout: 0,
              params: {}, // Default Url params
              parseJson: true, // Convert response data to JSON object automatically.
              withCredentials: false
            };
          }

          _createClass(Fly, [{
            key: "request",
            value: function request(url, data, options) {
              var _this = this;

              var engine = new this.engine();
              var contentType = "Content-Type";
              var contentTypeLowerCase = contentType.toLowerCase();
              var interceptors = this.interceptors;
              var requestInterceptor = interceptors.request;
              var responseInterceptor = interceptors.response;
              var requestInterceptorHandler = requestInterceptor.handler;
              var promise = new Promise(function (resolve, reject) {
                if (utils.isObject(url)) {
                  options = url;
                  url = options.url;
                }
                options = options || {};
                options.headers = options.headers || {};

                function isPromise(p) {
                  // some  polyfill implementation of Promise may be not standard,
                  // so, we test by duck-typing
                  return p && p.then && p.catch;
                }

                /**
                 * If the request/response interceptor has been locked，
                 * the new request/response will enter a queue. otherwise, it will be performed directly.
                 * @param [promise] if the promise exist, means the interceptor is  locked.
                 * @param [callback]
                 */
                function enqueueIfLocked(promise, callback) {
                  if (promise) {
                    promise.then(function () {
                      callback();
                    });
                  } else {
                    callback();
                  }
                }

                // make the http request
                function makeRequest(options) {
                  data = options.body;
                  // Normalize the request url
                  url = utils.trim(options.url);
                  var baseUrl = utils.trim(options.baseURL || "");
                  if (!url && isBrowser && !baseUrl) url = location.href;
                  if (url.indexOf("http") !== 0) {
                    var isAbsolute = url[0] === "/";
                    if (!baseUrl && isBrowser) {
                      var arr = location.pathname.split("/");
                      arr.pop();
                      baseUrl = location.protocol + "//" + location.host + (isAbsolute ? "" : arr.join("/"));
                    }
                    if (baseUrl[baseUrl.length - 1] !== "/") {
                      baseUrl += "/";
                    }
                    url = baseUrl + (isAbsolute ? url.substr(1) : url);
                    if (isBrowser) {

                      // Normalize the url which contains the ".." or ".", such as
                      // "http://xx.com/aa/bb/../../xx" to "http://xx.com/xx" .
                      var t = document.createElement("a");
                      t.href = url;
                      url = t.href;
                    }
                  }

                  var responseType = utils.trim(options.responseType || "");
                  var isGet = options.method === "GET";
                  var dataType = utils.type(data);
                  var params = options.params || {};

                  // merge url params when the method is "GET" (data is object)
                  if (isGet && dataType === "object") {
                    params = utils.merge(data, params);
                  }
                  // encode params to String
                  params = utils.formatParams(params);

                  // save url params
                  var _params = [];
                  if (params) {
                    _params.push(params);
                  }
                  // Add data to url params when the method is "GET" (data is String)
                  if (isGet && data && dataType === "string") {
                    _params.push(data);
                  }

                  // make the final url
                  if (_params.length > 0) {
                    url += (url.indexOf("?") === -1 ? "?" : "&") + _params.join("&");
                  }

                  engine.open(options.method, url);

                  // try catch for ie >=9
                  try {
                    engine.withCredentials = !!options.withCredentials;
                    engine.timeout = options.timeout || 0;
                    if (responseType !== "stream") {
                      engine.responseType = responseType;
                    }
                  } catch (e) {}

                  var customContentType = options.headers[contentType] || options.headers[contentTypeLowerCase];

                  // default content type
                  var _contentType = "application/x-www-form-urlencoded";
                  // If the request data is json object, transforming it  to json string,
                  // and set request content-type to "json". In browser,  the data will
                  // be sent as RequestBody instead of FormData
                  if (utils.trim((customContentType || "").toLowerCase()) === _contentType) {
                    data = utils.formatParams(data);
                  } else if (!utils.isFormData(data) && ["object", "array"].indexOf(utils.type(data)) !== -1) {
                    _contentType = 'application/json;charset=utf-8';
                    data = JSON.stringify(data);
                  }
                  //If user doesn't set content-type, set default.
                  if (!(customContentType || isGet)) {
                    options.headers[contentType] = _contentType;
                  }

                  for (var k in options.headers) {
                    if (k === contentType && utils.isFormData(data)) {
                      // Delete the content-type, Let the browser set it
                      delete options.headers[k];
                    } else {
                      try {
                        // In browser environment, some header fields are readonly,
                        // write will cause the exception .
                        engine.setRequestHeader(k, options.headers[k]);
                      } catch (e) {}
                    }
                  }

                  function onresult(handler, data, type) {
                    enqueueIfLocked(responseInterceptor.p, function () {
                      if (handler) {
                        //如果失败，添加请求信息
                        if (type) {
                          data.request = options;
                        }
                        var ret = handler.call(responseInterceptor, data, Promise);
                        data = ret === undefined ? data : ret;
                      }
                      if (!isPromise(data)) {
                        data = Promise[type === 0 ? "resolve" : "reject"](data);
                      }
                      data.then(function (d) {
                        resolve(d);
                      }).catch(function (e) {
                        reject(e);
                      });
                    });
                  }

                  function onerror(e) {
                    e.engine = engine;
                    onresult(responseInterceptor.onerror, e, -1);
                  }

                  function Err(msg, status) {
                    this.message = msg;
                    this.status = status;
                  }

                  engine.onload = function () {
                    try {
                      // The xhr of IE9 has not response field
                      var response = engine.response || engine.responseText;
                      if (response && options.parseJson && (engine.getResponseHeader(contentType) || "").indexOf("json") !== -1
                      // Some third engine implementation may transform the response text to json object automatically,
                      // so we should test the type of response before transforming it
                      && !utils.isObject(response)) {
                        response = JSON.parse(response);
                      }

                      var headers = engine.responseHeaders;
                      // In browser
                      if (!headers) {
                        headers = {};
                        var items = (engine.getAllResponseHeaders() || "").split("\r\n");
                        items.pop();
                        items.forEach(function (e) {
                          if (!e) return;
                          var key = e.split(":")[0];
                          headers[key] = engine.getResponseHeader(key);
                        });
                      }
                      var status = engine.status;
                      var statusText = engine.statusText;
                      var data = { data: response, headers: headers, status: status, statusText: statusText };
                      // The _response filed of engine is set in  adapter which be called in engine-wrapper.js
                      utils.merge(data, engine._response);
                      if (status >= 200 && status < 300 || status === 304) {
                        data.engine = engine;
                        data.request = options;
                        onresult(responseInterceptor.handler, data, 0);
                      } else {
                        var e = new Err(statusText, status);
                        e.response = data;
                        onerror(e);
                      }
                    } catch (e) {
                      onerror(new Err(e.msg, engine.status));
                    }
                  };

                  engine.onerror = function (e) {
                    onerror(new Err(e.msg || "Network Error", 0));
                  };

                  engine.ontimeout = function () {
                    onerror(new Err("timeout [ " + engine.timeout + "ms ]", 1));
                  };
                  engine._options = options;
                  setTimeout(function () {
                    engine.send(isGet ? null : data);
                  }, 0);
                }

                enqueueIfLocked(requestInterceptor.p, function () {
                  utils.merge(options, JSON.parse(JSON.stringify(_this.config)));
                  var headers = options.headers;
                  headers[contentType] = headers[contentType] || headers[contentTypeLowerCase] || "";
                  delete headers[contentTypeLowerCase];
                  options.body = data || options.body;
                  url = utils.trim(url || "");
                  options.method = options.method.toUpperCase();
                  options.url = url;
                  var ret = options;
                  if (requestInterceptorHandler) {
                    ret = requestInterceptorHandler.call(requestInterceptor, options, Promise) || options;
                  }
                  if (!isPromise(ret)) {
                    ret = Promise.resolve(ret);
                  }
                  ret.then(function (d) {
                    //if options continue
                    if (d === options) {
                      makeRequest(d);
                    } else {
                      resolve(d);
                    }
                  }, function (err) {
                    reject(err);
                  });
                });
              });
              promise.engine = engine;
              return promise;
            }
          }, {
            key: "all",
            value: function all(promises) {
              return Promise.all(promises);
            }
          }, {
            key: "spread",
            value: function spread(callback) {
              return function (arr) {
                return callback.apply(null, arr);
              };
            }
          }]);

          return Fly;
        }();

        //For typeScript


        Fly.default = Fly;

        ["get", "post", "put", "patch", "head", "delete"].forEach(function (e) {
          Fly.prototype[e] = function (url, data, option) {
            return this.request(url, data, utils.merge({ method: e }, option));
          };
        });
        ["lock", "unlock", "clear"].forEach(function (e) {
          Fly.prototype[e] = function () {
            this.interceptors.request[e]();
          };
        });
        // Learn more about keep-loader: https://github.com/wendux/keep-loader
        ;
        module.exports = Fly;

        /***/
      },,,,,
      /* 3 */
      /* 4 */
      /* 5 */
      /* 6 */
      /* 7 */
      /***/function (module, exports, __webpack_require__) {

        "use strict";

        //微信小程序适配器

        module.exports = function (request, responseCallback) {
          var con = {
            method: request.method,
            url: request.url,
            dataType: request.dataType || undefined,
            header: request.headers,
            data: request.body || {},
            responseType: request.responseType || 'text',
            success: function success(res) {
              responseCallback({
                statusCode: res.statusCode,
                responseText: res.data,
                headers: res.header,
                statusMessage: res.errMsg
              });
            },
            fail: function fail(res) {
              responseCallback({
                statusCode: res.statusCode || 0,
                statusMessage: res.errMsg
              });
            }
          };
          wx.request(con);
        };

        /***/
      },,,,,,
      /* 8 */
      /* 9 */
      /* 10 */
      /* 11 */
      /* 12 */
      /* 13 */
      /***/function (module, exports, __webpack_require__) {

        "use strict";

        //微信小程序入口

        var _Fly = __webpack_require__(2);
        var EngineWrapper = __webpack_require__(1);
        var adapter = __webpack_require__(7);
        var wxEngine = EngineWrapper(adapter);
        module.exports = function (engine) {
          return new _Fly(engine || wxEngine);
        };

        /***/
      }]
      /******/)
    );
  });

  /***/
},,,,,,,,,,,,,,,,,,
/* 88 */
/* 89 */
/* 90 */
/* 91 */
/* 92 */
/* 93 */
/* 94 */
/* 95 */
/* 96 */
/* 97 */
/* 98 */
/* 99 */
/* 100 */
/* 101 */
/* 102 */
/* 103 */
/* 104 */
/* 105 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";
  /* unused harmony export Store */
  /* unused harmony export install */
  /* unused harmony export mapState */
  /* unused harmony export mapMutations */
  /* unused harmony export mapGetters */
  /* unused harmony export mapActions */
  /* unused harmony export createNamespacedHelpers */
  /**
   * vuex v3.1.0
   * (c) 2019 Evan You
   * @license MIT
   */

  function applyMixin(Vue) {
    var version = Number(Vue.version.split('.')[0]);

    if (version >= 2) {
      Vue.mixin({ beforeCreate: vuexInit });
    } else {
      // override init and inject vuex init procedure
      // for 1.x backwards compatibility.
      var _init = Vue.prototype._init;
      Vue.prototype._init = function (options) {
        if (options === void 0) options = {};

        options.init = options.init ? [vuexInit].concat(options.init) : vuexInit;
        _init.call(this, options);
      };
    }

    /**
     * Vuex init hook, injected into each instances init hooks list.
     */

    function vuexInit() {
      var options = this.$options;
      // store injection
      if (options.store) {
        this.$store = typeof options.store === 'function' ? options.store() : options.store;
      } else if (options.parent && options.parent.$store) {
        this.$store = options.parent.$store;
      }
    }
  }

  var devtoolHook = typeof window !== 'undefined' && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;

  function devtoolPlugin(store) {
    if (!devtoolHook) {
      return;
    }

    store._devtoolHook = devtoolHook;

    devtoolHook.emit('vuex:init', store);

    devtoolHook.on('vuex:travel-to-state', function (targetState) {
      store.replaceState(targetState);
    });

    store.subscribe(function (mutation, state) {
      devtoolHook.emit('vuex:mutation', mutation, state);
    });
  }

  /**
   * Get the first item that pass the test
   * by second argument function
   *
   * @param {Array} list
   * @param {Function} f
   * @return {*}
   */

  /**
   * forEach for object
   */
  function forEachValue(obj, fn) {
    Object.keys(obj).forEach(function (key) {
      return fn(obj[key], key);
    });
  }

  function isObject(obj) {
    return obj !== null && (typeof obj === 'undefined' ? 'undefined' : _typeof2(obj)) === 'object';
  }

  function isPromise(val) {
    return val && typeof val.then === 'function';
  }

  function assert(condition, msg) {
    if (!condition) {
      throw new Error("[vuex] " + msg);
    }
  }

  // Base data struct for store's module, package with some attribute and method
  var Module = function Module(rawModule, runtime) {
    this.runtime = runtime;
    // Store some children item
    this._children = Object.create(null);
    // Store the origin module object which passed by programmer
    this._rawModule = rawModule;
    var rawState = rawModule.state;

    // Store the origin module's state
    this.state = (typeof rawState === 'function' ? rawState() : rawState) || {};
  };

  var prototypeAccessors = { namespaced: { configurable: true } };

  prototypeAccessors.namespaced.get = function () {
    return !!this._rawModule.namespaced;
  };

  Module.prototype.addChild = function addChild(key, module) {
    this._children[key] = module;
  };

  Module.prototype.removeChild = function removeChild(key) {
    delete this._children[key];
  };

  Module.prototype.getChild = function getChild(key) {
    return this._children[key];
  };

  Module.prototype.update = function update(rawModule) {
    this._rawModule.namespaced = rawModule.namespaced;
    if (rawModule.actions) {
      this._rawModule.actions = rawModule.actions;
    }
    if (rawModule.mutations) {
      this._rawModule.mutations = rawModule.mutations;
    }
    if (rawModule.getters) {
      this._rawModule.getters = rawModule.getters;
    }
  };

  Module.prototype.forEachChild = function forEachChild(fn) {
    forEachValue(this._children, fn);
  };

  Module.prototype.forEachGetter = function forEachGetter(fn) {
    if (this._rawModule.getters) {
      forEachValue(this._rawModule.getters, fn);
    }
  };

  Module.prototype.forEachAction = function forEachAction(fn) {
    if (this._rawModule.actions) {
      forEachValue(this._rawModule.actions, fn);
    }
  };

  Module.prototype.forEachMutation = function forEachMutation(fn) {
    if (this._rawModule.mutations) {
      forEachValue(this._rawModule.mutations, fn);
    }
  };

  Object.defineProperties(Module.prototype, prototypeAccessors);

  var ModuleCollection = function ModuleCollection(rawRootModule) {
    // register root module (Vuex.Store options)
    this.register([], rawRootModule, false);
  };

  ModuleCollection.prototype.get = function get(path) {
    return path.reduce(function (module, key) {
      return module.getChild(key);
    }, this.root);
  };

  ModuleCollection.prototype.getNamespace = function getNamespace(path) {
    var module = this.root;
    return path.reduce(function (namespace, key) {
      module = module.getChild(key);
      return namespace + (module.namespaced ? key + '/' : '');
    }, '');
  };

  ModuleCollection.prototype.update = function update$1(rawRootModule) {
    update([], this.root, rawRootModule);
  };

  ModuleCollection.prototype.register = function register(path, rawModule, runtime) {
    var this$1 = this;
    if (runtime === void 0) runtime = true;

    if (true) {
      assertRawModule(path, rawModule);
    }

    var newModule = new Module(rawModule, runtime);
    if (path.length === 0) {
      this.root = newModule;
    } else {
      var parent = this.get(path.slice(0, -1));
      parent.addChild(path[path.length - 1], newModule);
    }

    // register nested modules
    if (rawModule.modules) {
      forEachValue(rawModule.modules, function (rawChildModule, key) {
        this$1.register(path.concat(key), rawChildModule, runtime);
      });
    }
  };

  ModuleCollection.prototype.unregister = function unregister(path) {
    var parent = this.get(path.slice(0, -1));
    var key = path[path.length - 1];
    if (!parent.getChild(key).runtime) {
      return;
    }

    parent.removeChild(key);
  };

  function update(path, targetModule, newModule) {
    if (true) {
      assertRawModule(path, newModule);
    }

    // update target module
    targetModule.update(newModule);

    // update nested modules
    if (newModule.modules) {
      for (var key in newModule.modules) {
        if (!targetModule.getChild(key)) {
          if (true) {
            console.warn("[vuex] trying to add a new module '" + key + "' on hot reloading, " + 'manual reload is needed');
          }
          return;
        }
        update(path.concat(key), targetModule.getChild(key), newModule.modules[key]);
      }
    }
  }

  var functionAssert = {
    assert: function assert(value) {
      return typeof value === 'function';
    },
    expected: 'function'
  };

  var objectAssert = {
    assert: function assert(value) {
      return typeof value === 'function' || (typeof value === 'undefined' ? 'undefined' : _typeof2(value)) === 'object' && typeof value.handler === 'function';
    },
    expected: 'function or object with "handler" function'
  };

  var assertTypes = {
    getters: functionAssert,
    mutations: functionAssert,
    actions: objectAssert
  };

  function assertRawModule(path, rawModule) {
    Object.keys(assertTypes).forEach(function (key) {
      if (!rawModule[key]) {
        return;
      }

      var assertOptions = assertTypes[key];

      forEachValue(rawModule[key], function (value, type) {
        assert(assertOptions.assert(value), makeAssertionMessage(path, key, type, value, assertOptions.expected));
      });
    });
  }

  function makeAssertionMessage(path, key, type, value, expected) {
    var buf = key + " should be " + expected + " but \"" + key + "." + type + "\"";
    if (path.length > 0) {
      buf += " in module \"" + path.join('.') + "\"";
    }
    buf += " is " + JSON.stringify(value) + ".";
    return buf;
  }

  var Vue; // bind on install

  var Store = function Store(options) {
    var this$1 = this;
    if (options === void 0) options = {};

    // Auto install if it is not done yet and `window` has `Vue`.
    // To allow users to avoid auto-installation in some cases,
    // this code should be placed here. See #731
    if (!Vue && typeof window !== 'undefined' && window.Vue) {
      install(window.Vue);
    }

    if (true) {
      assert(Vue, "must call Vue.use(Vuex) before creating a store instance.");
      assert(typeof Promise !== 'undefined', "vuex requires a Promise polyfill in this browser.");
      assert(this instanceof Store, "store must be called with the new operator.");
    }

    var plugins = options.plugins;if (plugins === void 0) plugins = [];
    var strict = options.strict;if (strict === void 0) strict = false;

    // store internal state
    this._committing = false;
    this._actions = Object.create(null);
    this._actionSubscribers = [];
    this._mutations = Object.create(null);
    this._wrappedGetters = Object.create(null);
    this._modules = new ModuleCollection(options);
    this._modulesNamespaceMap = Object.create(null);
    this._subscribers = [];
    this._watcherVM = new Vue();

    // bind commit and dispatch to self
    var store = this;
    var ref = this;
    var dispatch = ref.dispatch;
    var commit = ref.commit;
    this.dispatch = function boundDispatch(type, payload) {
      return dispatch.call(store, type, payload);
    };
    this.commit = function boundCommit(type, payload, options) {
      return commit.call(store, type, payload, options);
    };

    // strict mode
    this.strict = strict;

    var state = this._modules.root.state;

    // init root module.
    // this also recursively registers all sub-modules
    // and collects all module getters inside this._wrappedGetters
    installModule(this, state, [], this._modules.root);

    // initialize the store vm, which is responsible for the reactivity
    // (also registers _wrappedGetters as computed properties)
    resetStoreVM(this, state);

    // apply plugins
    plugins.forEach(function (plugin) {
      return plugin(this$1);
    });

    var useDevtools = options.devtools !== undefined ? options.devtools : Vue.config.devtools;
    if (useDevtools) {
      devtoolPlugin(this);
    }
  };

  var prototypeAccessors$1 = { state: { configurable: true } };

  prototypeAccessors$1.state.get = function () {
    return this._vm._data.$$state;
  };

  prototypeAccessors$1.state.set = function (v) {
    if (true) {
      assert(false, "use store.replaceState() to explicit replace store state.");
    }
  };

  Store.prototype.commit = function commit(_type, _payload, _options) {
    var this$1 = this;

    // check object-style commit
    var ref = unifyObjectStyle(_type, _payload, _options);
    var type = ref.type;
    var payload = ref.payload;
    var options = ref.options;

    var mutation = { type: type, payload: payload };
    var entry = this._mutations[type];
    if (!entry) {
      if (true) {
        console.error("[vuex] unknown mutation type: " + type);
      }
      return;
    }
    this._withCommit(function () {
      entry.forEach(function commitIterator(handler) {
        handler(payload);
      });
    });
    this._subscribers.forEach(function (sub) {
      return sub(mutation, this$1.state);
    });

    if ("development" !== 'production' && options && options.silent) {
      console.warn("[vuex] mutation type: " + type + ". Silent option has been removed. " + 'Use the filter functionality in the vue-devtools');
    }
  };

  Store.prototype.dispatch = function dispatch(_type, _payload) {
    var this$1 = this;

    // check object-style dispatch
    var ref = unifyObjectStyle(_type, _payload);
    var type = ref.type;
    var payload = ref.payload;

    var action = { type: type, payload: payload };
    var entry = this._actions[type];
    if (!entry) {
      if (true) {
        console.error("[vuex] unknown action type: " + type);
      }
      return;
    }

    try {
      this._actionSubscribers.filter(function (sub) {
        return sub.before;
      }).forEach(function (sub) {
        return sub.before(action, this$1.state);
      });
    } catch (e) {
      if (true) {
        console.warn("[vuex] error in before action subscribers: ");
        console.error(e);
      }
    }

    var result = entry.length > 1 ? Promise.all(entry.map(function (handler) {
      return handler(payload);
    })) : entry[0](payload);

    return result.then(function (res) {
      try {
        this$1._actionSubscribers.filter(function (sub) {
          return sub.after;
        }).forEach(function (sub) {
          return sub.after(action, this$1.state);
        });
      } catch (e) {
        if (true) {
          console.warn("[vuex] error in after action subscribers: ");
          console.error(e);
        }
      }
      return res;
    });
  };

  Store.prototype.subscribe = function subscribe(fn) {
    return genericSubscribe(fn, this._subscribers);
  };

  Store.prototype.subscribeAction = function subscribeAction(fn) {
    var subs = typeof fn === 'function' ? { before: fn } : fn;
    return genericSubscribe(subs, this._actionSubscribers);
  };

  Store.prototype.watch = function watch(getter, cb, options) {
    var this$1 = this;

    if (true) {
      assert(typeof getter === 'function', "store.watch only accepts a function.");
    }
    return this._watcherVM.$watch(function () {
      return getter(this$1.state, this$1.getters);
    }, cb, options);
  };

  Store.prototype.replaceState = function replaceState(state) {
    var this$1 = this;

    this._withCommit(function () {
      this$1._vm._data.$$state = state;
    });
  };

  Store.prototype.registerModule = function registerModule(path, rawModule, options) {
    if (options === void 0) options = {};

    if (typeof path === 'string') {
      path = [path];
    }

    if (true) {
      assert(Array.isArray(path), "module path must be a string or an Array.");
      assert(path.length > 0, 'cannot register the root module by using registerModule.');
    }

    this._modules.register(path, rawModule);
    installModule(this, this.state, path, this._modules.get(path), options.preserveState);
    // reset store to update getters...
    resetStoreVM(this, this.state);
  };

  Store.prototype.unregisterModule = function unregisterModule(path) {
    var this$1 = this;

    if (typeof path === 'string') {
      path = [path];
    }

    if (true) {
      assert(Array.isArray(path), "module path must be a string or an Array.");
    }

    this._modules.unregister(path);
    this._withCommit(function () {
      var parentState = getNestedState(this$1.state, path.slice(0, -1));
      Vue.delete(parentState, path[path.length - 1]);
    });
    resetStore(this);
  };

  Store.prototype.hotUpdate = function hotUpdate(newOptions) {
    this._modules.update(newOptions);
    resetStore(this, true);
  };

  Store.prototype._withCommit = function _withCommit(fn) {
    var committing = this._committing;
    this._committing = true;
    fn();
    this._committing = committing;
  };

  Object.defineProperties(Store.prototype, prototypeAccessors$1);

  function genericSubscribe(fn, subs) {
    if (subs.indexOf(fn) < 0) {
      subs.push(fn);
    }
    return function () {
      var i = subs.indexOf(fn);
      if (i > -1) {
        subs.splice(i, 1);
      }
    };
  }

  function resetStore(store, hot) {
    store._actions = Object.create(null);
    store._mutations = Object.create(null);
    store._wrappedGetters = Object.create(null);
    store._modulesNamespaceMap = Object.create(null);
    var state = store.state;
    // init all modules
    installModule(store, state, [], store._modules.root, true);
    // reset vm
    resetStoreVM(store, state, hot);
  }

  function resetStoreVM(store, state, hot) {
    var oldVm = store._vm;

    // bind store public getters
    store.getters = {};
    var wrappedGetters = store._wrappedGetters;
    var computed = {};
    forEachValue(wrappedGetters, function (fn, key) {
      // use computed to leverage its lazy-caching mechanism
      computed[key] = function () {
        return fn(store);
      };
      Object.defineProperty(store.getters, key, {
        get: function get() {
          return store._vm[key];
        },
        enumerable: true // for local getters
      });
    });

    // use a Vue instance to store the state tree
    // suppress warnings just in case the user has added
    // some funky global mixins
    var silent = Vue.config.silent;
    Vue.config.silent = true;
    store._vm = new Vue({
      data: {
        $$state: state
      },
      computed: computed
    });
    Vue.config.silent = silent;

    // enable strict mode for new vm
    if (store.strict) {
      enableStrictMode(store);
    }

    if (oldVm) {
      if (hot) {
        // dispatch changes in all subscribed watchers
        // to force getter re-evaluation for hot reloading.
        store._withCommit(function () {
          oldVm._data.$$state = null;
        });
      }
      Vue.nextTick(function () {
        return oldVm.$destroy();
      });
    }
  }

  function installModule(store, rootState, path, module, hot) {
    var isRoot = !path.length;
    var namespace = store._modules.getNamespace(path);

    // register in namespace map
    if (module.namespaced) {
      store._modulesNamespaceMap[namespace] = module;
    }

    // set state
    if (!isRoot && !hot) {
      var parentState = getNestedState(rootState, path.slice(0, -1));
      var moduleName = path[path.length - 1];
      store._withCommit(function () {
        Vue.set(parentState, moduleName, module.state);
      });
    }

    var local = module.context = makeLocalContext(store, namespace, path);

    module.forEachMutation(function (mutation, key) {
      var namespacedType = namespace + key;
      registerMutation(store, namespacedType, mutation, local);
    });

    module.forEachAction(function (action, key) {
      var type = action.root ? key : namespace + key;
      var handler = action.handler || action;
      registerAction(store, type, handler, local);
    });

    module.forEachGetter(function (getter, key) {
      var namespacedType = namespace + key;
      registerGetter(store, namespacedType, getter, local);
    });

    module.forEachChild(function (child, key) {
      installModule(store, rootState, path.concat(key), child, hot);
    });
  }

  /**
   * make localized dispatch, commit, getters and state
   * if there is no namespace, just use root ones
   */
  function makeLocalContext(store, namespace, path) {
    var noNamespace = namespace === '';

    var local = {
      dispatch: noNamespace ? store.dispatch : function (_type, _payload, _options) {
        var args = unifyObjectStyle(_type, _payload, _options);
        var payload = args.payload;
        var options = args.options;
        var type = args.type;

        if (!options || !options.root) {
          type = namespace + type;
          if ("development" !== 'production' && !store._actions[type]) {
            console.error("[vuex] unknown local action type: " + args.type + ", global type: " + type);
            return;
          }
        }

        return store.dispatch(type, payload);
      },

      commit: noNamespace ? store.commit : function (_type, _payload, _options) {
        var args = unifyObjectStyle(_type, _payload, _options);
        var payload = args.payload;
        var options = args.options;
        var type = args.type;

        if (!options || !options.root) {
          type = namespace + type;
          if ("development" !== 'production' && !store._mutations[type]) {
            console.error("[vuex] unknown local mutation type: " + args.type + ", global type: " + type);
            return;
          }
        }

        store.commit(type, payload, options);
      }
    };

    // getters and state object must be gotten lazily
    // because they will be changed by vm update
    Object.defineProperties(local, {
      getters: {
        get: noNamespace ? function () {
          return store.getters;
        } : function () {
          return makeLocalGetters(store, namespace);
        }
      },
      state: {
        get: function get() {
          return getNestedState(store.state, path);
        }
      }
    });

    return local;
  }

  function makeLocalGetters(store, namespace) {
    var gettersProxy = {};

    var splitPos = namespace.length;
    Object.keys(store.getters).forEach(function (type) {
      // skip if the target getter is not match this namespace
      if (type.slice(0, splitPos) !== namespace) {
        return;
      }

      // extract local getter type
      var localType = type.slice(splitPos);

      // Add a port to the getters proxy.
      // Define as getter property because
      // we do not want to evaluate the getters in this time.
      Object.defineProperty(gettersProxy, localType, {
        get: function get() {
          return store.getters[type];
        },
        enumerable: true
      });
    });

    return gettersProxy;
  }

  function registerMutation(store, type, handler, local) {
    var entry = store._mutations[type] || (store._mutations[type] = []);
    entry.push(function wrappedMutationHandler(payload) {
      handler.call(store, local.state, payload);
    });
  }

  function registerAction(store, type, handler, local) {
    var entry = store._actions[type] || (store._actions[type] = []);
    entry.push(function wrappedActionHandler(payload, cb) {
      var res = handler.call(store, {
        dispatch: local.dispatch,
        commit: local.commit,
        getters: local.getters,
        state: local.state,
        rootGetters: store.getters,
        rootState: store.state
      }, payload, cb);
      if (!isPromise(res)) {
        res = Promise.resolve(res);
      }
      if (store._devtoolHook) {
        return res.catch(function (err) {
          store._devtoolHook.emit('vuex:error', err);
          throw err;
        });
      } else {
        return res;
      }
    });
  }

  function registerGetter(store, type, rawGetter, local) {
    if (store._wrappedGetters[type]) {
      if (true) {
        console.error("[vuex] duplicate getter key: " + type);
      }
      return;
    }
    store._wrappedGetters[type] = function wrappedGetter(store) {
      return rawGetter(local.state, // local state
      local.getters, // local getters
      store.state, // root state
      store.getters // root getters
      );
    };
  }

  function enableStrictMode(store) {
    store._vm.$watch(function () {
      return this._data.$$state;
    }, function () {
      if (true) {
        assert(store._committing, "do not mutate vuex store state outside mutation handlers.");
      }
    }, { deep: true, sync: true });
  }

  function getNestedState(state, path) {
    return path.length ? path.reduce(function (state, key) {
      return state[key];
    }, state) : state;
  }

  function unifyObjectStyle(type, payload, options) {
    if (isObject(type) && type.type) {
      options = payload;
      payload = type;
      type = type.type;
    }

    if (true) {
      assert(typeof type === 'string', "expects string as the type, but found " + (typeof type === 'undefined' ? 'undefined' : _typeof2(type)) + ".");
    }

    return { type: type, payload: payload, options: options };
  }

  function install(_Vue) {
    if (Vue && _Vue === Vue) {
      if (true) {
        console.error('[vuex] already installed. Vue.use(Vuex) should be called only once.');
      }
      return;
    }
    Vue = _Vue;
    applyMixin(Vue);
  }

  /**
   * Reduce the code which written in Vue.js for getting the state.
   * @param {String} [namespace] - Module's namespace
   * @param {Object|Array} states # Object's item can be a function which accept state and getters for param, you can do something for state and getters in it.
   * @param {Object}
   */
  var mapState = normalizeNamespace(function (namespace, states) {
    var res = {};
    normalizeMap(states).forEach(function (ref) {
      var key = ref.key;
      var val = ref.val;

      res[key] = function mappedState() {
        var state = this.$store.state;
        var getters = this.$store.getters;
        if (namespace) {
          var module = getModuleByNamespace(this.$store, 'mapState', namespace);
          if (!module) {
            return;
          }
          state = module.context.state;
          getters = module.context.getters;
        }
        return typeof val === 'function' ? val.call(this, state, getters) : state[val];
      };
      // mark vuex getter for devtools
      res[key].vuex = true;
    });
    return res;
  });

  /**
   * Reduce the code which written in Vue.js for committing the mutation
   * @param {String} [namespace] - Module's namespace
   * @param {Object|Array} mutations # Object's item can be a function which accept `commit` function as the first param, it can accept anthor params. You can commit mutation and do any other things in this function. specially, You need to pass anthor params from the mapped function.
   * @return {Object}
   */
  var mapMutations = normalizeNamespace(function (namespace, mutations) {
    var res = {};
    normalizeMap(mutations).forEach(function (ref) {
      var key = ref.key;
      var val = ref.val;

      res[key] = function mappedMutation() {
        var args = [],
            len = arguments.length;
        while (len--) {
          args[len] = arguments[len];
        } // Get the commit method from store
        var commit = this.$store.commit;
        if (namespace) {
          var module = getModuleByNamespace(this.$store, 'mapMutations', namespace);
          if (!module) {
            return;
          }
          commit = module.context.commit;
        }
        return typeof val === 'function' ? val.apply(this, [commit].concat(args)) : commit.apply(this.$store, [val].concat(args));
      };
    });
    return res;
  });

  /**
   * Reduce the code which written in Vue.js for getting the getters
   * @param {String} [namespace] - Module's namespace
   * @param {Object|Array} getters
   * @return {Object}
   */
  var mapGetters = normalizeNamespace(function (namespace, getters) {
    var res = {};
    normalizeMap(getters).forEach(function (ref) {
      var key = ref.key;
      var val = ref.val;

      // The namespace has been mutated by normalizeNamespace
      val = namespace + val;
      res[key] = function mappedGetter() {
        if (namespace && !getModuleByNamespace(this.$store, 'mapGetters', namespace)) {
          return;
        }
        if ("development" !== 'production' && !(val in this.$store.getters)) {
          console.error("[vuex] unknown getter: " + val);
          return;
        }
        return this.$store.getters[val];
      };
      // mark vuex getter for devtools
      res[key].vuex = true;
    });
    return res;
  });

  /**
   * Reduce the code which written in Vue.js for dispatch the action
   * @param {String} [namespace] - Module's namespace
   * @param {Object|Array} actions # Object's item can be a function which accept `dispatch` function as the first param, it can accept anthor params. You can dispatch action and do any other things in this function. specially, You need to pass anthor params from the mapped function.
   * @return {Object}
   */
  var mapActions = normalizeNamespace(function (namespace, actions) {
    var res = {};
    normalizeMap(actions).forEach(function (ref) {
      var key = ref.key;
      var val = ref.val;

      res[key] = function mappedAction() {
        var args = [],
            len = arguments.length;
        while (len--) {
          args[len] = arguments[len];
        } // get dispatch function from store
        var dispatch = this.$store.dispatch;
        if (namespace) {
          var module = getModuleByNamespace(this.$store, 'mapActions', namespace);
          if (!module) {
            return;
          }
          dispatch = module.context.dispatch;
        }
        return typeof val === 'function' ? val.apply(this, [dispatch].concat(args)) : dispatch.apply(this.$store, [val].concat(args));
      };
    });
    return res;
  });

  /**
   * Rebinding namespace param for mapXXX function in special scoped, and return them by simple object
   * @param {String} namespace
   * @return {Object}
   */
  var createNamespacedHelpers = function createNamespacedHelpers(namespace) {
    return {
      mapState: mapState.bind(null, namespace),
      mapGetters: mapGetters.bind(null, namespace),
      mapMutations: mapMutations.bind(null, namespace),
      mapActions: mapActions.bind(null, namespace)
    };
  };

  /**
   * Normalize the map
   * normalizeMap([1, 2, 3]) => [ { key: 1, val: 1 }, { key: 2, val: 2 }, { key: 3, val: 3 } ]
   * normalizeMap({a: 1, b: 2, c: 3}) => [ { key: 'a', val: 1 }, { key: 'b', val: 2 }, { key: 'c', val: 3 } ]
   * @param {Array|Object} map
   * @return {Object}
   */
  function normalizeMap(map) {
    return Array.isArray(map) ? map.map(function (key) {
      return { key: key, val: key };
    }) : Object.keys(map).map(function (key) {
      return { key: key, val: map[key] };
    });
  }

  /**
   * Return a function expect two param contains namespace and map. it will normalize the namespace and then the param's function will handle the new namespace and the map.
   * @param {Function} fn
   * @return {Function}
   */
  function normalizeNamespace(fn) {
    return function (namespace, map) {
      if (typeof namespace !== 'string') {
        map = namespace;
        namespace = '';
      } else if (namespace.charAt(namespace.length - 1) !== '/') {
        namespace += '/';
      }
      return fn(namespace, map);
    };
  }

  /**
   * Search a special module from store by namespace. if module not exist, print error message.
   * @param {Object} store
   * @param {String} helper
   * @param {String} namespace
   * @return {Object}
   */
  function getModuleByNamespace(store, helper, namespace) {
    var module = store._modulesNamespaceMap[namespace];
    if ("development" !== 'production' && !module) {
      console.error("[vuex] module namespace not found in " + helper + "(): " + namespace);
    }
    return module;
  }

  var index_esm = {
    Store: Store,
    install: install,
    version: '3.1.0',
    mapState: mapState,
    mapMutations: mapMutations,
    mapGetters: mapGetters,
    mapActions: mapActions,
    createNamespacedHelpers: createNamespacedHelpers
  };

  /* harmony default export */__webpack_exports__["a"] = index_esm;

  /***/
},,,,,,
/* 106 */
/* 107 */
/* 108 */
/* 109 */
/* 110 */
/* 111 */
/***/function (module, exports, __webpack_require__) {

  var core = __webpack_require__(4);
  var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
  module.exports = function stringify(it) {
    // eslint-disable-line no-unused-vars
    return $JSON.stringify.apply($JSON, arguments);
  };

  /***/
},,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
/* 112 */
/* 113 */
/* 114 */
/* 115 */
/* 116 */
/* 117 */
/* 118 */
/* 119 */
/* 120 */
/* 121 */
/* 122 */
/* 123 */
/* 124 */
/* 125 */
/* 126 */
/* 127 */
/* 128 */
/* 129 */
/* 130 */
/* 131 */
/* 132 */
/* 133 */
/* 134 */
/* 135 */
/* 136 */
/* 137 */
/* 138 */
/* 139 */
/* 140 */
/* 141 */
/* 142 */
/* 143 */
/* 144 */
/* 145 */
/* 146 */
/* 147 */
/* 148 */
/* 149 */
/* 150 */
/* 151 */
/* 152 */
/* 153 */
/* 154 */
/* 155 */
/* 156 */
/* 157 */
/* 158 */
/* 159 */
/* 160 */
/* 161 */
/* 162 */
/* 163 */
/* 164 */
/* 165 */
/* 166 */
/* 167 */
/* 168 */
/* 169 */
/* 170 */
/* 171 */
/* 172 */
/* 173 */
/* 174 */
/* 175 */
/* 176 */
/* 177 */
/* 178 */
/* 179 */
/* 180 */
/* 181 */
/* 182 */
/* 183 */
/* 184 */
/* 185 */
/* 186 */
/* 187 */
/* 188 */
/* 189 */
/* 190 */
/* 191 */
/* 192 */
/* 193 */
/* 194 */
/* 195 */
/* 196 */
/* 197 */
/* 198 */
/* 199 */
/* 200 */
/* 201 */
/* 202 */
/* 203 */
/* 204 */
/* 205 */
/* 206 */
/* 207 */
/* 208 */
/* 209 */
/* 210 */
/***/function (module, exports) {

  /*
  	MIT License http://www.opensource.org/licenses/mit-license.php
  	Author Tobias Koppers @sokra
  */
  // css base code, injected by the css-loader
  module.exports = function (useSourceMap) {
    var list = [];

    // return the list of modules as css string
    list.toString = function toString() {
      return this.map(function (item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) {
          return "@media " + item[2] + "{" + content + "}";
        } else {
          return content;
        }
      }).join("");
    };

    // import a list of modules into the list
    list.i = function (modules, mediaQuery) {
      if (typeof modules === "string") modules = [[null, modules, ""]];
      var alreadyImportedModules = {};
      for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (typeof id === "number") alreadyImportedModules[id] = true;
      }
      for (i = 0; i < modules.length; i++) {
        var item = modules[i];
        // skip already imported module
        // this implementation is not 100% perfect for weird media query combinations
        //  when a module is imported multiple times with different media queries.
        //  I hope this will never occur (Hey this way we have smaller bundles)
        if (typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
          if (mediaQuery && !item[2]) {
            item[2] = mediaQuery;
          } else if (mediaQuery) {
            item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
          }
          list.push(item);
        }
      }
    };
    return list;
  };

  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || '';
    var cssMapping = item[3];
    if (!cssMapping) {
      return content;
    }

    if (useSourceMap && typeof btoa === 'function') {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map(function (source) {
        return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */';
      });

      return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
    }

    return [content].join('\n');
  }

  // Adapted from convert-source-map (MIT)
  function toComment(sourceMap) {
    // eslint-disable-next-line no-undef
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

    return '/*# ' + data + ' */';
  }

  /***/
},
/* 211 */
/***/function (module, __webpack_exports__, __webpack_require__) {

  "use strict";

  Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
  /* harmony export (immutable) */__webpack_exports__["default"] = addStylesClient;
  /* harmony import */var __WEBPACK_IMPORTED_MODULE_0__listToStyles__ = __webpack_require__(47);
  /*
    MIT License http://www.opensource.org/licenses/mit-license.php
    Author Tobias Koppers @sokra
    Modified by Evan You @yyx990803
  */

  var hasDocument = typeof document !== 'undefined';

  if (typeof DEBUG !== 'undefined' && DEBUG) {
    if (!hasDocument) {
      throw new Error('vue-style-loader cannot be used in a non-browser environment. ' + "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
    }
  }

  /*
  type StyleObject = {
    id: number;
    parts: Array<StyleObjectPart>
  }
  
  type StyleObjectPart = {
    css: string;
    media: string;
    sourceMap: ?string
  }
  */

  var stylesInDom = {/*
                     [id: number]: {
                     id: number,
                     refs: number,
                     parts: Array<(obj?: StyleObjectPart) => void>
                     }
                     */};

  var head = hasDocument && (document.head || document.getElementsByTagName('head')[0]);
  var singletonElement = null;
  var singletonCounter = 0;
  var isProduction = false;
  var noop = function noop() {};
  var options = null;
  var ssrIdKey = 'data-vue-ssr-id';

  // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
  // tags it will allow on a page
  var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

  function addStylesClient(parentId, list, _isProduction, _options) {
    isProduction = _isProduction;

    options = _options || {};

    var styles = Object(__WEBPACK_IMPORTED_MODULE_0__listToStyles__["a" /* default */])(parentId, list);
    addStylesToDom(styles);

    return function update(newList) {
      var mayRemove = [];
      for (var i = 0; i < styles.length; i++) {
        var item = styles[i];
        var domStyle = stylesInDom[item.id];
        domStyle.refs--;
        mayRemove.push(domStyle);
      }
      if (newList) {
        styles = Object(__WEBPACK_IMPORTED_MODULE_0__listToStyles__["a" /* default */])(parentId, newList);
        addStylesToDom(styles);
      } else {
        styles = [];
      }
      for (var i = 0; i < mayRemove.length; i++) {
        var domStyle = mayRemove[i];
        if (domStyle.refs === 0) {
          for (var j = 0; j < domStyle.parts.length; j++) {
            domStyle.parts[j]();
          }
          delete stylesInDom[domStyle.id];
        }
      }
    };
  }

  function addStylesToDom(styles /* Array<StyleObject> */) {
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i];
      var domStyle = stylesInDom[item.id];
      if (domStyle) {
        domStyle.refs++;
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j](item.parts[j]);
        }
        for (; j < item.parts.length; j++) {
          domStyle.parts.push(addStyle(item.parts[j]));
        }
        if (domStyle.parts.length > item.parts.length) {
          domStyle.parts.length = item.parts.length;
        }
      } else {
        var parts = [];
        for (var j = 0; j < item.parts.length; j++) {
          parts.push(addStyle(item.parts[j]));
        }
        stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts };
      }
    }
  }

  function createStyleElement() {
    var styleElement = document.createElement('style');
    styleElement.type = 'text/css';
    head.appendChild(styleElement);
    return styleElement;
  }

  function addStyle(obj /* StyleObjectPart */) {
    var update, remove;
    var styleElement = document.querySelector('style[' + ssrIdKey + '~="' + obj.id + '"]');

    if (styleElement) {
      if (isProduction) {
        // has SSR styles and in production mode.
        // simply do nothing.
        return noop;
      } else {
        // has SSR styles but in dev mode.
        // for some reason Chrome can't handle source map in server-rendered
        // style tags - source maps in <style> only works if the style tag is
        // created and inserted dynamically. So we remove the server rendered
        // styles and inject new ones.
        styleElement.parentNode.removeChild(styleElement);
      }
    }

    if (isOldIE) {
      // use singleton mode for IE9.
      var styleIndex = singletonCounter++;
      styleElement = singletonElement || (singletonElement = createStyleElement());
      update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
      remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
    } else {
      // use multi-style-tag mode in all other cases
      styleElement = createStyleElement();
      update = applyToTag.bind(null, styleElement);
      remove = function remove() {
        styleElement.parentNode.removeChild(styleElement);
      };
    }

    update(obj);

    return function updateStyle(newObj /* StyleObjectPart */) {
      if (newObj) {
        if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
          return;
        }
        update(obj = newObj);
      } else {
        remove();
      }
    };
  }

  var replaceText = function () {
    var textStore = [];

    return function (index, replacement) {
      textStore[index] = replacement;
      return textStore.filter(Boolean).join('\n');
    };
  }();

  function applyToSingletonTag(styleElement, index, remove, obj) {
    var css = remove ? '' : obj.css;

    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = replaceText(index, css);
    } else {
      var cssNode = document.createTextNode(css);
      var childNodes = styleElement.childNodes;
      if (childNodes[index]) styleElement.removeChild(childNodes[index]);
      if (childNodes.length) {
        styleElement.insertBefore(cssNode, childNodes[index]);
      } else {
        styleElement.appendChild(cssNode);
      }
    }
  }

  function applyToTag(styleElement, obj) {
    var css = obj.css;
    var media = obj.media;
    var sourceMap = obj.sourceMap;

    if (media) {
      styleElement.setAttribute('media', media);
    }
    if (options.ssrId) {
      styleElement.setAttribute(ssrIdKey, obj.id);
    }

    if (sourceMap) {
      // https://developer.chrome.com/devtools/docs/javascript-debugging
      // this makes source maps inside style tags work properly in Chrome
      css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */';
      // http://stackoverflow.com/a/26603875
      css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */';
    }

    if (styleElement.styleSheet) {
      styleElement.styleSheet.cssText = css;
    } else {
      while (styleElement.firstChild) {
        styleElement.removeChild(styleElement.firstChild);
      }
      styleElement.appendChild(document.createTextNode(css));
    }
  }

  /***/
}]);
});
define("pages/counter/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([5], {

  /***/100:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(101);

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/101:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(103);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1946d4a8_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(106);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(102);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1946d4a8_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/counter/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-1946d4a8", Component.options);
        } else {
          hotAPI.reload("data-v-1946d4a8", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/102:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/103:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__store__ = __webpack_require__(104);
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    // Use Vuex


    /* harmony default export */__webpack_exports__["a"] = {
      computed: {
        count: function count() {
          return __WEBPACK_IMPORTED_MODULE_0__store__["a" /* default */].state.count;
        }
      },
      methods: {
        increment: function increment() {
          __WEBPACK_IMPORTED_MODULE_0__store__["a" /* default */].commit('increment');
        },
        decrement: function decrement() {
          __WEBPACK_IMPORTED_MODULE_0__store__["a" /* default */].commit('decrement');
        }
      }
    };

    /***/
  },

  /***/104:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1_vuex__ = __webpack_require__(105);
    // https://vuex.vuejs.org/zh-cn/intro.html
    // make sure to call Vue.use(Vuex) if using a module system


    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */]);

    var store = new __WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */].Store({
      state: {
        count: 0
      },
      mutations: {
        increment: function increment(state) {
          var obj = state;
          obj.count += 1;
        },
        decrement: function decrement(state) {
          var obj = state;
          obj.count -= 1;
        }
      }
    });

    /* harmony default export */__webpack_exports__["a"] = store;

    /***/
  },

  /***/106:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('div', {
        staticClass: "counter-warp"
      }, [_c('p', [_vm._v("Vuex counter：" + _vm._s(_vm.count))]), _vm._v(" "), _c('p', [_c('button', {
        attrs: {
          "eventid": '0'
        },
        on: {
          "click": _vm.increment
        }
      }, [_vm._v("+")]), _vm._v(" "), _c('button', {
        attrs: {
          "eventid": '1'
        },
        on: {
          "click": _vm.decrement
        }
      }, [_vm._v("-")])], 1)], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-1946d4a8", esExports);
      }
    }

    /***/
  }

}, [100]);
});
define("pages/logs/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([2], {

  /***/136:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(137);

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/137:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(139);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_2649a5ce_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(144);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(138);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_2649a5ce_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/logs/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-2649a5ce", Component.options);
        } else {
          hotAPI.reload("data-v-2649a5ce", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/138:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/139:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__utils_index__ = __webpack_require__(17);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__components_card__ = __webpack_require__(140);
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      components: {
        card: __WEBPACK_IMPORTED_MODULE_1__components_card__["a" /* default */]
      },

      data: function data() {
        return {
          logs: [],
          imgUrls: ['http://mss.sankuai.com/v1/mss_51a7233366a4427fa6132a6ce72dbe54/newsPicture/05558951-de60-49fb-b674-dd906c8897a6', 'http://mss.sankuai.com/v1/mss_51a7233366a4427fa6132a6ce72dbe54/coursePicture/0fbcfdf7-0040-4692-8f84-78bb21f3395d', 'http://mss.sankuai.com/v1/mss_51a7233366a4427fa6132a6ce72dbe54/management-school-picture/7683b32e-4e44-4b2f-9c03-c21f34320870']
        };
      },
      created: function created() {
        var logs = void 0;
        if (global.mpvuePlatform === 'my') {
          logs = global.mpvue.getStorageSync({ key: 'logs' }).data || [];
        } else {
          logs = global.mpvue.getStorageSync('logs') || [];
        }
        this.logs = logs.map(function (log) {
          return Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["f" /* formatTime */])(new Date(log));
        });
      }
    };

    /***/
  },

  /***/140:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_card_vue__ = __webpack_require__(142);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_4e3fe29d_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_card_vue__ = __webpack_require__(143);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(141);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_card_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_4e3fe29d_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_card_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/components/card.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] card.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-4e3fe29d", Component.options);
        } else {
          hotAPI.reload("data-v-4e3fe29d", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/141:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/142:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //

    /* harmony default export */
    __webpack_exports__["a"] = {
      props: ['text']
    };

    /***/
  },

  /***/143:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('div', [_c('p', {
        staticClass: "card"
      }, [_vm._v("\n    " + _vm._s(_vm.text) + "\n  ")])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-4e3fe29d", esExports);
      }
    }

    /***/
  },

  /***/144:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('div', [_vm.imgUrls.length > 0 ? _c('swiper', {
        attrs: {
          "indidator-dots": "imgUrls.length > 1"
        }
      }, _vm._l(_vm.imgUrls, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('swiper-item', {
          attrs: {
            "mpcomid": '0_' + index
          }
        }, [_c('image', {
          attrs: {
            "src": item,
            "mode": "scaleToFill"
          }
        })])], 1);
      })) : _vm._e(), _vm._v(" "), _c('ul', {
        staticClass: "container log-list"
      }, _vm._l(_vm.logs, function (log, index) {
        return _c('li', {
          key: index,
          staticClass: "log-item",
          class: {
            red: _vm.aa
          }
        }, [_c('card', {
          attrs: {
            "text": index + 1 + ' . ' + log,
            "mpcomid": '1_' + index
          }
        })], 1);
      }))], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-2649a5ce", esExports);
      }
    }

    /***/
  }

}, [136]);
});
define("static/iview/action-sheet/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class', 'i-class-mask', 'i-class-header'],

    options: {
        multipleSlots: true
    },

    properties: {
        visible: {
            type: Boolean,
            value: false
        },
        maskClosable: {
            type: Boolean,
            value: true
        },
        showCancel: {
            type: Boolean,
            value: false
        },
        cancelText: {
            type: String,
            value: '取消'
        },
        actions: {
            type: Array,
            value: []
        }
    },

    methods: {
        handleClickMask: function handleClickMask() {
            if (!this.data.maskClosable) return;
            this.handleClickCancel();
        },
        handleClickItem: function handleClickItem(_ref) {
            var _ref$currentTarget = _ref.currentTarget,
                currentTarget = _ref$currentTarget === undefined ? {} : _ref$currentTarget;

            var dataset = currentTarget.dataset || {};
            var index = dataset.index;

            this.triggerEvent('iclick', { index: index });
        },
        handleClickCancel: function handleClickCancel() {
            this.triggerEvent('cancel');
        }
    }
});
});
define("static/iview/alert/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    options: {
        multipleSlots: true
    },
    properties: {
        //info, success, warning, error
        type: {
            type: String,
            value: 'info'
        },
        closable: {
            type: Boolean,
            value: false
        },
        showIcon: {
            type: Boolean,
            default: false
        },
        desc: {
            type: Boolean,
            default: false
        }
    },
    data: {
        closed: false
    },
    methods: {
        handleTap: function handleTap() {
            this.setData({
                closed: !this.data.closed
            });
            this.triggerEvent('close');
        }
    }
});
});
define("static/iview/avatar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        // circle || square
        shape: {
            type: String,
            value: 'circle'
        },
        // small || large || default
        size: {
            type: String,
            value: 'default'
        },
        src: {
            type: String,
            value: ''
        }
    }
});
});
define("static/iview/badge/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class', 'i-class-alone'],

    properties: {
        count: {
            type: Number,
            value: 0,
            observer: 'finalCount'
        },
        overflowCount: {
            type: Number,
            value: 99
        },
        dot: {
            type: Boolean,
            value: false
        }
    },
    data: {
        finalCount: 0
    },
    methods: {
        finalCount: function finalCount() {
            this.setData({
                finalCount: parseInt(this.data.count) >= parseInt(this.data.overflowCount) ? this.data.overflowCount + '+' : this.data.count
            });
        }
    }
});
});
define("static/iview/base/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function getCtx(selector) {
    var pages = getCurrentPages();
    var ctx = pages[pages.length - 1];

    var componentCtx = ctx.selectComponent(selector);

    if (!componentCtx) {
        console.error('无法找到对应的组件，请按文档说明使用组件');
        return null;
    }
    return componentCtx;
}

function Toast(options) {
    var _options$selector = options.selector,
        selector = _options$selector === undefined ? '#toast' : _options$selector;

    var ctx = getCtx(selector);

    ctx.handleShow(options);
}

Toast.hide = function () {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#toast';

    var ctx = getCtx(selector);

    ctx.handleHide();
};

function Message(options) {
    var _options$selector2 = options.selector,
        selector = _options$selector2 === undefined ? '#message' : _options$selector2;

    var ctx = getCtx(selector);

    ctx.handleShow(options);
}

module.exports = {
    $Toast: Toast,
    $Message: Message
};
});
define("static/iview/button/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        // default, primary, ghost, info, success, warning, error
        type: {
            type: String,
            value: ''
        },
        inline: {
            type: Boolean,
            value: false
        },
        // default, large, small
        size: {
            type: String,
            value: ''
        },
        // circle, square
        shape: {
            type: String,
            value: 'square'
        },
        disabled: {
            type: Boolean,
            value: false
        },
        loading: {
            type: Boolean,
            value: false
        },
        long: {
            type: Boolean,
            value: false
        },
        openType: String,
        appParameter: String,
        hoverStopPropagation: Boolean,
        hoverStartTime: {
            type: Number,
            value: 20
        },
        hoverStayTime: {
            type: Number,
            value: 70
        },
        lang: {
            type: String,
            value: 'en'
        },
        sessionFrom: {
            type: String,
            value: ''
        },
        sendMessageTitle: String,
        sendMessagePath: String,
        sendMessageImg: String,
        showMessageCard: Boolean
    },

    methods: {
        handleTap: function handleTap() {
            if (this.data.disabled) return false;

            this.triggerEvent('click');
        },
        bindgetuserinfo: function bindgetuserinfo() {
            var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                _ref$detail = _ref.detail,
                detail = _ref$detail === undefined ? {} : _ref$detail;

            this.triggerEvent('getuserinfo', detail);
        },
        bindcontact: function bindcontact() {
            var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                _ref2$detail = _ref2.detail,
                detail = _ref2$detail === undefined ? {} : _ref2$detail;

            this.triggerEvent('contact', detail);
        },
        bindgetphonenumber: function bindgetphonenumber() {
            var _ref3 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                _ref3$detail = _ref3.detail,
                detail = _ref3$detail === undefined ? {} : _ref3$detail;

            this.triggerEvent('getphonenumber', detail);
        },
        binderror: function binderror() {
            var _ref4 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
                _ref4$detail = _ref4.detail,
                detail = _ref4$detail === undefined ? {} : _ref4$detail;

            this.triggerEvent('error', detail);
        }
    }
});
});
define("static/iview/card/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    options: {
        multipleSlots: true
    },

    properties: {
        full: {
            type: Boolean,
            value: false
        },
        thumb: {
            type: String,
            value: ''
        },
        title: {
            type: String,
            value: ''
        },
        extra: {
            type: String,
            value: ''
        }
    }
});
});
define("static/iview/cell-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../cell/index': {
            type: 'child',
            linked: function linked() {
                this._updateIsLastCell();
            },
            linkChanged: function linkChanged() {
                this._updateIsLastCell();
            },
            unlinked: function unlinked() {
                this._updateIsLastCell();
            }
        }
    },

    methods: {
        _updateIsLastCell: function _updateIsLastCell() {
            var cells = this.getRelationNodes('../cell/index');
            var len = cells.length;

            if (len > 0) {
                var lastIndex = len - 1;

                cells.forEach(function (cell, index) {
                    cell.updateIsLastCell(index === lastIndex);
                });
            }
        }
    }
});
});
define("static/iview/cell/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var warn = function warn(msg, getValue) {
    console.warn(msg);
    console.log('接受到的值为：', getValue);
};

Component({
    externalClasses: ['i-class'],

    options: {
        multipleSlots: true
    },

    relations: {
        '../cell-group/index': {
            type: 'parent'
        }
    },

    properties: {
        // 左侧标题
        title: {
            type: String
        },
        // 标题下方的描述信息
        label: {
            type: String
        },
        // 右侧内容
        value: {
            type: String
        },
        // 只有点击 footer 区域才触发 tab 事件
        onlyTapFooter: {
            type: Boolean
        },
        // 是否展示右侧箭头并开启尝试以 url 跳转
        isLink: {
            type: null,
            value: ''
        },
        // 链接类型，可选值为 navigateTo，redirectTo，switchTab，reLaunch
        linkType: {
            type: String,
            value: 'navigateTo'
        },
        url: {
            type: String,
            value: ''
        }
    },

    data: {
        isLastCell: true
    },

    methods: {
        navigateTo: function navigateTo() {
            var url = this.data.url;

            var type = _typeof(this.data.isLink);

            this.triggerEvent('click', {});

            if (!this.data.isLink || !url || url === 'true' || url === 'false') return;

            if (type !== 'boolean' && type !== 'string') {
                warn('isLink 属性值必须是一个字符串或布尔值', this.data.isLink);
                return;
            }

            if (['navigateTo', 'redirectTo', 'switchTab', 'reLaunch'].indexOf(this.data.linkType) === -1) {
                warn('linkType 属性可选值为 navigateTo，redirectTo，switchTab，reLaunch', this.data.linkType);
                return;
            }
            wx[this.data.linkType].call(wx, { url: url });
        },
        handleTap: function handleTap() {
            if (!this.data.onlyTapFooter) {
                this.navigateTo();
            }
        },
        updateIsLastCell: function updateIsLastCell(isLastCell) {
            this.setData({ isLastCell: isLastCell });
        }
    }
});
});
define("static/iview/checkbox-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    relations: {
        '../checkbox/index': {
            type: 'child',
            linked: function linked() {
                this.changeCurrent();
            },
            linkChanged: function linkChanged() {
                this.changeCurrent();
            },
            unlinked: function unlinked() {
                this.changeCurrent();
            }
        }
    },
    properties: {
        current: {
            type: Array,
            value: [],
            observer: 'changeCurrent'
        }
    },
    methods: {
        changeCurrent: function changeCurrent() {
            var val = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.current;

            var items = this.getRelationNodes('../checkbox/index');
            var len = items.length;
            if (len > 0) {
                items.forEach(function (item) {
                    item.changeCurrent(val.indexOf(item.data.value) !== -1);
                });
            }
        },
        emitEvent: function emitEvent(current) {
            this.triggerEvent('change', current);
        }
    }
});
});
define("static/iview/checkbox/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var prefixCls = 'i-checkbox';

Component({
    externalClasses: ['i-class'],
    relations: {
        '../checkbox-group/index': {
            type: 'parent'
        }
    },
    properties: {
        value: {
            type: String,
            value: ''
        },
        checked: {
            type: Boolean,
            value: false
        },
        disabled: {
            type: Boolean,
            value: false
        },
        color: {
            type: String,
            value: '#2d8cf0'
        },
        position: {
            type: String,
            value: 'left', //left right
            observer: 'setPosition'
        }
    },
    data: {
        checked: true,
        positionCls: prefixCls + '-checkbox-left'
    },
    attached: function attached() {
        this.setPosition();
    },

    methods: {
        changeCurrent: function changeCurrent(current) {
            this.setData({ checked: current });
        },
        checkboxChange: function checkboxChange() {
            if (this.data.disabled) return;
            var item = { current: !this.data.checked, value: this.data.value };
            var parent = this.getRelationNodes('../checkbox-group/index')[0];
            parent ? parent.emitEvent(item) : this.triggerEvent('change', item);
        },
        setPosition: function setPosition() {
            this.setData({
                positionCls: this.data.position.indexOf('left') !== -1 ? prefixCls + '-checkbox-left' : prefixCls + '-checkbox-right'
            });
        }
    }
});
});
define("static/iview/col/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../row/index': {
            type: 'parent'
        }
    },

    properties: {
        span: {
            value: 0,
            type: Number
        },
        offset: {
            value: 0,
            type: Number
        }
    }
});
});
define("static/iview/collapse-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class-content', 'i-class-title', 'i-class'],

    relations: {
        '../collapse/index': {
            type: 'parent',
            linked: function linked(target) {
                var options = {
                    accordion: target.data.accordion
                };
                if (target.data.name === this.data.name) {
                    options.showContent = 'i-collapse-item-show-content';
                }
                this.setData(options);
            }
        }
    },

    properties: {
        title: String,
        name: String
    },

    data: {
        showContent: '',
        accordion: false
    },

    options: {
        multipleSlots: true
    },

    methods: {
        trigger: function trigger(e) {
            var data = this.data;
            if (data.accordion) {
                this.triggerEvent('collapse', { name: data.name }, { composed: true, bubbles: true });
            } else {
                this.setData({
                    showContent: data.showContent ? '' : 'i-collapse-item-show-content'
                });
            }
        }
    }
});
});
define("static/iview/collapse/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../collapse-item/index': {
            type: 'child'
        }
    },
    properties: {
        name: String,
        accordion: Boolean
    },
    methods: {
        clickfn: function clickfn(e) {
            var params = e.detail;
            var allList = this.getRelationNodes('../collapse-item/index');
            allList.forEach(function (item) {
                if (params.name === item.data.name) {
                    item.setData({
                        showContent: 'i-collapse-item-show-content'
                    });
                } else {
                    item.setData({
                        showContent: ''
                    });
                }
            });
        }
    }
});
});
define("static/iview/count-down/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    properties: {
        target: Number,
        showDay: Boolean,
        callback: String,
        format: Array,
        clearTimer: Boolean
    },
    externalClasses: ['countdown-class'],
    data: {
        time: '',
        resultFormat: [],
        changeFormat: false
    },
    ready: function ready() {
        this.getFormat();
    },

    methods: {
        getFormat: function getFormat() {
            var data = this.data;
            var len = data.format.length;

            if (!data.showDay) data.resultFormat.push('');

            if (len >= 3) {
                for (var i = 0; i < len; i++) {
                    if (data.resultFormat.length >= 4) break;
                    if (data.format[i]) {
                        data.resultFormat.push(data.format[i].toString());
                    }
                }

                if (data.resultFormat.length >= 4) data.changeFormat = true;
            }

            this.getLastTime();
        },
        init: function init() {
            var self = this;
            setTimeout(function () {
                self.getLastTime.call(self);
            }, 1000);
        },
        getLastTime: function getLastTime() {
            var data = this.data;
            var gapTime = Math.ceil((data.target - new Date().getTime()) / 1000);
            var result = '';
            var time = '00:00:00';
            var day = '00';
            var format = data.resultFormat;

            if (gapTime > 0) {
                day = this.formatNum(parseInt(gapTime / 86400));
                var lastTime = gapTime % 86400;
                var hour = this.formatNum(parseInt(lastTime / 3600));
                lastTime = lastTime % 3600;
                var minute = this.formatNum(parseInt(lastTime / 60));
                var second = this.formatNum(lastTime % 60);

                if (data.changeFormat) time = '' + hour + format[1] + minute + format[2] + second + format[3];else time = hour + ':' + minute + ':' + second;

                if (!data.clearTimer) this.init.call(this);
            } else {
                this.endfn();
            }

            if (data.showDay) {
                if (data.changeFormat) {
                    result = '' + day + format[0] + ' ' + time;
                } else {
                    result = day + 'd ' + time;
                }
            } else {
                result = time;
            }
            this.setData({
                time: result
            });
        },
        formatNum: function formatNum(num) {
            return num > 9 ? num : '0' + num;
        },
        endfn: function endfn() {
            this.triggerEvent('callback', {});
        }
    }
});
});
define("static/iview/divider/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        content: {
            type: String,
            value: ''
        },
        height: {
            type: Number,
            value: 48
        },
        color: {
            type: String,
            value: '#80848f'
        },
        lineColor: {
            type: String,
            value: '#e9eaec'
        },
        size: {
            type: String,
            value: 12
        }
    }
});
});
define("static/iview/drawer/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        visible: {
            type: Boolean,
            value: false
        },

        mask: {
            type: Boolean,
            value: true
        },

        maskClosable: {
            type: Boolean,
            value: true
        },

        mode: {
            type: String,
            value: 'left' // left right
        }
    },
    data: {},
    methods: {
        handleMaskClick: function handleMaskClick() {
            if (!this.data.maskClosable) {
                return;
            }
            this.triggerEvent('close', {});
        }
    }
});
});
define("static/iview/grid-icon/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../grid-item/index': {
            type: 'parent'
        }
    }

});
});
define("static/iview/grid-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../grid/index': {
            type: 'parent'
        },
        '../grid-icon/index': {
            type: 'child'
        }
    },

    data: {
        width: '33.33%'
    }
});
});
define("static/iview/grid-label/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../grid-item/index': {
            type: 'parent'
        }
    }

});
});
define("static/iview/grid/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../grid-item/index': {
            type: 'child',
            linked: function linked() {
                this.setGridItemWidth();
            },
            linkChanged: function linkChanged() {
                this.setGridItemWidth();
            },
            unlinked: function unlinked() {
                this.setGridItemWidth();
            }
        }
    },

    methods: {
        setGridItemWidth: function setGridItemWidth() {
            var nodes = this.getRelationNodes('../grid-item/index');

            // const len = nodes.length;
            // if (len < 3) {
            //     nodes.forEach(item => {
            //         item.setData({
            //             'width': '33.33%'
            //         });
            //     });
            // } else {
            //     const width = 100 / nodes.length;
            //     nodes.forEach(item => {
            //         item.setData({
            //             'width': width + '%'
            //         });
            //     });
            // }
            var width = 100 / nodes.length;
            nodes.forEach(function (item) {
                item.setData({
                    'width': width + '%'
                });
            });
        }
    },

    ready: function ready() {
        this.setGridItemWidth();
    }
});
});
define("static/iview/icon/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        type: {
            type: String,
            value: ''
        },
        custom: {
            type: String,
            value: ''
        },
        size: {
            type: Number,
            value: 14
        },
        color: {
            type: String,
            value: ''
        }
    }
});
});
define("static/iview/index-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        name: {
            type: String,
            value: ''
        }
    },
    relations: {
        '../index/index': {
            type: 'parent'
        }
    },
    data: {
        top: 0,
        height: 0,
        currentName: ''
    },
    methods: {
        updateDataChange: function updateDataChange() {
            var _this = this;

            var className = '.i-index-item';
            var query = wx.createSelectorQuery().in(this);
            query.select(className).boundingClientRect(function (res) {
                _this.setData({
                    top: res.top,
                    height: res.height,
                    currentName: _this.data.name
                });
            }).exec();
        }
    }
});
});
define("static/iview/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        height: {
            type: String,
            value: '300'
        },
        itemHeight: {
            type: Number,
            value: 18
        }
    },
    relations: {
        '../index-item/index': {
            type: 'child',
            linked: function linked() {
                this._updateDataChange();
            },
            linkChanged: function linkChanged() {
                this._updateDataChange();
            },
            unlinked: function unlinked() {
                this._updateDataChange();
            }
        }
    },
    data: {
        scrollTop: 0,
        fixedData: [],
        current: 0,
        timer: null,
        startTop: 0,
        itemLength: 0,
        currentName: '',
        isTouches: false
    },
    methods: {
        loop: function loop() {},
        _updateDataChange: function _updateDataChange() {
            var _this = this;

            var indexItems = this.getRelationNodes('../index-item/index');
            var len = indexItems.length;
            var fixedData = this.data.fixedData;
            /*
             * 使用函数节流限制重复去设置数组内容进而限制多次重复渲染
             * 暂时没有研究微信在渲染的时候是否会进行函数节流
            */
            if (len > 0) {

                if (this.data.timer) {
                    clearTimeout(this.data.timer);
                    this.setData({
                        timer: null
                    });
                }

                this.data.timer = setTimeout(function () {
                    var data = [];
                    indexItems.forEach(function (item) {
                        if (item.data.name && fixedData.indexOf(item.data.name) === -1) {
                            data.push(item.data.name);
                            item.updateDataChange();
                        }
                    });
                    _this.setData({
                        fixedData: data,
                        itemLength: indexItems.length
                    });
                    //组件加载完成之后重新设置顶部高度
                    _this.setTouchStartVal();
                }, 0);
                this.setData({
                    timer: this.data.timer
                });
            }
        },
        handlerScroll: function handlerScroll(event) {
            var _this2 = this;

            var detail = event.detail;
            var scrollTop = detail.scrollTop;
            var indexItems = this.getRelationNodes('../index-item/index');
            indexItems.forEach(function (item, index) {
                var data = item.data;
                var offset = data.top + data.height;
                if (scrollTop < offset && scrollTop >= data.top) {
                    _this2.setData({
                        current: index,
                        currentName: data.currentName
                    });
                }
            });
        },
        getCurrentItem: function getCurrentItem(index) {
            var indexItems = this.getRelationNodes('../index-item/index');
            var result = {};
            result = indexItems[index].data;
            result.total = indexItems.length;
            return result;
        },
        triggerCallback: function triggerCallback(options) {
            this.triggerEvent('change', options);
        },
        handlerFixedTap: function handlerFixedTap(event) {
            var eindex = event.currentTarget.dataset.index;
            var item = this.getCurrentItem(eindex);
            this.setData({
                scrollTop: item.top,
                currentName: item.currentName,
                isTouches: true
            });
            this.triggerCallback({
                index: eindex,
                current: item.currentName
            });
        },
        handlerTouchMove: function handlerTouchMove(event) {
            var data = this.data;
            var touches = event.touches[0] || {};
            var pageY = touches.pageY;
            var rest = pageY - data.startTop;
            var index = Math.ceil(rest / data.itemHeight);
            index = index >= data.itemLength ? data.itemLength - 1 : index;
            var movePosition = this.getCurrentItem(index);

            /*
             * 当touch选中的元素和当前currentName不相等的时候才震动一下
             * 微信震动事件
            */
            if (movePosition.name !== this.data.currentName) {
                wx.vibrateShort();
            }

            this.setData({
                scrollTop: movePosition.top,
                currentName: movePosition.name,
                isTouches: true
            });

            this.triggerCallback({
                index: index,
                current: movePosition.name
            });
        },
        handlerTouchEnd: function handlerTouchEnd() {
            this.setData({
                isTouches: false
            });
        },
        setTouchStartVal: function setTouchStartVal() {
            var _this3 = this;

            var className = '.i-index-fixed';
            var query = wx.createSelectorQuery().in(this);
            query.select(className).boundingClientRect(function (res) {
                _this3.setData({
                    startTop: res.top
                });
            }).exec();
        }
    }
});
});
define("static/iview/input-number/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function addNum(num1, num2) {
    var sq1 = void 0,
        sq2 = void 0,
        m = void 0;
    try {
        sq1 = num1.toString().split('.')[1].length;
    } catch (e) {
        sq1 = 0;
    }
    try {
        sq2 = num2.toString().split('.')[1].length;
    } catch (e) {
        sq2 = 0;
    }
    m = Math.pow(10, Math.max(sq1, sq2));
    return (Math.round(num1 * m) + Math.round(num2 * m)) / m;
}

Component({
    externalClasses: ['i-class'],

    properties: {
        // small || default || large
        size: String,
        value: {
            type: Number,
            value: 1
        },
        min: {
            type: Number,
            value: -Infinity
        },
        max: {
            type: Number,
            value: Infinity
        },
        step: {
            type: Number,
            value: 1
        }
    },

    methods: {
        handleChangeStep: function handleChangeStep(e, type) {
            var _e$currentTarget$data = e.currentTarget.dataset,
                dataset = _e$currentTarget$data === undefined ? {} : _e$currentTarget$data;
            var disabled = dataset.disabled;
            var step = this.data.step;
            var value = this.data.value;


            if (disabled) return null;

            if (type === 'minus') {
                value = addNum(value, -step);
            } else if (type === 'plus') {
                value = addNum(value, step);
            }

            if (value < this.data.min || value > this.data.max) return null;

            this.handleEmit(value, type);
        },
        handleMinus: function handleMinus(e) {
            this.handleChangeStep(e, 'minus');
        },
        handlePlus: function handlePlus(e) {
            this.handleChangeStep(e, 'plus');
        },
        handleBlur: function handleBlur(e) {
            var _this = this;

            var value = e.detail.value;
            var _data = this.data,
                min = _data.min,
                max = _data.max;


            if (!value) {
                setTimeout(function () {
                    _this.handleEmit(value);
                }, 16);
                return;
            }

            value = +value;
            if (value > max) {
                value = max;
            } else if (value < min) {
                value = min;
            }

            this.handleEmit(value);
        },
        handleEmit: function handleEmit(value, type) {
            var data = {
                value: value
            };
            if (type) data.type = type;

            this.triggerEvent('change', data);
        }
    }
});
});
define("static/iview/input/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    behaviors: ['wx://form-field'],

    externalClasses: ['i-class'],

    properties: {
        title: {
            type: String
        },
        // text || textarea || password || number
        type: {
            type: String,
            value: 'text'
        },
        disabled: {
            type: Boolean,
            value: false
        },
        placeholder: {
            type: String,
            value: ''
        },
        autofocus: {
            type: Boolean,
            value: false
        },
        mode: {
            type: String,
            value: 'normal'
        },
        right: {
            type: Boolean,
            value: false
        },
        error: {
            type: Boolean,
            value: false
        },
        maxlength: {
            type: Number
        }
    },

    methods: {
        handleInputChange: function handleInputChange(event) {
            var _event$detail = event.detail,
                detail = _event$detail === undefined ? {} : _event$detail;
            var _detail$value = detail.value,
                value = _detail$value === undefined ? '' : _detail$value;

            this.setData({ value: value });

            this.triggerEvent('change', event);
        },
        handleInputFocus: function handleInputFocus(event) {
            this.triggerEvent('focus', event);
        },
        handleInputBlur: function handleInputBlur(event) {
            this.triggerEvent('blur', event);
        }
    }
});
});
define("static/iview/load-more/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        loading: {
            type: Boolean,
            value: true
        },
        tip: {
            type: String,
            value: ''
        }
    }
});
});
define("static/iview/message/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var default_data = {
    visible: false,
    content: '',
    duration: 2,
    type: 'default' // default || success || warning || error
};

var timmer = null;

Component({
    externalClasses: ['i-class'],

    data: _extends({}, default_data),

    methods: {
        handleShow: function handleShow(options) {
            var _this = this;

            var _options$type = options.type,
                type = _options$type === undefined ? 'default' : _options$type,
                _options$duration = options.duration,
                duration = _options$duration === undefined ? 2 : _options$duration;


            this.setData(_extends({}, options, {
                type: type,
                duration: duration,
                visible: true
            }));

            var d = this.data.duration * 1000;

            if (timmer) clearTimeout(timmer);
            if (d !== 0) {
                timmer = setTimeout(function () {
                    _this.handleHide();
                    timmer = null;
                }, d);
            }
        },
        handleHide: function handleHide() {
            this.setData(_extends({}, default_data));
        }
    }
});
});
define("static/iview/modal/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class', 'i-class-mask'],

    properties: {
        visible: {
            type: Boolean,
            value: false
        },
        title: {
            type: String,
            value: ''
        },
        showOk: {
            type: Boolean,
            value: true
        },
        showCancel: {
            type: Boolean,
            value: true
        },
        okText: {
            type: String,
            value: '确定'
        },
        cancelText: {
            type: String,
            value: '取消'
        },
        // 按钮组，有此值时，不显示 ok 和 cancel 按钮
        actions: {
            type: Array,
            value: []
        },
        // horizontal || vertical
        actionMode: {
            type: String,
            value: 'horizontal'
        }
    },

    methods: {
        handleClickItem: function handleClickItem(_ref) {
            var _ref$currentTarget = _ref.currentTarget,
                currentTarget = _ref$currentTarget === undefined ? {} : _ref$currentTarget;

            var dataset = currentTarget.dataset || {};
            var index = dataset.index;

            this.triggerEvent('click', { index: index });
        },
        handleClickOk: function handleClickOk() {
            this.triggerEvent('ok');
        },
        handleClickCancel: function handleClickCancel() {
            this.triggerEvent('cancel');
        }
    }
});
});
define("static/iview/notice-bar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var VALID_MODE = ['closeable'];
var FONT_COLOR = '#f60';
var BG_COLOR = '#fff7cc';

Component({
    externalClasses: ['i-class'],

    properties: {
        closable: {
            type: Boolean,
            value: false
        },
        icon: {
            type: String,
            value: ''
        },
        loop: {
            type: Boolean,
            value: false
        },
        // 背景颜色
        backgroundcolor: {
            type: String,
            value: '#fefcec'
        },
        // 字体及图标颜色
        color: {
            type: String,
            value: '#f76a24'
        },
        // 滚动速度
        speed: {
            type: Number,
            value: 1000
        }
    },

    data: {
        show: true,
        wrapWidth: 0,
        width: 0,
        duration: 0,
        animation: null,
        timer: null
    },
    detached: function detached() {
        this.destroyTimer();
    },
    ready: function ready() {
        if (this.data.loop) {
            this.initAnimation();
        }
    },


    methods: {
        initAnimation: function initAnimation() {
            var _this = this;

            wx.createSelectorQuery().in(this).select('.i-noticebar-content-wrap').boundingClientRect(function (wrapRect) {
                wx.createSelectorQuery().in(_this).select('.i-noticebar-content').boundingClientRect(function (rect) {
                    var duration = rect.width / 40 * _this.data.speed;
                    var animation = wx.createAnimation({
                        duration: duration,
                        timingFunction: "linear"
                    });
                    _this.setData({
                        wrapWidth: wrapRect.width,
                        width: rect.width,
                        duration: duration,
                        animation: animation
                    }, function () {
                        _this.startAnimation();
                    });
                }).exec();
            }).exec();
        },
        startAnimation: function startAnimation() {
            var _this2 = this;

            //reset
            if (this.data.animation.option.transition.duration !== 0) {
                this.data.animation.option.transition.duration = 0;
                var resetAnimation = this.data.animation.translateX(this.data.wrapWidth).step();
                this.setData({
                    animationData: resetAnimation.export()
                });
            }
            this.data.animation.option.transition.duration = this.data.duration;
            var animationData = this.data.animation.translateX(-this.data.width).step();
            setTimeout(function () {
                _this2.setData({
                    animationData: animationData.export()
                });
            }, 100);
            var timer = setTimeout(function () {
                _this2.startAnimation();
            }, this.data.duration);
            this.setData({
                timer: timer
            });
        },
        destroyTimer: function destroyTimer() {
            if (this.data.timer) {
                clearTimeout(this.data.timer);
            }
        },
        handleClose: function handleClose() {
            this.destroyTimer();
            this.setData({
                show: false,
                timer: null
            });
        }
    }
});
});
define("static/iview/page/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    options: {
        multipleSlots: true
    },

    properties: {
        // button || number || pointer
        mode: {
            type: String,
            value: 'button'
        },
        current: {
            type: Number,
            value: 1
        },
        total: {
            type: Number,
            value: 0
        },
        // 是否隐藏数值
        simple: {
            type: Boolean,
            value: false
        }
    },

    methods: {
        handleChange: function handleChange(type) {
            this.triggerEvent('change', {
                type: type
            });
        },
        handlePrev: function handlePrev() {
            this.handleChange('prev');
        },
        handleNext: function handleNext() {
            this.handleChange('next');
        }
    }
});
});
define("static/iview/panel/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        title: {
            type: String,
            value: ''
        },
        // 标题顶部距离
        hideTop: {
            type: Boolean,
            value: false
        },
        hideBorder: {
            type: Boolean,
            value: false
        }
    }
});
});
define("static/iview/progress/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        percent: {
            type: Number,
            value: 0
        },
        // normal || active || wrong || success
        status: {
            type: String,
            value: 'normal'
        },
        strokeWidth: {
            type: Number,
            value: 10
        },
        hideInfo: {
            type: Boolean,
            value: false
        }
    }
});
});
define("static/iview/radio-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    relations: {
        '../radio/index': {
            type: 'child',
            linked: function linked() {
                this.changeCurrent();
            },
            linkChanged: function linkChanged() {
                this.changeCurrent();
            },
            unlinked: function unlinked() {
                this.changeCurrent();
            }
        }
    },
    properties: {
        current: {
            type: String,
            value: '',
            observer: 'changeCurrent'
        }
    },
    methods: {
        changeCurrent: function changeCurrent() {
            var val = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.current;

            var items = this.getRelationNodes('../radio/index');
            var len = items.length;
            if (len > 0) {
                items.forEach(function (item) {
                    item.changeCurrent(val === item.data.value);
                });
            }
        },
        emitEvent: function emitEvent(current) {
            this.triggerEvent('change', current);
        }
    }
});
});
define("static/iview/radio/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var prefixCls = 'i-radio';

Component({
    externalClasses: ['i-class'],
    relations: {
        '../radio-group/index': {
            type: 'parent'
        }
    },
    properties: {
        value: {
            type: String,
            value: ''
        },
        checked: {
            type: Boolean,
            value: false
        },
        disabled: {
            type: Boolean,
            value: false
        },
        color: {
            type: String,
            value: '#2d8cf0'
        },
        position: {
            type: String,
            value: 'left', //left right
            observer: 'setPosition'
        }
    },
    data: {
        checked: true,
        positionCls: prefixCls + '-radio-left'
    },
    attached: function attached() {
        this.setPosition();
    },

    methods: {
        changeCurrent: function changeCurrent(current) {
            this.setData({ checked: current });
        },
        radioChange: function radioChange() {
            if (this.data.disabled) return;
            var item = { current: !this.data.checked, value: this.data.value };
            var parent = this.getRelationNodes('../radio-group/index')[0];
            parent ? parent.emitEvent(item) : this.triggerEvent('change', item);
        },
        setPosition: function setPosition() {
            this.setData({
                positionCls: this.data.position.indexOf('left') !== -1 ? prefixCls + '-radio-left' : prefixCls + '-radio-right'
            });
        }
    }
});
});
define("static/iview/rate/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        count: {
            type: Number,
            value: 5
        },
        value: {
            type: Number,
            value: 0
        },
        disabled: {
            type: Boolean,
            value: false
        },
        size: {
            type: Number,
            value: 20
        },
        name: {
            type: String,
            value: ''
        }
    },
    data: {
        touchesStart: {
            pageX: 0
        }
    },
    methods: {
        handleClick: function handleClick(e) {
            var data = this.data;
            if (data.disabled) {
                return;
            }
            var index = e.currentTarget.dataset.index;
            this.triggerEvent('change', {
                index: index + 1
            });
        },
        handleTouchMove: function handleTouchMove(e) {
            var data = this.data;
            if (data.disabled) {
                return;
            }
            if (!e.changedTouches[0]) {
                return;
            }
            var movePageX = e.changedTouches[0].pageX;
            var space = movePageX - data.touchesStart.pageX;

            if (space <= 0) {
                return;
            }
            var setIndex = Math.ceil(space / data.size);
            setIndex = setIndex > data.count ? data.count : setIndex;
            this.triggerEvent('change', {
                index: setIndex
            });
        }
    },
    ready: function ready() {
        var _this = this;

        var className = '.i-rate';
        var query = wx.createSelectorQuery().in(this);
        query.select(className).boundingClientRect(function (res) {
            _this.data.touchesStart.pageX = res.left || 0;
        }).exec();
    }
});
});
define("static/iview/row/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../col/index': {
            type: 'child'
        }
    }
});
});
define("static/iview/slide/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    options: {
        // 在组件定义时的选项中启用多slot支持
        multipleSlots: true
    },
    methods: {
        handleTap2: function handleTap2() {
            console.log(event, 1111111);
        },
        handleTap3: function handleTap3() {}
    }
});
});
define("static/iview/spin/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    properties: {
        // small || default || large
        size: {
            type: String,
            value: 'default'
        },
        fix: {
            type: Boolean,
            value: false
        },
        fullscreen: {
            type: Boolean,
            value: false
        },
        custom: {
            type: Boolean,
            value: false
        }
    }
});
});
define("static/iview/step/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        status: {
            type: String,
            //wait、process、finish、error
            value: ''
        },
        title: {
            type: String,
            value: ''
        },
        content: {
            type: String,
            value: ''
        },
        icon: {
            type: String,
            value: ''
        }
    },
    options: {
        // 在组件定义时的选项中启用多slot支持
        multipleSlots: true
    },
    relations: {
        '../steps/index': {
            type: 'parent'
        }
    },
    data: {
        //step length
        len: 1,
        //current in step index
        index: 0,
        //parent component select current index
        current: 0,
        //css direction
        direction: 'horizontal'
    },
    methods: {
        updateDataChange: function updateDataChange(options) {
            this.setData({
                len: options.len,
                index: options.index,
                current: options.current,
                direction: options.direction
            });
        }
    }

});
});
define("static/iview/steps/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        current: {
            type: Number,
            value: -1,
            observer: '_updateDataChange'
        },
        status: {
            type: String,
            //wait、process、finish、error
            value: ''
        },
        direction: {
            type: String,
            //value has horizontal or vertical 
            value: 'horizontal'
        }
    },
    relations: {
        '../step/index': {
            type: 'child',
            linked: function linked() {
                this._updateDataChange();
            },
            linkChanged: function linkChanged() {
                this._updateDataChange();
            },
            unlinked: function unlinked() {
                this._updateDataChange();
            }
        }
    },
    methods: {
        _updateDataChange: function _updateDataChange() {
            var _this = this;

            var steps = this.getRelationNodes('../step/index');
            var len = steps.length;
            if (len > 0) {
                steps.forEach(function (step, index) {
                    step.updateDataChange({
                        len: len,
                        index: index,
                        current: _this.data.current,
                        direction: _this.data.direction
                    });
                });
            }
        }
    }
});
});
define("static/iview/sticky-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    options: {
        multipleSlots: true
    },
    relations: {
        '../sticky/index': {
            type: 'parent'
        }
    },
    data: {
        top: 0,
        height: 0,
        isFixed: false,
        index: -1
    },
    methods: {
        updateScrollTopChange: function updateScrollTopChange(scrollTop) {
            var data = this.data;
            var top = data.top;
            var height = data.height;
            this.setData({
                isFixed: scrollTop >= top && scrollTop < top + height ? true : false
            });
        },
        updateDataChange: function updateDataChange(index) {
            var _this = this;

            var className = '.i-sticky-item';
            var query = wx.createSelectorQuery().in(this);
            query.select(className).boundingClientRect(function (res) {
                if (res) {
                    _this.setData({
                        top: res.top,
                        height: res.height,
                        index: index
                    });
                }
            }).exec();
        }
    }
});
});
define("static/iview/sticky/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        scrollTop: {
            type: Number,
            observer: function observer(val) {
                this._updateScrollTopChange();
            }
        }
    },
    relations: {
        '../sticky-item/index': {
            type: 'child',
            linked: function linked() {
                this._updateDataChange();
            },
            linkChanged: function linkChanged() {
                this._updateDataChange();
            },
            unlinked: function unlinked() {
                this._updateDataChange();
            }
        }
    },
    data: {
        timer: null,
        itemLength: 0
    },
    methods: {
        _updateScrollTopChange: function _updateScrollTopChange() {
            var _this = this;

            var stickies = this.getRelationNodes('../sticky-item/index');
            if (stickies.length > 0) {
                stickies.forEach(function (item) {
                    if (item) {
                        item.updateScrollTopChange(_this.data.scrollTop);
                    }
                });
            }
        },
        _updateDataChange: function _updateDataChange() {
            var stickies = this.getRelationNodes('../sticky-item/index');
            if (stickies.length > 0) {
                if (this.data.timer) {
                    clearTimeout(this.data.timer);
                    this.setData({
                        timer: null
                    });
                }
                this.data.timer = setTimeout(function () {
                    stickies.forEach(function (item, index) {
                        if (item) {
                            item.updateDataChange(index);
                        }
                    });
                }, 0);
                this.setData({
                    timer: this.data.timer
                });
            }
        }
    }

});
});
define("static/iview/swipeout/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/*
* touch事件判断方式
* https://github.com/madrobby/zepto/blob/master/src/touch.js#files
*/
function swipeDirection(x1, x2, y1, y2) {
    return Math.abs(x1 - x2) >= Math.abs(y1 - y2) ? x1 - x2 > 0 ? 'Left' : 'Right' : y1 - y2 > 0 ? 'Up' : 'Down';
}

Component({
    externalClasses: ['i-class'],
    properties: {
        actions: {
            value: [],
            type: Array,
            observer: '_updateButtonSize'
        },
        unclosable: {
            value: false,
            type: Boolean
        },
        toggle: {
            value: false,
            type: Boolean,
            observer: 'closeButtonGroup'
        },
        operateWidth: {
            type: Number,
            value: 160
        }
    },
    options: {
        // 在组件定义时的选项中启用多slot支持
        multipleSlots: true
    },
    data: {
        //touch start position
        tStart: {
            pageX: 0,
            pageY: 0
        },
        //限制滑动距离
        limitMove: 0,
        //element move position
        position: {
            pageX: 0,
            pageY: 0
        }
    },
    methods: {
        //阻止事件冒泡
        loop: function loop() {},
        _updateButtonSize: function _updateButtonSize() {
            var actions = this.data.actions;
            if (actions.length > 0) {
                var query = wx.createSelectorQuery().in(this);
                var limitMovePosition = 0;
                actions.forEach(function (item) {
                    limitMovePosition += item.width || 0;
                });
                this.data.limitMove = limitMovePosition;
                /*
                    * 动态获取每个传进值的按钮尺寸不能正确获取，在安卓上少了6px
                    * 暂时实现需要在actions里面传递宽度
                    * 需要后期调研
                */
                //query.selectAll('.i-swipeout-button-right-item').boundingClientRect((rects)=>{
                //     if( rects ){
                //         console.log(rects,1111111)
                //         rects.forEach(item => {
                //             limitMovePosition += item.width;
                //         });
                //         this.data.limitMove = limitMovePosition;
                //         console.log(limitMovePosition,111111111)
                //     }
                // }).exec()
            } else {
                this.data.limitMove = this.data.operateWidth;
            }
        },
        handlerTouchstart: function handlerTouchstart(event) {
            var touches = event.touches ? event.touches[0] : {};
            var tStart = this.data.tStart;
            if (touches) {
                for (var i in tStart) {
                    if (touches[i]) {
                        tStart[i] = touches[i];
                    }
                }
            }
        },
        swipper: function swipper(touches) {
            var data = this.data;
            var start = data.tStart;
            var spacing = {
                pageX: touches.pageX - start.pageX,
                pageY: touches.pageY - start.pageY
            };
            if (data.limitMove < Math.abs(spacing.pageX)) {
                spacing.pageX = -data.limitMove;
            }
            this.setData({
                'position': spacing
            });
        },
        handlerTouchmove: function handlerTouchmove(event) {
            var start = this.data.tStart;
            var touches = event.touches ? event.touches[0] : {};
            if (touches) {
                var direction = swipeDirection(start.pageX, touches.pageX, start.pageY, touches.pageY);
                if (direction === 'Left') {
                    this.swipper(touches);
                }
            }
        },
        handlerTouchend: function handlerTouchend(event) {
            var start = this.data.tStart;
            var touches = event.changedTouches ? event.changedTouches[0] : {};
            if (touches) {
                var direction = swipeDirection(start.pageX, touches.pageX, start.pageY, touches.pageY);
                var spacing = {
                    pageX: touches.pageX - start.pageX,
                    pageY: touches.pageY - start.pageY
                };
                if (Math.abs(spacing.pageX) >= 40 && direction === "Left") {
                    spacing.pageX = spacing.pageX < 0 ? -this.data.limitMove : this.data.limitMove;
                } else {
                    spacing.pageX = 0;
                }
                this.setData({
                    'position': spacing
                });
            }
        },
        handlerButton: function handlerButton(event) {
            if (!this.data.unclosable) {
                this.closeButtonGroup();
            }
            var dataset = event.currentTarget.dataset;
            this.triggerEvent('change', {
                index: dataset.index
            });
        },
        closeButtonGroup: function closeButtonGroup() {
            this.setData({
                'position': { pageX: 0, pageY: 0 }
            });
        },

        //控制自定义组件
        handlerParentButton: function handlerParentButton(event) {
            if (!this.data.unclosable) {
                this.closeButtonGroup();
            }
        }
    },
    ready: function ready() {
        this._updateButtonSize();
    }
});
});
define("static/iview/switch/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        value: {
            type: Boolean,
            value: false
        },
        //large small default
        size: {
            type: String,
            value: 'default'
        },
        // is or not disable
        disabled: {
            type: Boolean,
            value: false
        },
        // hidden inut name
        name: {
            type: String,
            value: ''
        }
    },
    options: {
        // 在组件定义时的选项中启用多slot支持
        multipleSlots: true
    },
    methods: {
        toggle: function toggle() {
            if (this.data.disabled) return;
            var data = this.data;
            var value = data.value ? false : true;
            this.triggerEvent('change', {
                value: value
            });
        }
    }
});
});
define("static/iview/tab-bar-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../tab-bar/index': {
            type: 'parent'
        }
    },

    properties: {
        icon: {
            type: String,
            value: ''
        },
        currentIcon: {
            type: String,
            value: ''
        },
        img: {
            type: String,
            value: ''
        },
        currentImg: {
            type: String,
            value: ''
        },
        key: {
            type: String,
            value: ''
        },
        title: {
            type: String,
            value: ''
        },
        dot: {
            type: Boolean,
            value: false
        },
        count: {
            type: Number,
            value: 0
        }
    },

    data: {
        current: false,
        currentColor: ''
    },

    methods: {
        changeCurrent: function changeCurrent(current) {
            this.setData({ current: current });
        },
        changeCurrentColor: function changeCurrentColor(currentColor) {
            this.setData({ currentColor: currentColor });
        },
        handleClickItem: function handleClickItem() {
            var parent = this.getRelationNodes('../tab-bar/index')[0];
            parent.emitEvent(this.data.key);
        }
    }
});
});
define("static/iview/tab-bar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../tab-bar-item/index': {
            type: 'child',
            linked: function linked() {
                this.changeCurrent();
            },
            linkChanged: function linkChanged() {
                this.changeCurrent();
            },
            unlinked: function unlinked() {
                this.changeCurrent();
            }
        }
    },

    properties: {
        current: {
            type: String,
            value: '',
            observer: 'changeCurrent'
        },
        color: {
            type: String,
            value: ''
        },
        fixed: {
            type: Boolean,
            value: false
        }
    },

    data: {
        list: []
    },

    methods: {
        changeCurrent: function changeCurrent() {
            var _this = this;

            var val = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.current;

            var items = this.getRelationNodes('../tab-bar-item/index');
            var len = items.length;

            if (len > 0) {
                var list = [];
                items.forEach(function (item) {
                    item.changeCurrent(item.data.key === val);
                    item.changeCurrentColor(_this.data.color);
                    list.push({
                        key: item.data.key
                    });
                });
                this.setData({
                    list: list
                });
            }
        },
        emitEvent: function emitEvent(key) {
            this.triggerEvent('change', { key: key });
        },
        handleClickItem: function handleClickItem(e) {
            var key = e.currentTarget.dataset.key;
            this.emitEvent(key);
        }
    }
});
});
define("static/iview/tab/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../tabs/index': {
            type: 'parent'
        }
    },

    properties: {
        key: {
            type: String,
            value: ''
        },
        title: {
            type: String,
            value: ''
        },
        dot: {
            type: Boolean,
            value: false
        },
        count: {
            type: Number,
            value: 0
        }
    },

    data: {
        current: false,
        currentColor: '',
        scroll: false
    },

    methods: {
        changeCurrent: function changeCurrent(current) {
            this.setData({ current: current });
        },
        changeCurrentColor: function changeCurrentColor(currentColor) {
            this.setData({ currentColor: currentColor });
        },
        changeScroll: function changeScroll(scroll) {
            this.setData({ scroll: scroll });
        },
        handleClickItem: function handleClickItem() {
            var parent = this.getRelationNodes('../tabs/index')[0];
            parent.emitEvent(this.data.key);
        }
    }
});
});
define("static/iview/tabs/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],

    relations: {
        '../tab/index': {
            type: 'child',
            linked: function linked() {
                this.changeCurrent();
            },
            linkChanged: function linkChanged() {
                this.changeCurrent();
            },
            unlinked: function unlinked() {
                this.changeCurrent();
            }
        }
    },

    properties: {
        current: {
            type: String,
            value: '',
            observer: 'changeCurrent'
        },
        color: {
            type: String,
            value: ''
        },
        scroll: {
            type: Boolean,
            value: false
        },
        fixed: {
            type: Boolean,
            value: false
        }
    },

    methods: {
        changeCurrent: function changeCurrent() {
            var _this = this;

            var val = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.current;

            var items = this.getRelationNodes('../tab/index');
            var len = items.length;

            if (len > 0) {
                items.forEach(function (item) {
                    item.changeScroll(_this.data.scroll);
                    item.changeCurrent(item.data.key === val);
                    item.changeCurrentColor(_this.data.color);
                });
            }
        },
        emitEvent: function emitEvent(key) {
            this.triggerEvent('change', { key: key });
        }
    }
});
});
define("static/iview/tag/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Component({
    externalClasses: ['i-class'],
    properties: {
        //slot name
        name: {
            type: String,
            value: ''
        },
        //can click or not click
        checkable: {
            type: Boolean,
            value: false
        },
        //is current choose
        checked: {
            type: Boolean,
            value: true
        },
        //background and color setting
        color: {
            type: String,
            value: 'default'
        },
        //control fill or not
        type: {
            type: String,
            value: 'dot'
        }
    },
    methods: {
        tapTag: function tapTag() {
            var data = this.data;
            if (data.checkable) {
                var checked = data.checked ? false : true;
                this.triggerEvent('change', {
                    name: data.name || '',
                    checked: checked
                });
            }
        }
    }
});
});
define("static/iview/toast/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var default_data = {
    visible: false,
    content: '',
    icon: '',
    image: '',
    duration: 2,
    mask: true,
    type: 'default' // default || success || warning || error || loading
};

var timmer = null;

Component({
    externalClasses: ['i-class'],

    data: _extends({}, default_data),

    methods: {
        handleShow: function handleShow(options) {
            var _this = this;

            var _options$type = options.type,
                type = _options$type === undefined ? 'default' : _options$type,
                _options$duration = options.duration,
                duration = _options$duration === undefined ? 2 : _options$duration;


            this.setData(_extends({}, options, {
                type: type,
                duration: duration,
                visible: true
            }));

            var d = this.data.duration * 1000;

            if (timmer) clearTimeout(timmer);
            if (d !== 0) {
                timmer = setTimeout(function () {
                    _this.handleHide();
                    timmer = null;
                }, d);
            }
        },
        handleHide: function handleHide() {
            this.setData(_extends({}, default_data));
        }
    }
});
});
define("static/vant/action-sheet/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _iphonex = require('../mixins/iphonex');

(0, _component.VantComponent)({
  mixins: [_iphonex.iphonex],
  props: {
    show: Boolean,
    title: String,
    cancelText: String,
    zIndex: {
      type: Number,
      value: 100
    },
    actions: {
      type: Array,
      value: []
    },
    overlay: {
      type: Boolean,
      value: true
    },
    closeOnClickOverlay: {
      type: Boolean,
      value: true
    }
  },
  methods: {
    onSelect: function onSelect(event) {
      var index = event.currentTarget.dataset.index;
      var item = this.data.actions[index];

      if (item && !item.disabled && !item.loading) {
        this.$emit('select', item);
      }
    },
    onCancel: function onCancel() {
      this.$emit('cancel');
    },
    onClose: function onClose() {
      this.$emit('close');
    }
  }
});
});
define("static/vant/area/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['active-class', 'toolbar-class', 'column-class'],
  props: {
    title: String,
    value: String,
    loading: Boolean,
    itemHeight: {
      type: Number,
      value: 44
    },
    visibleItemCount: {
      type: Number,
      value: 5
    },
    columnsNum: {
      type: [String, Number],
      value: 3
    },
    areaList: {
      type: Object,
      value: {}
    }
  },
  data: {
    columns: [{
      values: []
    }, {
      values: []
    }, {
      values: []
    }],
    displayColumns: [{
      values: []
    }, {
      values: []
    }, {
      values: []
    }]
  },
  watch: {
    value: function value(_value) {
      this.code = _value;
      this.setValues();
    },
    areaList: 'setValues',
    columnsNum: function columnsNum(value) {
      this.set({
        displayColumns: this.data.columns.slice(0, +value)
      });
    }
  },
  methods: {
    getPicker: function getPicker() {
      if (this.picker == null) {
        this.picker = this.selectComponent('.van-area__picker');
      }

      return this.picker;
    },
    onCancel: function onCancel(event) {
      this.emit('cancel', event.detail);
    },
    onConfirm: function onConfirm(event) {
      this.emit('confirm', event.detail);
    },
    emit: function emit(type, detail) {
      detail.values = detail.value;
      delete detail.value;
      this.$emit(type, detail);
    },
    onChange: function onChange(event) {
      var _this = this;

      var _event$detail = event.detail,
          index = _event$detail.index,
          picker = _event$detail.picker,
          value = _event$detail.value;
      this.code = value[index].code;
      this.setValues().then(function () {
        _this.$emit('change', {
          picker: picker,
          values: picker.getValues(),
          index: index
        });
      });
    },
    getConfig: function getConfig(type) {
      var areaList = this.data.areaList;
      return areaList && areaList[type + "_list"] || {};
    },
    getList: function getList(type, code) {
      var result = [];

      if (type !== 'province' && !code) {
        return result;
      }

      var list = this.getConfig(type);
      result = Object.keys(list).map(function (code) {
        return {
          code: code,
          name: list[code]
        };
      });

      if (code) {
        // oversea code
        if (code[0] === '9' && type === 'city') {
          code = '9';
        }

        result = result.filter(function (item) {
          return item.code.indexOf(code) === 0;
        });
      }

      return result;
    },
    getIndex: function getIndex(type, code) {
      var compareNum = type === 'province' ? 2 : type === 'city' ? 4 : 6;
      var list = this.getList(type, code.slice(0, compareNum - 2)); // oversea code

      if (code[0] === '9' && type === 'province') {
        compareNum = 1;
      }

      code = code.slice(0, compareNum);

      for (var i = 0; i < list.length; i++) {
        if (list[i].code.slice(0, compareNum) === code) {
          return i;
        }
      }

      return 0;
    },
    setValues: function setValues() {
      var _this2 = this;

      var county = this.getConfig('county');
      var code = this.code || Object.keys(county)[0] || '';
      var province = this.getList('province');
      var city = this.getList('city', code.slice(0, 2));
      var picker = this.getPicker();

      if (!picker) {
        return;
      }

      var stack = [];
      stack.push(picker.setColumnValues(0, province));
      stack.push(picker.setColumnValues(1, city));

      if (city.length && code.slice(2, 4) === '00') {
        ;
        code = city[0].code;
      }

      stack.push(picker.setColumnValues(2, this.getList('county', code.slice(0, 4))));
      return Promise.all(stack).then(function () {
        return picker.setIndexes([_this2.getIndex('province', code), _this2.getIndex('city', code), _this2.getIndex('county', code)]);
      }).catch(function () {});
    },
    getValues: function getValues() {
      var picker = this.getPicker();
      return picker ? picker.getValues().filter(function (value) {
        return !!value;
      }) : [];
    },
    getDetail: function getDetail() {
      var values = this.getValues();
      var area = {
        code: '',
        country: '',
        province: '',
        city: '',
        county: ''
      };

      if (!values.length) {
        return area;
      }

      var names = values.map(function (item) {
        return item.name;
      });
      area.code = values[values.length - 1].code;

      if (area.code[0] === '9') {
        area.country = names[1] || '';
        area.province = names[2] || '';
      } else {
        area.province = names[0] || '';
        area.city = names[1] || '';
        area.county = names[2] || '';
      }

      return area;
    },
    reset: function reset() {
      this.code = '';
      return this.setValues();
    }
  }
});
});
define("static/vant/badge-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _utils = require('../common/utils');

(0, _component.VantComponent)({
  relation: {
    name: 'badge',
    type: 'descendant',
    linked: function linked(target) {
      this.badges.push(target);
      this.setActive();
    },
    unlinked: function unlinked(target) {
      this.badges = this.badges.filter(function (item) {
        return item !== target;
      });
      this.setActive();
    }
  },
  props: {
    active: {
      type: Number,
      value: 0
    }
  },
  watch: {
    active: 'setActive'
  },
  beforeCreate: function beforeCreate() {
    this.badges = [];
    this.currentActive = -1;
  },
  methods: {
    setActive: function setActive(badge) {
      var active = this.data.active;
      var badges = this.badges;

      if (badge && !(0, _utils.isNumber)(badge)) {
        active = badges.indexOf(badge);
      }

      if (active === this.currentActive) {
        return;
      }

      if (this.currentActive !== -1 && badges[this.currentActive]) {
        this.$emit('change', active);
        badges[this.currentActive].setActive(false);
      }

      if (badges[active]) {
        badges[active].setActive(true);
        this.currentActive = active;
      }
    }
  }
});
});
define("static/vant/badge/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  relation: {
    type: 'ancestor',
    name: 'badge-group'
  },
  props: {
    info: null,
    title: String
  },
  methods: {
    onClick: function onClick() {
      var group = this.getRelationNodes('../badge-group/index')[0];

      if (group) {
        group.setActive(this);
      }
    },
    setActive: function setActive(active) {
      this.set({
        active: active
      });
    }
  }
});
});
define("static/vant/button/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _button = require('../mixins/button');

var _openType = require('../mixins/open-type');

(0, _component.VantComponent)({
  mixins: [_button.button, _openType.openType],
  classes: ['hover-class', 'loading-class'],
  props: {
    plain: Boolean,
    block: Boolean,
    round: Boolean,
    square: Boolean,
    loading: Boolean,
    disabled: Boolean,
    type: {
      type: String,
      value: 'default'
    },
    size: {
      type: String,
      value: 'normal'
    }
  },
  methods: {
    onClick: function onClick() {
      if (!this.data.disabled && !this.data.loading) {
        this.$emit('click');
      }
    }
  }
});
});
define("static/vant/card/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _link = require('../mixins/link');

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['num-class', 'desc-class', 'thumb-class', 'title-class', 'price-class', 'origin-price-class'],
  mixins: [_link.link],
  props: {
    tag: String,
    num: String,
    desc: String,
    thumb: String,
    title: String,
    price: String,
    centered: Boolean,
    lazyLoad: Boolean,
    thumbLink: String,
    originPrice: String,
    thumbMode: {
      type: String,
      value: 'aspectFit'
    },
    currency: {
      type: String,
      value: '¥'
    }
  },
  methods: {
    onClickThumb: function onClickThumb() {
      this.jumpLink('thumbLink');
    }
  }
});
});
define("static/vant/cell-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    border: {
      type: Boolean,
      value: true
    }
  }
});
});
define("static/vant/cell/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _link = require('../mixins/link');

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['title-class', 'label-class', 'value-class', 'right-icon-class', 'hover-class'],
  mixins: [_link.link],
  props: {
    title: null,
    value: null,
    icon: String,
    size: String,
    label: String,
    center: Boolean,
    isLink: Boolean,
    required: Boolean,
    clickable: Boolean,
    titleWidth: String,
    customStyle: String,
    arrowDirection: String,
    border: {
      type: Boolean,
      value: true
    }
  },
  methods: {
    onClick: function onClick(event) {
      this.$emit('click', event.detail);
      this.jumpLink();
    }
  }
});
});
define("static/vant/checkbox-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  relation: {
    name: 'checkbox',
    type: 'descendant',
    linked: function linked(target) {
      var _this$data = this.data,
          value = _this$data.value,
          disabled = _this$data.disabled;
      target.set({
        value: value.indexOf(target.data.name) !== -1,
        disabled: disabled || target.data.disabled
      });
    }
  },
  props: {
    max: Number,
    value: Array,
    disabled: Boolean
  },
  watch: {
    value: function value(_value) {
      var children = this.getRelationNodes('../checkbox/index');
      children.forEach(function (child) {
        child.set({
          value: _value.indexOf(child.data.name) !== -1
        });
      });
    },
    disabled: function disabled(_disabled) {
      var children = this.getRelationNodes('../checkbox/index');
      children.forEach(function (child) {
        child.set({
          disabled: _disabled || child.data.disabled
        });
      });
    }
  }
});
});
define("static/vant/checkbox/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  relation: {
    name: 'checkbox-group',
    type: 'ancestor'
  },
  classes: ['icon-class', 'label-class'],
  props: {
    value: null,
    disabled: Boolean,
    useIconSlot: Boolean,
    checkedColor: String,
    labelPosition: String,
    labelDisabled: Boolean,
    shape: {
      type: String,
      value: 'round'
    }
  },
  methods: {
    emitChange: function emitChange(value) {
      var parent = this.getRelationNodes('../checkbox-group/index')[0];

      if (parent) {
        this.setParentValue(parent, value);
      } else {
        this.$emit('input', value);
        this.$emit('change', value);
      }
    },
    toggle: function toggle() {
      if (!this.data.disabled) {
        this.emitChange(!this.data.value);
      }
    },
    onClickLabel: function onClickLabel() {
      if (!this.data.disabled && !this.data.labelDisabled) {
        this.emitChange(!this.data.value);
      }
    },
    setParentValue: function setParentValue(parent, value) {
      var parentValue = parent.data.value.slice();
      var name = this.data.name;

      if (value) {
        if (parent.data.max && parentValue.length >= parent.data.max) {
          return;
        }
        /* istanbul ignore else */

        if (parentValue.indexOf(name) === -1) {
          parentValue.push(name);
          parent.$emit('input', parentValue);
          parent.$emit('change', parentValue);
        }
      } else {
        var index = parentValue.indexOf(name);
        /* istanbul ignore else */

        if (index !== -1) {
          parentValue.splice(index, 1);
          parent.$emit('input', parentValue);
          parent.$emit('change', parentValue);
        }
      }
    }
  }
});
});
define("static/vant/col/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  relation: {
    name: 'row',
    type: 'ancestor'
  },
  props: {
    span: Number,
    offset: Number
  },
  data: {
    style: ''
  },
  methods: {
    setGutter: function setGutter(gutter) {
      var padding = gutter / 2 + "px";
      var style = gutter ? "padding-left: " + padding + "; padding-right: " + padding + ";" : '';

      if (style !== this.data.style) {
        this.set({
          style: style
        });
      }
    }
  }
});
});
define("static/vant/collapse-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['title-class', 'content-class'],
  relation: {
    name: 'collapse',
    type: 'ancestor',
    linked: function linked(parent) {
      this.parent = parent;
    }
  },
  props: {
    name: null,
    title: null,
    value: null,
    icon: String,
    label: String,
    disabled: Boolean,
    border: {
      type: Boolean,
      value: true
    },
    isLink: {
      type: Boolean,
      value: true
    }
  },
  data: {
    contentHeight: 0,
    expanded: false
  },
  beforeCreate: function beforeCreate() {
    this.animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'ease-in-out'
    });
  },
  methods: {
    updateExpanded: function updateExpanded() {
      if (!this.parent) {
        return null;
      }

      var _this$parent$data = this.parent.data,
          value = _this$parent$data.value,
          accordion = _this$parent$data.accordion,
          items = _this$parent$data.items;
      var name = this.data.name;
      var index = items.indexOf(this);
      var currentName = name == null ? index : name;
      var expanded = accordion ? value === currentName : value.some(function (name) {
        return name === currentName;
      });

      if (expanded !== this.data.expanded) {
        this.updateStyle(expanded);
      }

      this.set({
        expanded: expanded
      });
    },
    updateStyle: function updateStyle(expanded) {
      var _this = this;

      this.getRect('.van-collapse-item__content').then(function (res) {
        var animationData = _this.animation.height(expanded ? res.height : 0).step().export();

        if (expanded) {
          _this.set({
            animationData: animationData
          });
        } else {
          _this.set({
            contentHeight: res.height + 'px'
          }, function () {
            setTimeout(function () {
              _this.set({
                animationData: animationData
              });
            }, 20);
          });
        }
      });
    },
    onClick: function onClick() {
      if (this.data.disabled) {
        return;
      }

      var _this$data = this.data,
          name = _this$data.name,
          expanded = _this$data.expanded;
      var index = this.parent.data.items.indexOf(this);
      var currentName = name == null ? index : name;
      this.parent.switch(currentName, !expanded);
    },
    onTransitionEnd: function onTransitionEnd() {
      if (this.data.expanded) {
        this.set({
          contentHeight: 'auto'
        });
      }
    }
  }
});
});
define("static/vant/collapse/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  relation: {
    name: 'collapse-item',
    type: 'descendant',
    linked: function linked(child) {
      this.set({
        items: [].concat(this.data.items, [child])
      }, function () {
        child.updateExpanded();
      });
    }
  },
  props: {
    accordion: Boolean,
    value: null
  },
  data: {
    items: []
  },
  watch: {
    value: function value() {
      this.data.items.forEach(function (child) {
        child.updateExpanded();
      });
    },
    accordion: function accordion() {
      this.data.items.forEach(function (child) {
        child.updateExpanded();
      });
    }
  },
  methods: {
    switch: function _switch(name, expanded) {
      var _this$data = this.data,
          accordion = _this$data.accordion,
          value = _this$data.value;

      if (!accordion) {
        name = expanded ? value.concat(name) : value.filter(function (activeName) {
          return activeName !== name;
        });
      } else {
        name = expanded ? name : '';
      }

      this.$emit('change', name);
      this.$emit('input', name);
    }
  }
});
});
define("static/vant/common/color.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var RED = exports.RED = '#f44';
var BLUE = exports.BLUE = '#1989fa';
var GREEN = exports.GREEN = '#07c160';
});
define("static/vant/common/component.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.VantComponent = undefined;

var _basic = require('../mixins/basic');

var _index = require('../mixins/observer/index');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function mapKeys(source, target, map) {
  Object.keys(map).forEach(function (key) {
    if (source[key]) {
      target[map[key]] = source[key];
    }
  });
}

function VantComponent(vantOptions) {
  if (vantOptions === void 0) {
    vantOptions = {};
  }

  var options = {};
  mapKeys(vantOptions, options, {
    data: 'data',
    props: 'properties',
    mixins: 'behaviors',
    methods: 'methods',
    beforeCreate: 'created',
    created: 'attached',
    mounted: 'ready',
    relations: 'relations',
    destroyed: 'detached',
    classes: 'externalClasses'
  });
  var _vantOptions = vantOptions,
      relation = _vantOptions.relation;

  if (relation) {
    options.relations = Object.assign(options.relations || {}, _defineProperty({}, "../" + relation.name + "/index", relation));
  } // add default externalClasses


  options.externalClasses = options.externalClasses || [];
  options.externalClasses.push('custom-class'); // add default behaviors

  options.behaviors = options.behaviors || [];
  options.behaviors.push(_basic.basic); // map field to form-field behavior

  if (vantOptions.field) {
    options.behaviors.push('wx://form-field');
  } // add default options


  options.options = {
    multipleSlots: true,
    addGlobalClass: true
  };
  (0, _index.observe)(vantOptions, options);
  Component(options);
}

exports.VantComponent = VantComponent;
});
define("static/vant/common/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function isDef(value) {
  return value !== undefined && value !== null;
}

function isObj(x) {
  var type = typeof x === 'undefined' ? 'undefined' : _typeof(x);
  return x !== null && (type === 'object' || type === 'function');
}

function isNumber(value) {
  return (/^\d+$/.test(value)
  );
}

function range(num, min, max) {
  return Math.min(Math.max(num, min), max);
}

exports.isObj = isObj;
exports.isDef = isDef;
exports.isNumber = isNumber;
exports.range = range;
});
define("static/vant/datetime-picker/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _utils = require('../common/utils');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var currentYear = new Date().getFullYear();

function isValidDate(date) {
  return (0, _utils.isDef)(date) && !isNaN(new Date(date).getTime());
}

function range(num, min, max) {
  return Math.min(Math.max(num, min), max);
}

function padZero(val) {
  return ("00" + val).slice(-2);
}

function times(n, iteratee) {
  var index = -1;
  var result = Array(n);

  while (++index < n) {
    result[index] = iteratee(index);
  }

  return result;
}

function getTrueValue(formattedValue) {
  if (!formattedValue) return;

  while (isNaN(parseInt(formattedValue, 10))) {
    formattedValue = formattedValue.slice(1);
  }

  return parseInt(formattedValue, 10);
}

function getMonthEndDay(year, month) {
  return 32 - new Date(year, month - 1, 32).getDate();
}

(0, _component.VantComponent)({
  props: {
    value: null,
    title: String,
    loading: Boolean,
    itemHeight: {
      type: Number,
      value: 44
    },
    visibleItemCount: {
      type: Number,
      value: 5
    },
    confirmButtonText: {
      type: String,
      value: '确认'
    },
    cancelButtonText: {
      type: String,
      value: '取消'
    },
    type: {
      type: String,
      value: 'datetime'
    },
    showToolbar: {
      type: Boolean,
      value: true
    },
    minDate: {
      type: Number,
      value: new Date(currentYear - 10, 0, 1).getTime()
    },
    maxDate: {
      type: Number,
      value: new Date(currentYear + 10, 11, 31).getTime()
    },
    minHour: {
      type: Number,
      value: 0
    },
    maxHour: {
      type: Number,
      value: 23
    },
    minMinute: {
      type: Number,
      value: 0
    },
    maxMinute: {
      type: Number,
      value: 59
    }
  },
  data: {
    innerValue: Date.now(),
    columns: []
  },
  watch: {
    value: function value(val) {
      var _this = this;

      var data = this.data;
      val = this.correctValue(val);
      var isEqual = val === data.innerValue;

      if (!isEqual) {
        this.updateColumnValue(val).then(function () {
          _this.$emit('input', val);
        });
      }
    },
    type: 'updateColumns',
    minHour: 'updateColumns',
    maxHour: 'updateColumns',
    minMinute: 'updateColumns',
    maxMinute: 'updateColumns'
  },
  methods: {
    getPicker: function getPicker() {
      if (this.picker == null) {
        var picker = this.picker = this.selectComponent('.van-datetime-picker');
        var setColumnValues = picker.setColumnValues;

        picker.setColumnValues = function () {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          return setColumnValues.apply(picker, [].concat(args, [false]));
        };
      }

      return this.picker;
    },
    updateColumns: function updateColumns() {
      var results = this.getRanges().map(function (_ref, index) {
        var type = _ref.type,
            range = _ref.range;
        var values = times(range[1] - range[0] + 1, function (index) {
          var value = range[0] + index;
          value = type === 'year' ? "" + value : padZero(value);
          return value;
        });
        return {
          values: values
        };
      });
      return this.set({
        columns: results
      });
    },
    getRanges: function getRanges() {
      var data = this.data;

      if (data.type === 'time') {
        return [{
          type: 'hour',
          range: [data.minHour, data.maxHour]
        }, {
          type: 'minute',
          range: [data.minMinute, data.maxMinute]
        }];
      }

      var _this$getBoundary = this.getBoundary('max', data.innerValue),
          maxYear = _this$getBoundary.maxYear,
          maxDate = _this$getBoundary.maxDate,
          maxMonth = _this$getBoundary.maxMonth,
          maxHour = _this$getBoundary.maxHour,
          maxMinute = _this$getBoundary.maxMinute;

      var _this$getBoundary2 = this.getBoundary('min', data.innerValue),
          minYear = _this$getBoundary2.minYear,
          minDate = _this$getBoundary2.minDate,
          minMonth = _this$getBoundary2.minMonth,
          minHour = _this$getBoundary2.minHour,
          minMinute = _this$getBoundary2.minMinute;

      var result = [{
        type: 'year',
        range: [minYear, maxYear]
      }, {
        type: 'month',
        range: [minMonth, maxMonth]
      }, {
        type: 'day',
        range: [minDate, maxDate]
      }, {
        type: 'hour',
        range: [minHour, maxHour]
      }, {
        type: 'minute',
        range: [minMinute, maxMinute]
      }];
      if (data.type === 'date') result.splice(3, 2);
      if (data.type === 'year-month') result.splice(2, 3);
      return result;
    },
    correctValue: function correctValue(value) {
      var data = this.data; // validate value

      var isDateType = data.type !== 'time';

      if (isDateType && !isValidDate(value)) {
        value = data.minDate;
      } else if (!isDateType && !value) {
        var minHour = data.minHour;
        value = padZero(minHour) + ":00";
      } // time type


      if (!isDateType) {
        var _value$split = value.split(':'),
            hour = _value$split[0],
            minute = _value$split[1];

        hour = padZero(range(hour, data.minHour, data.maxHour));
        minute = padZero(range(minute, data.minMinute, data.maxMinute));
        return hour + ":" + minute;
      } // date type


      value = Math.max(value, data.minDate);
      value = Math.min(value, data.maxDate);
      return value;
    },
    getBoundary: function getBoundary(type, innerValue) {
      var _ref2;

      var value = new Date(innerValue);
      var boundary = new Date(this.data[type + "Date"]);
      var year = boundary.getFullYear();
      var month = 1;
      var date = 1;
      var hour = 0;
      var minute = 0;

      if (type === 'max') {
        month = 12;
        date = getMonthEndDay(value.getFullYear(), value.getMonth() + 1);
        hour = 23;
        minute = 59;
      }

      if (value.getFullYear() === year) {
        month = boundary.getMonth() + 1;

        if (value.getMonth() + 1 === month) {
          date = boundary.getDate();

          if (value.getDate() === date) {
            hour = boundary.getHours();

            if (value.getHours() === hour) {
              minute = boundary.getMinutes();
            }
          }
        }
      }

      return _ref2 = {}, _defineProperty(_ref2, type + "Year", year), _defineProperty(_ref2, type + "Month", month), _defineProperty(_ref2, type + "Date", date), _defineProperty(_ref2, type + "Hour", hour), _defineProperty(_ref2, type + "Minute", minute), _ref2;
    },
    onCancel: function onCancel() {
      this.$emit('cancel');
    },
    onConfirm: function onConfirm() {
      this.$emit('confirm', this.data.innerValue);
    },
    onChange: function onChange() {
      var _this2 = this;

      var data = this.data;
      var value;
      var picker = this.getPicker();

      if (data.type === 'time') {
        var indexes = picker.getIndexes();
        value = indexes[0] + data.minHour + ":" + (indexes[1] + data.minMinute);
      } else {
        var values = picker.getValues();
        var year = getTrueValue(values[0]);
        var month = getTrueValue(values[1]);
        var maxDate = getMonthEndDay(year, month);
        var date = getTrueValue(values[2]);

        if (data.type === 'year-month') {
          date = 1;
        }

        date = date > maxDate ? maxDate : date;
        var hour = 0;
        var minute = 0;

        if (data.type === 'datetime') {
          hour = getTrueValue(values[3]);
          minute = getTrueValue(values[4]);
        }

        value = new Date(year, month - 1, date, hour, minute);
      }

      value = this.correctValue(value);
      this.updateColumnValue(value).then(function () {
        _this2.$emit('input', value);

        _this2.$emit('change', picker);
      });
    },
    updateColumnValue: function updateColumnValue(value) {
      var _this3 = this;

      var values = [];
      var data = this.data;
      var picker = this.getPicker();

      if (data.type === 'time') {
        var pair = value.split(':');
        values = [pair[0], pair[1]];
      } else {
        var date = new Date(value);
        values = ["" + date.getFullYear(), padZero(date.getMonth() + 1)];

        if (data.type === 'date') {
          values.push(padZero(date.getDate()));
        }

        if (data.type === 'datetime') {
          values.push(padZero(date.getDate()), padZero(date.getHours()), padZero(date.getMinutes()));
        }
      }

      return this.set({
        innerValue: value
      }).then(function () {
        return _this3.updateColumns();
      }).then(function () {
        return picker.setValues(values);
      });
    }
  },
  created: function created() {
    var _this4 = this;

    var innerValue = this.correctValue(this.data.value);
    this.updateColumnValue(innerValue).then(function () {
      _this4.$emit('input', innerValue);
    });
  }
});
});
define("static/vant/dialog/dialog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }return target;
  };return _extends.apply(this, arguments);
}

var queue = [];

function getContext() {
  var pages = getCurrentPages();
  return pages[pages.length - 1];
}

var Dialog = function Dialog(options) {
  options = _extends({}, Dialog.currentOptions, options);
  return new Promise(function (resolve, reject) {
    var context = options.context || getContext();
    var dialog = context.selectComponent(options.selector);
    delete options.selector;

    if (dialog) {
      dialog.set(_extends({
        onCancel: reject,
        onConfirm: resolve
      }, options));
      queue.push(dialog);
    } else {
      console.warn('未找到 van-dialog 节点，请确认 selector 及 context 是否正确');
    }
  });
};

Dialog.defaultOptions = {
  show: true,
  title: '',
  message: '',
  zIndex: 100,
  overlay: true,
  asyncClose: false,
  messageAlign: '',
  transition: 'scale',
  selector: '#van-dialog',
  confirmButtonText: '确认',
  cancelButtonText: '取消',
  showConfirmButton: true,
  showCancelButton: false,
  closeOnClickOverlay: false,
  confirmButtonOpenType: ''
};
Dialog.alert = Dialog;

Dialog.confirm = function (options) {
  return Dialog(_extends({
    showCancelButton: true
  }, options));
};

Dialog.close = function () {
  queue.forEach(function (dialog) {
    dialog.close();
  });
  queue = [];
};

Dialog.stopLoading = function () {
  queue.forEach(function (dialog) {
    dialog.stopLoading();
  });
};

Dialog.setDefaultOptions = function (options) {
  Object.assign(Dialog.currentOptions, options);
};

Dialog.resetDefaultOptions = function () {
  Dialog.currentOptions = _extends({}, Dialog.defaultOptions);
};

Dialog.resetDefaultOptions();
exports.default = Dialog;
});
define("static/vant/dialog/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _openType = require('../mixins/open-type');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

(0, _component.VantComponent)({
  mixins: [_openType.openType],
  props: {
    show: Boolean,
    title: String,
    message: String,
    useSlot: Boolean,
    asyncClose: Boolean,
    messageAlign: String,
    showCancelButton: Boolean,
    closeOnClickOverlay: Boolean,
    confirmButtonOpenType: String,
    zIndex: {
      type: Number,
      value: 2000
    },
    confirmButtonText: {
      type: String,
      value: '确认'
    },
    cancelButtonText: {
      type: String,
      value: '取消'
    },
    showConfirmButton: {
      type: Boolean,
      value: true
    },
    overlay: {
      type: Boolean,
      value: true
    },
    transition: {
      type: String,
      value: 'scale'
    }
  },
  data: {
    loading: {
      confirm: false,
      cancel: false
    }
  },
  watch: {
    show: function show(_show) {
      !_show && this.stopLoading();
    }
  },
  methods: {
    onConfirm: function onConfirm() {
      this.handleAction('confirm');
    },
    onCancel: function onCancel() {
      this.handleAction('cancel');
    },
    onClickOverlay: function onClickOverlay() {
      this.onClose('overlay');
    },
    handleAction: function handleAction(action) {
      if (this.data.asyncClose) {
        this.set(_defineProperty({}, "loading." + action, true));
      }

      this.onClose(action);
    },
    close: function close() {
      this.set({
        show: false
      });
    },
    stopLoading: function stopLoading() {
      this.set({
        loading: {
          confirm: false,
          cancel: false
        }
      });
    },
    onClose: function onClose(action) {
      if (!this.data.asyncClose) {
        this.close();
      }

      this.$emit('close', action); //把 dialog 实例传递出去，可以通过 stopLoading() 在外部关闭按钮的 loading

      this.$emit(action, {
        dialog: this
      });
      var callback = this.data[action === 'confirm' ? 'onConfirm' : 'onCancel'];

      if (callback) {
        callback(this);
      }
    }
  }
});
});
define("static/vant/field/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  classes: ['input-class'],
  props: {
    icon: String,
    label: String,
    error: Boolean,
    fixed: Boolean,
    focus: Boolean,
    center: Boolean,
    isLink: Boolean,
    leftIcon: String,
    disabled: Boolean,
    autosize: Boolean,
    readonly: Boolean,
    required: Boolean,
    iconClass: String,
    clearable: Boolean,
    inputAlign: String,
    customClass: String,
    confirmType: String,
    confirmHold: Boolean,
    errorMessage: String,
    placeholder: String,
    customStyle: String,
    useIconSlot: Boolean,
    useButtonSlot: Boolean,
    showConfirmBar: {
      type: Boolean,
      value: true
    },
    placeholderStyle: String,
    adjustPosition: {
      type: Boolean,
      value: true
    },
    cursorSpacing: {
      type: Number,
      value: 50
    },
    maxlength: {
      type: Number,
      value: -1
    },
    type: {
      type: String,
      value: 'text'
    },
    border: {
      type: Boolean,
      value: true
    },
    titleWidth: {
      type: String,
      value: '90px'
    }
  },
  data: {
    showClear: false
  },
  beforeCreate: function beforeCreate() {
    this.focused = false;
  },
  methods: {
    onInput: function onInput(event) {
      var _this = this;

      var _ref = event.detail || {},
          _ref$value = _ref.value,
          value = _ref$value === void 0 ? '' : _ref$value;

      this.set({
        value: value,
        showClear: this.getShowClear(value)
      }, function () {
        _this.emitChange(value);
      });
    },
    onFocus: function onFocus(event) {
      var _ref2 = event.detail || {},
          _ref2$value = _ref2.value,
          value = _ref2$value === void 0 ? '' : _ref2$value,
          _ref2$height = _ref2.height,
          height = _ref2$height === void 0 ? 0 : _ref2$height;

      this.$emit('focus', {
        value: value,
        height: height
      });
      this.focused = true;
      this.blurFromClear = false;
      this.set({
        showClear: this.getShowClear()
      });
    },
    onBlur: function onBlur(event) {
      var _this2 = this;

      var _ref3 = event.detail || {},
          _ref3$value = _ref3.value,
          value = _ref3$value === void 0 ? '' : _ref3$value,
          _ref3$cursor = _ref3.cursor,
          cursor = _ref3$cursor === void 0 ? 0 : _ref3$cursor;

      this.$emit('blur', {
        value: value,
        cursor: cursor
      });
      this.focused = false;
      var showClear = this.getShowClear();

      if (this.data.value === value) {
        this.set({
          showClear: showClear
        });
      } else if (!this.blurFromClear) {
        // fix: the handwritten keyboard does not trigger input change
        this.set({
          value: value,
          showClear: showClear
        }, function () {
          _this2.emitChange(value);
        });
      }
    },
    onClickIcon: function onClickIcon() {
      this.$emit('click-icon');
    },
    getShowClear: function getShowClear(value) {
      value = value === undefined ? this.data.value : value;
      return this.data.clearable && this.focused && value && !this.data.readonly;
    },
    onClear: function onClear() {
      var _this3 = this;

      this.blurFromClear = true;
      this.set({
        value: '',
        showClear: this.getShowClear('')
      }, function () {
        _this3.emitChange('');

        _this3.$emit('clear', '');
      });
    },
    onConfirm: function onConfirm() {
      this.$emit('confirm', this.data.value);
    },
    emitChange: function emitChange(value) {
      this.$emit('input', value);
      this.$emit('change', value);
    }
  }
});
});
define("static/vant/goods-action-button/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _link = require('../mixins/link');

var _button = require('../mixins/button');

var _openType = require('../mixins/open-type');

(0, _component.VantComponent)({
  mixins: [_link.link, _button.button, _openType.openType],
  props: {
    text: String,
    loading: Boolean,
    disabled: Boolean,
    type: {
      type: String,
      value: 'danger'
    }
  },
  methods: {
    onClick: function onClick(event) {
      this.$emit('click', event.detail);
      this.jumpLink();
    }
  }
});
});
define("static/vant/goods-action-icon/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _link = require('../mixins/link');

var _button = require('../mixins/button');

var _openType = require('../mixins/open-type');

(0, _component.VantComponent)({
  classes: ['icon-class', 'text-class'],
  mixins: [_link.link, _button.button, _openType.openType],
  props: {
    text: String,
    info: String,
    icon: String
  },
  methods: {
    onClick: function onClick(event) {
      this.$emit('click', event.detail);
      this.jumpLink();
    }
  }
});
});
define("static/vant/goods-action/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _iphonex = require('../mixins/iphonex');

(0, _component.VantComponent)({
  mixins: [_iphonex.iphonex]
});
});
define("static/vant/icon/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    info: null,
    name: String,
    size: String,
    color: String,
    customStyle: String,
    classPrefix: {
      type: String,
      value: 'van-icon'
    }
  },
  methods: {
    onClick: function onClick() {
      this.$emit('click');
    }
  }
});
});
define("static/vant/info/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    info: null,
    customStyle: String
  }
});
});
define("static/vant/loading/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    size: {
      type: String,
      value: '30px'
    },
    type: {
      type: String,
      value: 'circular'
    },
    color: {
      type: String,
      value: '#c9c9c9'
    }
  }
});
});
define("static/vant/mixins/basic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var basic = exports.basic = Behavior({
  methods: {
    $emit: function $emit() {
      this.triggerEvent.apply(this, arguments);
    },
    getRect: function getRect(selector, all) {
      var _this = this;

      return new Promise(function (resolve) {
        wx.createSelectorQuery().in(_this)[all ? 'selectAll' : 'select'](selector).boundingClientRect(function (rect) {
          if (all && Array.isArray(rect) && rect.length) {
            resolve(rect);
          }

          if (!all && rect) {
            resolve(rect);
          }
        }).exec();
      });
    }
  }
});
});
define("static/vant/mixins/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var button = exports.button = Behavior({
  externalClasses: ['hover-class'],
  properties: {
    id: String,
    lang: {
      type: String,
      value: 'en'
    },
    sessionFrom: String,
    sendMessageTitle: String,
    sendMessagePath: String,
    sendMessageImg: String,
    showMessageCard: String,
    appParameter: String,
    ariaLabel: String
  }
});
});
define("static/vant/mixins/iphonex.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var isIPhoneX = null;

function getIsIPhoneX() {
  return new Promise(function (resolve, reject) {
    if (isIPhoneX !== null) {
      resolve(isIPhoneX);
    } else {
      wx.getSystemInfo({
        success: function success(_ref) {
          var model = _ref.model,
              screenHeight = _ref.screenHeight;
          var iphoneX = /iphone x/i.test(model);
          var iphoneNew = /iPhone11/i.test(model) && screenHeight === 812;
          isIPhoneX = iphoneX || iphoneNew;
          resolve(isIPhoneX);
        },
        fail: reject
      });
    }
  });
}

var iphonex = exports.iphonex = Behavior({
  properties: {
    safeAreaInsetBottom: {
      type: Boolean,
      value: true
    }
  },
  created: function created() {
    var _this = this;

    getIsIPhoneX().then(function (isIPhoneX) {
      _this.set({
        isIPhoneX: isIPhoneX
      });
    });
  }
});
});
define("static/vant/mixins/link.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var link = exports.link = Behavior({
  properties: {
    url: String,
    linkType: {
      type: String,
      value: 'navigateTo'
    }
  },
  methods: {
    jumpLink: function jumpLink(urlKey) {
      if (urlKey === void 0) {
        urlKey = 'url';
      }

      var url = this.data[urlKey];

      if (url) {
        wx[this.data.linkType]({
          url: url
        });
      }
    }
  }
});
});
define("static/vant/mixins/observer/behavior.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
function setAsync(context, data) {
  return new Promise(function (resolve) {
    context.setData(data, resolve);
  });
}

;
var behavior = exports.behavior = Behavior({
  created: function created() {
    var _this = this;

    if (!this.$options) {
      return;
    }

    var cache = {};

    var _this$$options = this.$options(),
        computed = _this$$options.computed;

    var keys = Object.keys(computed);

    this.calcComputed = function () {
      var needUpdate = {};
      keys.forEach(function (key) {
        var value = computed[key].call(_this);

        if (cache[key] !== value) {
          cache[key] = needUpdate[key] = value;
        }
      });
      return needUpdate;
    };
  },
  attached: function attached() {
    this.set();
  },
  methods: {
    // set data and set computed data
    set: function set(data, callback) {
      var _this2 = this;

      var stack = [];

      if (data) {
        stack.push(setAsync(this, data));
      }

      if (this.calcComputed) {
        stack.push(setAsync(this, this.calcComputed()));
      }

      return Promise.all(stack).then(function (res) {
        if (callback && typeof callback === 'function') {
          callback.call(_this2);
        }

        return res;
      });
    }
  }
});
});
define("static/vant/mixins/observer/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.observe = observe;

var _behavior = require('./behavior');

var _props = require('./props');

function observe(vantOptions, options) {
  var watch = vantOptions.watch,
      computed = vantOptions.computed;
  options.behaviors.push(_behavior.behavior);

  if (watch) {
    var props = options.properties || {};
    Object.keys(watch).forEach(function (key) {
      if (key in props) {
        var prop = props[key];

        if (prop === null || !('type' in prop)) {
          prop = {
            type: prop
          };
        }

        prop.observer = watch[key];
        props[key] = prop;
      }
    });
    options.properties = props;
  }

  if (computed) {
    options.methods = options.methods || {};

    options.methods.$options = function () {
      return vantOptions;
    };

    if (options.properties) {
      (0, _props.observeProps)(options.properties);
    }
  }
}
});
define("static/vant/mixins/observer/props.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.observeProps = observeProps;
function observeProps(props) {
  if (!props) {
    return;
  }

  Object.keys(props).forEach(function (key) {
    var prop = props[key];

    if (prop === null || !('type' in prop)) {
      prop = {
        type: prop
      };
    }

    var _prop = prop,
        observer = _prop.observer;

    prop.observer = function () {
      if (observer) {
        if (typeof observer === 'string') {
          observer = this[observer];
        }

        observer.apply(this, arguments);
      }

      this.set();
    };

    props[key] = prop;
  });
}
});
define("static/vant/mixins/open-type.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var openType = exports.openType = Behavior({
  properties: {
    openType: String
  },
  methods: {
    bindGetUserInfo: function bindGetUserInfo(event) {
      this.$emit('getuserinfo', event.detail);
    },
    bindContact: function bindContact(event) {
      this.$emit('contact', event.detail);
    },
    bindGetPhoneNumber: function bindGetPhoneNumber(event) {
      this.$emit('getphonenumber', event.detail);
    },
    bindError: function bindError(event) {
      this.$emit('error', event.detail);
    },
    bindLaunchApp: function bindLaunchApp(event) {
      this.$emit('launchapp', event.detail);
    },
    bindOpenSetting: function bindOpenSetting(event) {
      this.$emit('opensetting', event.detail);
    }
  }
});
});
define("static/vant/mixins/touch.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var touch = exports.touch = Behavior({
  methods: {
    touchStart: function touchStart(event) {
      this.direction = '';
      this.deltaX = 0;
      this.deltaY = 0;
      this.offsetX = 0;
      this.offsetY = 0;
      this.startX = event.touches[0].clientX;
      this.startY = event.touches[0].clientY;
    },
    touchMove: function touchMove(event) {
      var touch = event.touches[0];
      this.deltaX = touch.clientX - this.startX;
      this.deltaY = touch.clientY - this.startY;
      this.offsetX = Math.abs(this.deltaX);
      this.offsetY = Math.abs(this.deltaY);
      this.direction = this.offsetX > this.offsetY ? 'horizontal' : this.offsetX < this.offsetY ? 'vertical' : '';
    }
  }
});
});
define("static/vant/mixins/transition.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var transition = exports.transition = function transition(showDefaultValue) {
  return Behavior({
    properties: {
      customStyle: String,
      show: {
        type: Boolean,
        value: showDefaultValue,
        observer: 'observeShow'
      },
      duration: {
        type: Number,
        value: 300
      }
    },
    data: {
      type: '',
      inited: false,
      display: false,
      supportAnimation: true
    },
    attached: function attached() {
      if (this.data.show) {
        this.show();
      }

      this.detectSupport();
    },
    methods: {
      detectSupport: function detectSupport() {
        var _this = this;

        wx.getSystemInfo({
          success: function success(info) {
            if (info && info.system && info.system.indexOf('iOS 8') === 0) {
              _this.set({
                supportAnimation: false
              });
            }
          }
        });
      },
      observeShow: function observeShow(value) {
        if (value) {
          this.show();
        } else {
          if (this.data.supportAnimation) {
            this.set({
              type: 'leave'
            });
          } else {
            this.set({
              display: false
            });
          }
        }
      },
      show: function show() {
        this.set({
          inited: true,
          display: true,
          type: 'enter'
        });
      },
      onAnimationEnd: function onAnimationEnd() {
        if (!this.data.show) {
          this.set({
            display: false
          });
        }
      }
    }
  });
};
});
define("static/vant/nav-bar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['title-class'],
  props: {
    title: String,
    fixed: Boolean,
    leftText: String,
    rightText: String,
    leftArrow: Boolean,
    border: {
      type: Boolean,
      value: true
    },
    zIndex: {
      type: Number,
      value: 1
    }
  },
  methods: {
    onClickLeft: function onClickLeft() {
      this.$emit('click-left');
    },
    onClickRight: function onClickRight() {
      this.$emit('click-right');
    }
  }
});
});
define("static/vant/notice-bar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var FONT_COLOR = '#ed6a0c';
var BG_COLOR = '#fffbe8';
(0, _component.VantComponent)({
  props: {
    text: {
      type: String,
      value: ''
    },
    mode: {
      type: String,
      value: ''
    },
    url: {
      type: String,
      value: ''
    },
    openType: {
      type: String,
      value: 'navigate'
    },
    delay: {
      type: Number,
      value: 0
    },
    speed: {
      type: Number,
      value: 50
    },
    scrollable: {
      type: Boolean,
      value: true
    },
    leftIcon: {
      type: String,
      value: ''
    },
    color: {
      type: String,
      value: FONT_COLOR
    },
    backgroundColor: {
      type: String,
      value: BG_COLOR
    }
  },
  data: {
    show: true,
    hasRightIcon: false
  },
  watch: {
    text: function text() {
      this.set({}, this.init);
    }
  },
  created: function created() {
    if (this.data.mode) {
      this.set({
        hasRightIcon: true
      });
    }

    this.resetAnimation = wx.createAnimation({
      duration: 0,
      timingFunction: 'linear'
    });
  },
  destroyed: function destroyed() {
    this.timer && clearTimeout(this.timer);
  },
  methods: {
    init: function init() {
      var _this = this;

      Promise.all([this.getRect('.van-notice-bar__content'), this.getRect('.van-notice-bar__content-wrap')]).then(function (rects) {
        var contentRect = rects[0],
            wrapRect = rects[1];

        if (contentRect == null || wrapRect == null || !contentRect.width || !wrapRect.width) {
          return;
        }

        var _this$data = _this.data,
            speed = _this$data.speed,
            scrollable = _this$data.scrollable,
            delay = _this$data.delay;

        if (scrollable && wrapRect.width < contentRect.width) {
          var duration = contentRect.width / speed * 1000;
          _this.wrapWidth = wrapRect.width;
          _this.contentWidth = contentRect.width;
          _this.duration = duration;
          _this.animation = wx.createAnimation({
            duration: duration,
            timingFunction: 'linear',
            delay: delay
          });

          _this.scroll();
        }
      });
    },
    scroll: function scroll() {
      var _this2 = this;

      this.timer && clearTimeout(this.timer);
      this.timer = null;
      this.set({
        animationData: this.resetAnimation.translateX(this.wrapWidth).step().export()
      });
      setTimeout(function () {
        _this2.set({
          animationData: _this2.animation.translateX(-_this2.contentWidth).step().export()
        });
      }, 20);
      this.timer = setTimeout(function () {
        _this2.scroll();
      }, this.duration);
    },
    onClickIcon: function onClickIcon() {
      this.timer && clearTimeout(this.timer);
      this.timer = null;
      this.set({
        show: false
      });
    },
    onClick: function onClick(event) {
      this.$emit('click', event);
    }
  }
});
});
define("static/vant/notify/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _color = require('../common/color');

(0, _component.VantComponent)({
  props: {
    text: String,
    color: {
      type: String,
      value: '#fff'
    },
    backgroundColor: {
      type: String,
      value: _color.RED
    },
    duration: {
      type: Number,
      value: 3000
    }
  },
  methods: {
    show: function show() {
      var _this = this;

      var duration = this.data.duration;
      clearTimeout(this.timer);
      this.set({
        show: true
      });

      if (duration > 0 && duration !== Infinity) {
        this.timer = setTimeout(function () {
          _this.hide();
        }, duration);
      }
    },
    hide: function hide() {
      clearTimeout(this.timer);
      this.set({
        show: false
      });
    }
  }
});
});
define("static/vant/notify/notify.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Notify;

var _utils = require('../common/utils');

var defaultOptions = {
  selector: '#van-notify',
  duration: 3000
};

function parseOptions(text) {
  return (0, _utils.isObj)(text) ? text : {
    text: text
  };
}

function getContext() {
  var pages = getCurrentPages();
  return pages[pages.length - 1];
}

function Notify(options) {
  if (options === void 0) {
    options = {};
  }

  options = Object.assign({}, defaultOptions, parseOptions(options));
  var context = options.context || getContext();
  var notify = context.selectComponent(options.selector);
  delete options.selector;

  if (notify) {
    notify.set(options);
    notify.show();
  } else {
    console.warn('未找到 van-notify 节点，请确认 selector 及 context 是否正确');
  }
}
});
define("static/vant/overlay/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    show: Boolean,
    mask: Boolean,
    customStyle: String,
    zIndex: {
      type: Number,
      value: 1
    }
  },
  methods: {
    onClick: function onClick() {
      this.$emit('click');
    },
    // for prevent touchmove
    noop: function noop() {}
  }
});
});
define("static/vant/panel/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  classes: ['header-class', 'footer-class'],
  props: {
    desc: String,
    title: String,
    status: String,
    useFooterSlot: Boolean
  }
});
});
define("static/vant/picker-column/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _utils = require('../common/utils');

var DEFAULT_DURATION = 200;
(0, _component.VantComponent)({
  classes: ['active-class'],
  props: {
    valueKey: String,
    className: String,
    itemHeight: Number,
    visibleItemCount: Number,
    initialOptions: {
      type: Array,
      value: []
    },
    defaultIndex: {
      type: Number,
      value: 0
    }
  },
  data: {
    startY: 0,
    offset: 0,
    duration: 0,
    startOffset: 0,
    options: [],
    currentIndex: 0
  },
  beforeCreate: function beforeCreate() {
    var _this = this;

    var _this$data = this.data,
        defaultIndex = _this$data.defaultIndex,
        initialOptions = _this$data.initialOptions;
    this.set({
      currentIndex: defaultIndex,
      options: initialOptions
    }).then(function () {
      _this.setIndex(defaultIndex);
    });
  },
  computed: {
    count: function count() {
      return this.data.options.length;
    },
    baseOffset: function baseOffset() {
      var data = this.data;
      return data.itemHeight * (data.visibleItemCount - 1) / 2;
    },
    wrapperStyle: function wrapperStyle() {
      var data = this.data;
      return ["transition: " + data.duration + "ms", "transform: translate3d(0, " + (data.offset + data.baseOffset) + "px, 0)", "line-height: " + data.itemHeight + "px"].join('; ');
    }
  },
  watch: {
    defaultIndex: function defaultIndex(value) {
      this.setIndex(value);
    }
  },
  methods: {
    onTouchStart: function onTouchStart(event) {
      this.set({
        startY: event.touches[0].clientY,
        startOffset: this.data.offset,
        duration: 0
      });
    },
    onTouchMove: function onTouchMove(event) {
      var data = this.data;
      var deltaY = event.touches[0].clientY - data.startY;
      this.set({
        offset: (0, _utils.range)(data.startOffset + deltaY, -(data.count * data.itemHeight), data.itemHeight)
      });
    },
    onTouchEnd: function onTouchEnd() {
      var data = this.data;

      if (data.offset !== data.startOffset) {
        this.set({
          duration: DEFAULT_DURATION
        });
        var index = (0, _utils.range)(Math.round(-data.offset / data.itemHeight), 0, data.count - 1);
        this.setIndex(index, true);
      }
    },
    onClickItem: function onClickItem(event) {
      var index = event.currentTarget.dataset.index;
      this.setIndex(index, true);
    },
    adjustIndex: function adjustIndex(index) {
      var data = this.data;
      index = (0, _utils.range)(index, 0, data.count);

      for (var i = index; i < data.count; i++) {
        if (!this.isDisabled(data.options[i])) return i;
      }

      for (var _i = index - 1; _i >= 0; _i--) {
        if (!this.isDisabled(data.options[_i])) return _i;
      }
    },
    isDisabled: function isDisabled(option) {
      return (0, _utils.isObj)(option) && option.disabled;
    },
    getOptionText: function getOptionText(option) {
      var data = this.data;
      return (0, _utils.isObj)(option) && data.valueKey in option ? option[data.valueKey] : option;
    },
    setIndex: function setIndex(index, userAction) {
      var _this2 = this;

      var data = this.data;
      index = this.adjustIndex(index) || 0;
      var offset = -index * data.itemHeight;

      if (index !== data.currentIndex) {
        return this.set({
          offset: offset,
          currentIndex: index
        }).then(function () {
          userAction && _this2.$emit('change', index);
        });
      } else {
        return this.set({
          offset: offset
        });
      }
    },
    setValue: function setValue(value) {
      var options = this.data.options;

      for (var i = 0; i < options.length; i++) {
        if (this.getOptionText(options[i]) === value) {
          return this.setIndex(i);
        }
      }

      return Promise.resolve();
    },
    getValue: function getValue() {
      var data = this.data;
      return data.options[data.currentIndex];
    }
  }
});
});
define("static/vant/picker/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

function isSimple(columns) {
  return columns.length && !columns[0].values;
}

(0, _component.VantComponent)({
  classes: ['active-class', 'toolbar-class', 'column-class'],
  props: {
    title: String,
    loading: Boolean,
    showToolbar: Boolean,
    confirmButtonText: String,
    cancelButtonText: String,
    visibleItemCount: {
      type: Number,
      value: 5
    },
    valueKey: {
      type: String,
      value: 'text'
    },
    itemHeight: {
      type: Number,
      value: 44
    },
    columns: {
      type: Array,
      value: [],
      observer: function observer(columns) {
        if (columns === void 0) {
          columns = [];
        }

        this.simple = isSimple(columns);
        this.children = this.selectAllComponents('.van-picker__column');

        if (Array.isArray(this.children) && this.children.length) {
          this.setColumns().catch(function () {});
        }
      }
    }
  },
  beforeCreate: function beforeCreate() {
    this.children = [];
  },
  methods: {
    noop: function noop() {},
    setColumns: function setColumns() {
      var _this = this;

      var data = this.data;
      var columns = this.simple ? [{
        values: data.columns
      }] : data.columns;
      var stack = columns.map(function (column, index) {
        return _this.setColumnValues(index, column.values);
      });
      return Promise.all(stack);
    },
    emit: function emit(event) {
      var type = event.currentTarget.dataset.type;

      if (this.simple) {
        this.$emit(type, {
          value: this.getColumnValue(0),
          index: this.getColumnIndex(0)
        });
      } else {
        this.$emit(type, {
          value: this.getValues(),
          index: this.getIndexes()
        });
      }
    },
    onChange: function onChange(event) {
      if (this.simple) {
        this.$emit('change', {
          picker: this,
          value: this.getColumnValue(0),
          index: this.getColumnIndex(0)
        });
      } else {
        this.$emit('change', {
          picker: this,
          value: this.getValues(),
          index: event.currentTarget.dataset.index
        });
      }
    },
    // get column instance by index
    getColumn: function getColumn(index) {
      return this.children[index];
    },
    // get column value by index
    getColumnValue: function getColumnValue(index) {
      var column = this.getColumn(index);
      return column && column.getValue();
    },
    // set column value by index
    setColumnValue: function setColumnValue(index, value) {
      var column = this.getColumn(index);

      if (column == null) {
        return Promise.reject('setColumnValue: 对应列不存在');
      }

      return column.setValue(value);
    },
    // get column option index by column index
    getColumnIndex: function getColumnIndex(columnIndex) {
      return (this.getColumn(columnIndex) || {}).data.currentIndex;
    },
    // set column option index by column index
    setColumnIndex: function setColumnIndex(columnIndex, optionIndex) {
      var column = this.getColumn(columnIndex);

      if (column == null) {
        return Promise.reject('setColumnIndex: 对应列不存在');
      }

      return column.setIndex(optionIndex);
    },
    // get options of column by index
    getColumnValues: function getColumnValues(index) {
      return (this.children[index] || {}).data.options;
    },
    // set options of column by index
    setColumnValues: function setColumnValues(index, options, needReset) {
      if (needReset === void 0) {
        needReset = true;
      }

      var column = this.children[index];

      if (column == null) {
        return Promise.reject('setColumnValues: 对应列不存在');
      }

      var isSame = JSON.stringify(column.data.options) === JSON.stringify(options);

      if (isSame) {
        return Promise.resolve();
      }

      return column.set({
        options: options
      }).then(function () {
        if (needReset) {
          column.setIndex(0);
        }
      });
    },
    // get values of all columns
    getValues: function getValues() {
      return this.children.map(function (child) {
        return child.getValue();
      });
    },
    // set values of all columns
    setValues: function setValues(values) {
      var _this2 = this;

      var stack = values.map(function (value, index) {
        return _this2.setColumnValue(index, value);
      });
      return Promise.all(stack);
    },
    // get indexes of all columns
    getIndexes: function getIndexes() {
      return this.children.map(function (child) {
        return child.data.currentIndex;
      });
    },
    // set indexes of all columns
    setIndexes: function setIndexes(indexes) {
      var _this3 = this;

      var stack = indexes.map(function (optionIndex, columnIndex) {
        return _this3.setColumnIndex(columnIndex, optionIndex);
      });
      return Promise.all(stack);
    }
  }
});
});
define("static/vant/popup/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _transition = require('../mixins/transition');

var _iphonex = require('../mixins/iphonex');

(0, _component.VantComponent)({
  mixins: [(0, _transition.transition)(false), _iphonex.iphonex],
  props: {
    transition: String,
    customStyle: String,
    overlayStyle: String,
    zIndex: {
      type: Number,
      value: 100
    },
    overlay: {
      type: Boolean,
      value: true
    },
    closeOnClickOverlay: {
      type: Boolean,
      value: true
    },
    position: {
      type: String,
      value: 'center'
    }
  },
  methods: {
    onClickOverlay: function onClickOverlay() {
      this.$emit('click-overlay');

      if (this.data.closeOnClickOverlay) {
        this.$emit('close');
      }
    }
  }
});
});
define("static/vant/progress/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _color = require('../common/color');

(0, _component.VantComponent)({
  props: {
    inactive: Boolean,
    percentage: Number,
    pivotText: String,
    pivotColor: String,
    showPivot: {
      type: Boolean,
      value: true
    },
    color: {
      type: String,
      value: _color.BLUE
    },
    textColor: {
      type: String,
      value: '#fff'
    }
  },
  data: {
    pivotWidth: 0,
    progressWidth: 0
  },
  watch: {
    pivotText: 'getWidth',
    showPivot: 'getWidth'
  },
  computed: {
    portionStyle: function portionStyle() {
      var width = (this.data.progressWidth - this.data.pivotWidth) * this.data.percentage / 100 + 'px';
      var background = this.getCurrentColor();
      return "width: " + width + "; background: " + background + "; ";
    },
    pivotStyle: function pivotStyle() {
      var color = this.data.textColor;
      var background = this.data.pivotColor || this.getCurrentColor();
      return "color: " + color + "; background: " + background;
    },
    text: function text() {
      return this.data.pivotText || this.data.percentage + '%';
    }
  },
  mounted: function mounted() {
    this.getWidth();
  },
  methods: {
    getCurrentColor: function getCurrentColor() {
      return this.data.inactive ? '#cacaca' : this.data.color;
    },
    getWidth: function getWidth() {
      var _this = this;

      this.getRect('.van-progress').then(function (rect) {
        _this.set({
          progressWidth: rect.width
        });
      });
      this.getRect('.van-progress__pivot').then(function (rect) {
        _this.set({
          pivotWidth: rect.width || 0
        });
      });
    }
  }
});
});
define("static/vant/radio-group/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  relation: {
    name: 'radio',
    type: 'descendant',
    linked: function linked(target) {
      var _this$data = this.data,
          value = _this$data.value,
          disabled = _this$data.disabled;
      target.set({
        value: value,
        disabled: disabled || target.data.disabled
      });
    }
  },
  props: {
    value: null,
    disabled: Boolean
  },
  watch: {
    value: function value(_value) {
      var children = this.getRelationNodes('../radio/index');
      children.forEach(function (child) {
        child.set({
          value: _value
        });
      });
    },
    disabled: function disabled(_disabled) {
      var children = this.getRelationNodes('../radio/index');
      children.forEach(function (child) {
        child.set({
          disabled: _disabled || child.data.disabled
        });
      });
    }
  }
});
});
define("static/vant/radio/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  relation: {
    name: 'radio-group',
    type: 'ancestor'
  },
  classes: ['icon-class', 'label-class'],
  props: {
    name: null,
    value: null,
    disabled: Boolean,
    labelDisabled: Boolean,
    labelPosition: String,
    checkedColor: String
  },
  methods: {
    emitChange: function emitChange(value) {
      var instance = this.getRelationNodes('../radio-group/index')[0] || this;
      instance.$emit('input', value);
      instance.$emit('change', value);
    },
    onChange: function onChange(event) {
      this.emitChange(event.detail.value);
    },
    onClickLabel: function onClickLabel() {
      if (!this.data.disabled && !this.data.labelDisabled) {
        this.emitChange(this.data.name);
      }
    }
  }
});
});
define("static/vant/rate/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }return target;
  };return _extends.apply(this, arguments);
}

(0, _component.VantComponent)({
  field: true,
  classes: ['icon-class'],
  props: {
    readonly: Boolean,
    disabled: Boolean,
    size: {
      type: Number,
      value: 20
    },
    icon: {
      type: String,
      value: 'star'
    },
    voidIcon: {
      type: String,
      value: 'star-o'
    },
    color: {
      type: String,
      value: '#ffd21e'
    },
    voidColor: {
      type: String,
      value: '#c7c7c7'
    },
    disabledColor: {
      type: String,
      value: '#bdbdbd'
    },
    count: {
      type: Number,
      value: 5
    },
    value: {
      type: Number,
      value: 0
    }
  },
  data: {
    innerValue: 0
  },
  watch: {
    value: function value(_value) {
      if (_value !== this.data.innerValue) {
        this.set({
          innerValue: _value
        });
      }
    }
  },
  computed: {
    list: function list() {
      var _this$data = this.data,
          count = _this$data.count,
          innerValue = _this$data.innerValue;
      return Array.from({
        length: count
      }, function (_, index) {
        return index < innerValue;
      });
    }
  },
  methods: {
    onSelect: function onSelect(event) {
      var data = this.data;
      var index = event.currentTarget.dataset.index;

      if (!data.disabled && !data.readonly) {
        this.set({
          innerValue: index + 1
        });
        this.$emit('input', index + 1);
        this.$emit('change', index + 1);
      }
    },
    onTouchMove: function onTouchMove(event) {
      var _this = this;

      var _event$touches$ = event.touches[0],
          clientX = _event$touches$.clientX,
          clientY = _event$touches$.clientY;
      this.getRect('.van-rate__item', true).then(function (list) {
        var target = list.find(function (item) {
          return clientX >= item.left && clientX <= item.right && clientY >= item.top && clientY <= item.bottom;
        });

        if (target != null) {
          _this.onSelect(_extends({}, event, {
            currentTarget: target
          }));
        }
      });
    }
  }
});
});
define("static/vant/row/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  relation: {
    name: 'col',
    type: 'descendant',
    linked: function linked(target) {
      if (this.data.gutter) {
        target.setGutter(this.data.gutter);
      }
    }
  },
  props: {
    gutter: Number
  },
  watch: {
    gutter: 'setGutter'
  },
  mounted: function mounted() {
    if (this.data.gutter) {
      this.setGutter();
    }
  },
  methods: {
    setGutter: function setGutter() {
      var _this = this;

      var gutter = this.data.gutter;
      var margin = "-" + Number(gutter) / 2 + "px";
      var style = gutter ? "margin-right: " + margin + "; margin-left: " + margin + ";" : '';
      this.set({
        style: style
      });
      this.getRelationNodes('../col/index').forEach(function (col) {
        col.setGutter(_this.data.gutter);
      });
    }
  }
});
});
define("static/vant/search/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  classes: ['field-class', 'input-class', 'cancel-class'],
  props: {
    focus: Boolean,
    error: Boolean,
    disabled: Boolean,
    readonly: Boolean,
    inputAlign: String,
    showAction: Boolean,
    useActionSlot: Boolean,
    placeholder: String,
    placeholderStyle: String,
    background: {
      type: String,
      value: '#f2f2f2'
    },
    maxlength: {
      type: Number,
      value: -1
    }
  },
  methods: {
    onChange: function onChange(event) {
      this.set({
        value: event.detail
      });
      this.$emit('change', event.detail);
    },
    onCancel: function onCancel() {
      this.set({
        value: ''
      });
      this.$emit('cancel');
      this.$emit('change', '');
    },
    onSearch: function onSearch() {
      this.$emit('search', this.data.value);
    },
    onFocus: function onFocus() {
      this.$emit('focus');
    },
    onBlur: function onBlur() {
      this.$emit('blur');
    },
    onClear: function onClear() {
      this.$emit('clear');
    }
  }
});
});
define("static/vant/slider/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _touch = require('../mixins/touch');

(0, _component.VantComponent)({
  mixins: [_touch.touch],
  props: {
    disabled: Boolean,
    useButtonSlot: Boolean,
    activeColor: String,
    inactiveColor: String,
    max: {
      type: Number,
      value: 100
    },
    min: {
      type: Number,
      value: 0
    },
    step: {
      type: Number,
      value: 1
    },
    value: {
      type: Number,
      value: 0
    },
    barHeight: {
      type: String,
      value: '2px'
    }
  },
  watch: {
    value: function value(_value) {
      this.updateValue(_value, false);
    }
  },
  created: function created() {
    this.updateValue(this.data.value);
  },
  methods: {
    onTouchStart: function onTouchStart(event) {
      if (this.data.disabled) return;
      this.touchStart(event);
      this.startValue = this.format(this.data.value);
    },
    onTouchMove: function onTouchMove(event) {
      var _this = this;

      if (this.data.disabled) return;
      this.touchMove(event);
      this.getRect('.van-slider').then(function (rect) {
        var diff = _this.deltaX / rect.width * 100;

        _this.updateValue(_this.startValue + diff, false, true);
      });
    },
    onTouchEnd: function onTouchEnd() {
      if (this.data.disabled) return;
      this.updateValue(this.data.value, true);
    },
    onClick: function onClick(event) {
      var _this2 = this;

      if (this.data.disabled) return;
      this.getRect(function (rect) {
        var value = (event.detail.x - rect.left) / rect.width * 100;

        _this2.updateValue(value, true);
      });
    },
    updateValue: function updateValue(value, end, drag) {
      value = this.format(value);
      this.set({
        value: value,
        barStyle: "width: " + value + "%; height: " + this.data.barHeight + ";"
      });

      if (drag) {
        this.$emit('drag', {
          value: value
        });
      }

      if (end) {
        this.$emit('change', value);
      }
    },
    format: function format(value) {
      var _this$data = this.data,
          max = _this$data.max,
          min = _this$data.min,
          step = _this$data.step;
      return Math.round(Math.max(min, Math.min(value, max)) / step) * step;
    }
  }
});
});
define("static/vant/stepper/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

// Note that the bitwise operators and shift operators operate on 32-bit ints
// so in that case, the max safe integer is 2^31-1, or 2147483647

var MAX = 2147483647;
(0, _component.VantComponent)({
  field: true,
  classes: ['input-class', 'plus-class', 'minus-class'],
  props: {
    value: null,
    integer: Boolean,
    disabled: Boolean,
    asyncChange: Boolean,
    disableInput: Boolean,
    min: {
      type: null,
      value: 1
    },
    max: {
      type: null,
      value: MAX
    },
    step: {
      type: null,
      value: 1
    }
  },
  computed: {
    minusDisabled: function minusDisabled() {
      return this.data.disabled || this.data.value <= this.data.min;
    },
    plusDisabled: function plusDisabled() {
      return this.data.disabled || this.data.value >= this.data.max;
    }
  },
  watch: {
    value: function value(_value) {
      if (_value !== '') {
        this.set({
          value: this.range(_value)
        });
      }
    }
  },
  data: {
    focus: false
  },
  created: function created() {
    this.set({
      value: this.range(this.data.value)
    });
  },
  methods: {
    onFocus: function onFocus() {
      this.setData({
        focus: true
      });
    },
    // limit value range
    range: function range(value) {
      return Math.max(Math.min(this.data.max, value), this.data.min);
    },
    onInput: function onInput(event) {
      var _ref = event.detail || {},
          _ref$value = _ref.value,
          value = _ref$value === void 0 ? '' : _ref$value;

      this.triggerInput(value);
    },
    onChange: function onChange(type) {
      if (this.data[type + "Disabled"]) {
        this.$emit('overlimit', type);
        return;
      }

      var diff = type === 'minus' ? -this.data.step : +this.data.step;
      var value = Math.round((this.data.value + diff) * 100) / 100;
      this.triggerInput(this.range(value));
      this.$emit(type);
    },
    onBlur: function onBlur(event) {
      var value = this.range(this.data.value);
      this.triggerInput(value);
      this.$emit('blur', event);
    },
    onMinus: function onMinus() {
      this.onChange('minus');
    },
    onPlus: function onPlus() {
      this.onChange('plus');
    },
    triggerInput: function triggerInput(value) {
      this.set({
        value: this.data.asyncChange ? this.data.value : value
      });
      this.$emit('change', value);
    }
  }
});
});
define("static/vant/steps/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _color = require('../common/color');

(0, _component.VantComponent)({
  props: {
    icon: String,
    steps: Array,
    active: Number,
    direction: {
      type: String,
      value: 'horizontal'
    },
    activeColor: {
      type: String,
      value: _color.GREEN
    }
  },
  watch: {
    steps: 'formatSteps',
    active: 'formatSteps'
  },
  created: function created() {
    this.formatSteps();
  },
  methods: {
    formatSteps: function formatSteps() {
      var _this = this;

      var steps = this.data.steps;
      steps.forEach(function (step, index) {
        step.status = _this.getStatus(index);
      });
      this.set({
        steps: steps
      });
    },
    getStatus: function getStatus(index) {
      var active = this.data.active;

      if (index < active) {
        return 'finish';
      } else if (index === active) {
        return 'process';
      }

      return '';
    }
  }
});
});
define("static/vant/submit-bar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _iphonex = require('../mixins/iphonex');

(0, _component.VantComponent)({
  mixins: [_iphonex.iphonex],
  classes: ['bar-class', 'price-class', 'button-class'],
  props: {
    tip: null,
    type: Number,
    price: null,
    label: String,
    loading: Boolean,
    disabled: Boolean,
    buttonText: String,
    currency: {
      type: String,
      value: '¥'
    },
    buttonType: {
      type: String,
      value: 'danger'
    }
  },
  computed: {
    hasPrice: function hasPrice() {
      return typeof this.data.price === 'number';
    },
    priceStr: function priceStr() {
      return (this.data.price / 100).toFixed(2);
    },
    tipStr: function tipStr() {
      var tip = this.data.tip;
      return typeof tip === 'string' ? tip : '';
    }
  },
  methods: {
    onSubmit: function onSubmit(event) {
      this.$emit('submit', event.detail);
    }
  }
});
});
define("static/vant/swipe-cell/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _touch = require('../mixins/touch');

var THRESHOLD = 0.15;
(0, _component.VantComponent)({
  props: {
    disabled: Boolean,
    leftWidth: {
      type: Number,
      value: 0
    },
    rightWidth: {
      type: Number,
      value: 0
    },
    asyncClose: Boolean
  },
  mixins: [_touch.touch],
  data: {
    offset: 0,
    draging: false
  },
  computed: {
    wrapperStyle: function wrapperStyle() {
      var _this$data = this.data,
          offset = _this$data.offset,
          draging = _this$data.draging;
      var transform = "translate3d(" + offset + "px, 0, 0)";
      var transition = draging ? 'none' : '.6s cubic-bezier(0.18, 0.89, 0.32, 1)';
      return "\n        -webkit-transform: " + transform + ";\n        -webkit-transition: " + transition + ";\n        transform: " + transform + ";\n        transition: " + transition + ";\n      ";
    }
  },
  methods: {
    onTransitionend: function onTransitionend() {
      this.swipe = false;
    },
    open: function open(position) {
      var _this$data2 = this.data,
          leftWidth = _this$data2.leftWidth,
          rightWidth = _this$data2.rightWidth;
      var offset = position === 'left' ? leftWidth : -rightWidth;
      this.swipeMove(offset);
      this.resetSwipeStatus();
    },
    close: function close() {
      this.set({
        offset: 0
      });
    },
    resetSwipeStatus: function resetSwipeStatus() {
      this.swiping = false;
      this.opened = true;
    },
    swipeMove: function swipeMove(offset) {
      if (offset === void 0) {
        offset = 0;
      }

      this.set({
        offset: offset
      });
      offset && (this.swiping = true);
      !offset && (this.opened = false);
    },
    swipeLeaveTransition: function swipeLeaveTransition(direction) {
      var _this$data3 = this.data,
          offset = _this$data3.offset,
          leftWidth = _this$data3.leftWidth,
          rightWidth = _this$data3.rightWidth;
      var threshold = this.opened ? 1 - THRESHOLD : THRESHOLD; // right

      if (direction > 0 && -offset > rightWidth * threshold && rightWidth > 0) {
        this.open('right'); // left
      } else if (direction < 0 && offset > leftWidth * threshold && leftWidth > 0) {
        this.open('left');
      } else {
        this.swipeMove();
      }
    },
    startDrag: function startDrag(event) {
      if (this.data.disabled) {
        return;
      }

      this.set({
        draging: true
      });
      this.touchStart(event);

      if (this.opened) {
        this.startX -= this.data.offset;
      }
    },
    onDrag: function onDrag(event) {
      if (this.data.disabled) {
        return;
      }

      this.touchMove(event);
      var deltaX = this.deltaX;
      var _this$data4 = this.data,
          leftWidth = _this$data4.leftWidth,
          rightWidth = _this$data4.rightWidth;

      if (deltaX < 0 && (-deltaX > rightWidth || !rightWidth) || deltaX > 0 && (deltaX > leftWidth || deltaX > 0 && !leftWidth)) {
        return;
      }

      if (this.direction === 'horizontal') {
        this.swipeMove(deltaX);
      }
    },
    endDrag: function endDrag() {
      if (this.data.disabled) {
        return;
      }

      this.set({
        draging: false
      });

      if (this.swiping) {
        this.swipeLeaveTransition(this.data.offset > 0 ? -1 : 1);
      }
    },
    onClick: function onClick(event) {
      var _event$currentTarget$ = event.currentTarget.dataset.key,
          position = _event$currentTarget$ === void 0 ? 'outside' : _event$currentTarget$;
      this.$emit('click', position);

      if (!this.data.offset) {
        return;
      }

      if (this.data.asyncClose) {
        this.$emit('close', {
          position: position,
          instance: this
        });
      } else {
        this.swipeMove(0);
      }
    }
  }
});
});
define("static/vant/switch-cell/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  props: {
    title: String,
    border: Boolean,
    checked: Boolean,
    loading: Boolean,
    disabled: Boolean,
    activeColor: String,
    inactiveColor: String,
    size: {
      type: String,
      value: '24px'
    }
  },
  watch: {
    checked: function checked(value) {
      this.set({
        value: value
      });
    }
  },
  created: function created() {
    this.set({
      value: this.data.checked
    });
  },
  methods: {
    onChange: function onChange(event) {
      this.$emit('change', event.detail);
    }
  }
});
});
define("static/vant/switch/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  field: true,
  classes: ['node-class'],
  props: {
    checked: Boolean,
    loading: Boolean,
    disabled: Boolean,
    activeColor: String,
    inactiveColor: String,
    size: {
      type: String,
      value: '30px'
    }
  },
  watch: {
    checked: function checked(value) {
      this.set({
        value: value
      });
    }
  },
  created: function created() {
    this.set({
      value: this.data.checked
    });
  },
  methods: {
    onClick: function onClick() {
      if (!this.data.disabled && !this.data.loading) {
        var checked = !this.data.checked;
        this.$emit('input', checked);
        this.$emit('change', checked);
      }
    }
  }
});
});
define("static/vant/tab/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  relation: {
    name: 'tabs',
    type: 'ancestor'
  },
  props: {
    dot: Boolean,
    info: null,
    title: String,
    disabled: Boolean,
    titleStyle: String
  },
  data: {
    width: null,
    inited: false,
    active: false,
    animated: false
  },
  watch: {
    title: 'update',
    disabled: 'update',
    dot: 'update',
    info: 'update',
    titleStyle: 'update'
  },
  methods: {
    update: function update() {
      var parent = this.getRelationNodes('../tabs/index')[0];

      if (parent) {
        parent.updateTabs();
      }
    }
  }
});
});
define("static/vant/tabbar-item/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    info: null,
    icon: String,
    dot: Boolean
  },
  relation: {
    name: 'tabbar',
    type: 'ancestor'
  },
  data: {
    active: false
  },
  methods: {
    onClick: function onClick() {
      var parent = this.getRelationNodes('../tabbar/index')[0];

      if (parent) {
        parent.onChange(this);
      }

      this.$emit('click');
    },
    setActive: function setActive(_ref) {
      var active = _ref.active,
          color = _ref.color;

      if (this.data.active !== active) {
        this.set({
          active: active,
          color: color
        });
      }
    }
  }
});
});
define("static/vant/tabbar/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _iphonex = require('../mixins/iphonex');

(0, _component.VantComponent)({
  mixins: [_iphonex.iphonex],
  relation: {
    name: 'tabbar-item',
    type: 'descendant',
    linked: function linked(target) {
      var _this = this;

      this.data.items.push(target);
      setTimeout(function () {
        _this.setActiveItem();
      });
    },
    unlinked: function unlinked(target) {
      var _this2 = this;

      this.data.items = this.data.items.filter(function (item) {
        return item !== target;
      });
      setTimeout(function () {
        _this2.setActiveItem();
      });
    }
  },
  props: {
    active: Number,
    activeColor: String,
    fixed: {
      type: Boolean,
      value: true
    },
    zIndex: {
      type: Number,
      value: 1
    }
  },
  data: {
    items: [],
    currentActive: -1
  },
  watch: {
    active: function active(_active) {
      this.set({
        currentActive: _active
      });
      this.setActiveItem();
    }
  },
  created: function created() {
    this.set({
      currentActive: this.data.active
    });
  },
  methods: {
    setActiveItem: function setActiveItem() {
      var _this3 = this;

      this.data.items.forEach(function (item, index) {
        item.setActive({
          active: index === _this3.data.currentActive,
          color: _this3.data.activeColor
        });
      });
    },
    onChange: function onChange(child) {
      var active = this.data.items.indexOf(child);

      if (active !== this.data.currentActive && active !== -1) {
        this.$emit('change', active);
        this.set({
          currentActive: active
        });
        this.setActiveItem();
      }
    }
  }
});
});
define("static/vant/tabs/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _touch = require('../mixins/touch');

(0, _component.VantComponent)({
  mixins: [_touch.touch],
  relation: {
    name: 'tab',
    type: 'descendant',
    linked: function linked(child) {
      this.child.push(child);
      this.updateTabs(this.data.tabs.concat(child.data));
    },
    unlinked: function unlinked(child) {
      var index = this.child.indexOf(child);
      var tabs = this.data.tabs;
      tabs.splice(index, 1);
      this.child.splice(index, 1);
      this.updateTabs(tabs);
    }
  },
  props: {
    color: String,
    sticky: Boolean,
    animated: Boolean,
    swipeable: Boolean,
    lineWidth: {
      type: Number,
      value: -1
    },
    lineHeight: {
      type: Number,
      value: -1
    },
    active: {
      type: Number,
      value: 0
    },
    type: {
      type: String,
      value: 'line'
    },
    border: {
      type: Boolean,
      value: true
    },
    duration: {
      type: Number,
      value: 0.3
    },
    zIndex: {
      type: Number,
      value: 1
    },
    swipeThreshold: {
      type: Number,
      value: 4
    },
    offsetTop: {
      type: Number,
      value: 0
    },
    scrollTop: {
      type: Number,
      value: 0
    }
  },
  data: {
    tabs: [],
    lineStyle: '',
    scrollLeft: 0,
    scrollable: false,
    trackStyle: '',
    wrapStyle: '',
    position: ''
  },
  watch: {
    swipeThreshold: function swipeThreshold() {
      this.set({
        scrollable: this.child.length > this.data.swipeThreshold
      });
    },
    color: 'setLine',
    lineWidth: 'setLine',
    lineHeight: 'setLine',
    active: 'setActiveTab',
    animated: 'setTrack',
    scrollTop: 'onScroll',
    offsetTop: 'setWrapStyle'
  },
  beforeCreate: function beforeCreate() {
    this.child = [];
  },
  mounted: function mounted() {
    this.setLine();
    this.setTrack();
    this.scrollIntoView();
  },
  destroyed: function destroyed() {
    wx.createIntersectionObserver(this).disconnect();
  },
  methods: {
    updateTabs: function updateTabs(tabs) {
      tabs = tabs || this.data.tabs;
      this.set({
        tabs: tabs,
        scrollable: tabs.length > this.data.swipeThreshold
      });
      this.setActiveTab();
    },
    trigger: function trigger(eventName, index) {
      this.$emit(eventName, {
        index: index,
        title: this.data.tabs[index].title
      });
    },
    onTap: function onTap(event) {
      var index = event.currentTarget.dataset.index;

      if (this.data.tabs[index].disabled) {
        this.trigger('disabled', index);
      } else {
        this.trigger('click', index);
        this.setActive(index);
      }
    },
    setActive: function setActive(active) {
      if (active !== this.data.active) {
        this.trigger('change', active);
        this.set({
          active: active
        });
        this.setActiveTab();
      }
    },
    setLine: function setLine() {
      var _this = this;

      if (this.data.type !== 'line') {
        return;
      }

      var _this$data = this.data,
          color = _this$data.color,
          active = _this$data.active,
          duration = _this$data.duration,
          lineWidth = _this$data.lineWidth,
          lineHeight = _this$data.lineHeight;
      this.getRect('.van-tab', true).then(function (rects) {
        var rect = rects[active];
        var width = lineWidth !== -1 ? lineWidth : rect.width / 2;
        var height = lineHeight !== -1 ? "height: " + lineHeight + "px;" : '';
        var left = rects.slice(0, active).reduce(function (prev, curr) {
          return prev + curr.width;
        }, 0);
        left += (rect.width - width) / 2;

        _this.set({
          lineStyle: "\n            " + height + "\n            width: " + width + "px;\n            background-color: " + color + ";\n            -webkit-transform: translateX(" + left + "px);\n            -webkit-transition-duration: " + duration + "s;\n            transform: translateX(" + left + "px);\n            transition-duration: " + duration + "s;\n          "
        });
      });
    },
    setTrack: function setTrack() {
      var _this2 = this;

      var _this$data2 = this.data,
          animated = _this$data2.animated,
          active = _this$data2.active,
          duration = _this$data2.duration;
      if (!animated) return '';
      this.getRect('.van-tabs__content').then(function (rect) {
        var width = rect.width;

        _this2.set({
          trackStyle: "\n            width: " + width * _this2.child.length + "px;\n            left: " + -1 * active * width + "px;\n            transition: left " + duration + "s;\n            display: flex;\n          "
        });

        _this2.setTabsProps({
          width: width,
          animated: animated
        });
      });
    },
    setTabsProps: function setTabsProps(props) {
      this.child.forEach(function (item) {
        item.set(props);
      });
    },
    setActiveTab: function setActiveTab() {
      var _this3 = this;

      this.child.forEach(function (item, index) {
        var data = {
          active: index === _this3.data.active
        };

        if (data.active) {
          data.inited = true;
        }

        if (data.active !== item.data.active) {
          item.set(data);
        }
      });
      this.set({}, function () {
        _this3.setLine();

        _this3.setTrack();

        _this3.scrollIntoView();
      });
    },
    // scroll active tab into view
    scrollIntoView: function scrollIntoView() {
      var _this4 = this;

      if (!this.data.scrollable) {
        return;
      }

      this.getRect('.van-tab', true).then(function (tabRects) {
        var tabRect = tabRects[_this4.data.active];
        var offsetLeft = tabRects.slice(0, _this4.data.active).reduce(function (prev, curr) {
          return prev + curr.width;
        }, 0);
        var tabWidth = tabRect.width;

        _this4.getRect('.van-tabs__nav').then(function (navRect) {
          var navWidth = navRect.width;

          _this4.set({
            scrollLeft: offsetLeft - (navWidth - tabWidth) / 2
          });
        });
      });
    },
    onTouchStart: function onTouchStart(event) {
      if (!this.data.swipeable) return;
      this.touchStart(event);
    },
    onTouchMove: function onTouchMove(event) {
      if (!this.data.swipeable) return;
      this.touchMove(event);
    },
    // watch swipe touch end
    onTouchEnd: function onTouchEnd() {
      if (!this.data.swipeable) return;
      var _this$data3 = this.data,
          active = _this$data3.active,
          tabs = _this$data3.tabs;
      var direction = this.direction,
          deltaX = this.deltaX,
          offsetX = this.offsetX;
      var minSwipeDistance = 50;

      if (direction === 'horizontal' && offsetX >= minSwipeDistance) {
        if (deltaX > 0 && active !== 0) {
          this.setActive(active - 1);
        } else if (deltaX < 0 && active !== tabs.length - 1) {
          this.setActive(active + 1);
        }
      }
    },
    setWrapStyle: function setWrapStyle() {
      var _this$data4 = this.data,
          offsetTop = _this$data4.offsetTop,
          position = _this$data4.position;
      var wrapStyle;

      switch (position) {
        case 'top':
          wrapStyle = "\n            top: " + offsetTop + "px;\n            position: fixed;\n          ";
          break;

        case 'bottom':
          wrapStyle = "\n            top: auto;\n            bottom: 0;\n          ";
          break;

        default:
          wrapStyle = '';
      } // cut down `set`


      if (wrapStyle === this.data.wrapStyle) return;
      this.set({
        wrapStyle: wrapStyle
      });
    },
    // adjust tab position
    onScroll: function onScroll(scrollTop) {
      var _this5 = this;

      if (!this.data.sticky) return;
      var offsetTop = this.data.offsetTop;
      this.getRect('.van-tabs').then(function (rect) {
        var top = rect.top,
            height = rect.height;

        _this5.getRect('.van-tabs__wrap').then(function (rect) {
          var wrapHeight = rect.height;
          var position = '';

          if (offsetTop > top + height - wrapHeight) {
            position = 'bottom';
          } else if (offsetTop > top) {
            position = 'top';
          }

          _this5.$emit('scroll', {
            scrollTop: scrollTop + offsetTop,
            isFixed: position === 'top'
          });

          if (position !== _this5.data.position) {
            _this5.set({
              position: position
            }, function () {
              _this5.setWrapStyle();
            });
          }
        });
      });
    }
  }
});
});
define("static/vant/tag/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _color = require('../common/color');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_COLOR = '#999';
var COLOR_MAP = {
  danger: _color.RED,
  primary: _color.BLUE,
  success: _color.GREEN
};
(0, _component.VantComponent)({
  props: {
    size: String,
    type: String,
    mark: Boolean,
    color: String,
    plain: Boolean,
    round: Boolean,
    textColor: String
  },
  computed: {
    style: function style() {
      var color = this.data.color || COLOR_MAP[this.data.type] || DEFAULT_COLOR;
      var key = this.data.plain ? 'color' : 'background-color';
      var style = _defineProperty({}, key, color);

      if (this.data.textColor) {
        style.color = this.data.textColor;
      }

      return Object.keys(style).map(function (key) {
        return key + ": " + style[key];
      }).join(';');
    }
  }
});
});
define("static/vant/toast/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

(0, _component.VantComponent)({
  props: {
    show: Boolean,
    mask: Boolean,
    message: String,
    forbidClick: Boolean,
    zIndex: {
      type: Number,
      value: 1000
    },
    type: {
      type: String,
      value: 'text'
    },
    loadingType: {
      type: String,
      value: 'circular'
    },
    position: {
      type: String,
      value: 'middle'
    }
  },
  methods: {
    clear: function clear() {
      this.set({
        show: false
      });
    },
    // for prevent touchmove
    noop: function noop() {}
  }
});
});
define("static/vant/toast/toast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _utils = require('../common/utils');

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }return target;
  };return _extends.apply(this, arguments);
}

var defaultOptions = {
  type: 'text',
  mask: false,
  message: '',
  show: true,
  zIndex: 1000,
  duration: 3000,
  position: 'middle',
  forbidClick: false,
  loadingType: 'circular',
  selector: '#van-toast'
};
var queue = [];

var currentOptions = _extends({}, defaultOptions);

function parseOptions(message) {
  return (0, _utils.isObj)(message) ? message : {
    message: message
  };
}

function getContext() {
  var pages = getCurrentPages();
  return pages[pages.length - 1];
}

var Toast = function Toast(options) {
  if (options === void 0) {
    options = {};
  }

  options = _extends({}, currentOptions, parseOptions(options));
  var context = options.context || getContext();
  var toast = context.selectComponent(options.selector);

  if (!toast) {
    console.warn('未找到 van-toast 节点，请确认 selector 及 context 是否正确');
    return;
  }

  delete options.context;
  delete options.selector;
  queue.push(toast);
  toast.set(options);
  clearTimeout(toast.timer);

  if (options.duration > 0) {
    toast.timer = setTimeout(function () {
      toast.clear();
      queue = queue.filter(function (item) {
        return item !== toast;
      });
    }, options.duration);
  }

  return toast;
};

var createMethod = function createMethod(type) {
  return function (options) {
    return Toast(_extends({
      type: type
    }, parseOptions(options)));
  };
};

['loading', 'success', 'fail'].forEach(function (method) {
  Toast[method] = createMethod(method);
});

Toast.clear = function () {
  queue.forEach(function (toast) {
    toast.clear();
  });
  queue = [];
};

Toast.setDefaultOptions = function (options) {
  Object.assign(currentOptions, options);
};

Toast.resetDefaultOptions = function () {
  currentOptions = _extends({}, defaultOptions);
};

exports.default = Toast;
});
define("static/vant/transition/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var _transition = require('../mixins/transition');

(0, _component.VantComponent)({
  mixins: [(0, _transition.transition)(true)],
  props: {
    name: {
      type: String,
      value: 'fade'
    }
  }
});
});
define("static/vant/tree-select/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _component = require('../common/component');

var ITEM_HEIGHT = 44;
(0, _component.VantComponent)({
  classes: ['main-item-class', 'content-item-class', 'main-active-class', 'content-active-class', 'main-disabled-class', 'content-disabled-class'],
  props: {
    items: Array,
    mainActiveIndex: {
      type: Number,
      value: 0
    },
    activeId: {
      type: [Number, String]
    },
    maxHeight: {
      type: Number,
      value: 300
    }
  },
  data: {
    subItems: [],
    mainHeight: 0,
    itemHeight: 0
  },
  watch: {
    items: function items() {
      var _this = this;

      this.updateSubItems().then(function () {
        _this.updateMainHeight();
      });
    },
    maxHeight: function maxHeight() {
      this.updateItemHeight(this.data.subItems);
      this.updateMainHeight();
    },
    mainActiveIndex: 'updateSubItems'
  },
  methods: {
    // 当一个子项被选择时
    onSelectItem: function onSelectItem(event) {
      var item = event.currentTarget.dataset.item;

      if (!item.disabled) {
        this.$emit('click-item', item);
      }
    },
    // 当一个导航被点击时
    onClickNav: function onClickNav(event) {
      var index = event.currentTarget.dataset.index;
      var item = this.data.items[index];

      if (!item.disabled) {
        this.$emit('click-nav', {
          index: index
        });
      }
    },
    // 更新子项列表
    updateSubItems: function updateSubItems() {
      var _this$data = this.data,
          items = _this$data.items,
          mainActiveIndex = _this$data.mainActiveIndex;

      var _ref = items[mainActiveIndex] || {},
          _ref$children = _ref.children,
          children = _ref$children === void 0 ? [] : _ref$children;

      this.updateItemHeight(children);
      return this.set({
        subItems: children
      });
    },
    // 更新组件整体高度，根据最大高度和当前组件需要展示的高度来决定
    updateMainHeight: function updateMainHeight() {
      var _this$data2 = this.data,
          _this$data2$items = _this$data2.items,
          items = _this$data2$items === void 0 ? [] : _this$data2$items,
          _this$data2$subItems = _this$data2.subItems,
          subItems = _this$data2$subItems === void 0 ? [] : _this$data2$subItems;
      var maxHeight = Math.max(items.length * ITEM_HEIGHT, subItems.length * ITEM_HEIGHT);
      this.set({
        mainHeight: Math.min(maxHeight, this.data.maxHeight)
      });
    },
    // 更新子项列表高度，根据可展示的最大高度和当前子项列表的高度决定
    updateItemHeight: function updateItemHeight(subItems) {
      var itemHeight = Math.min(subItems.length * ITEM_HEIGHT, this.data.maxHeight);
      return this.set({
        itemHeight: itemHeight
      });
    }
  }
});
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("./common/manifest.js");
require("./common/vendor.js");
global.webpackJsonpMpvue([1], {

  /***/27:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__Net_js__ = __webpack_require__(49);

    var BASEURL = 'https://soil-mall.daqiuyin.com';

    var API = {
      // 获取openId
      getOpenId: function getOpenId(params) {
        var url = BASEURL + '/routine/member/permission';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 查看抬头列表
      invoiceList: function invoiceList(params) {
        var url = BASEURL + '/routine/invoice/invoiceExist';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 保存发票抬头
      invoiceSave: function invoiceSave(params) {
        var url = BASEURL + '/routine/invoice/save';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 发票抬头回显
      inoviceInfo: function inoviceInfo(params) {
        var url = BASEURL + '/routine/invoice/inoviceInfo';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 删除发票信息
      inoviceDelete: function inoviceDelete(params) {
        var url = BASEURL + '/routine/invoice/delete';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 查询分类
      category: function category(params) {
        var url = BASEURL + '/routine/category/category';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 查询分类
      findPackage: function findPackage(params) {
        var url = BASEURL + '/routine/category/findPackage';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 下单
      orderSave: function orderSave(params) {
        var url = BASEURL + '/routine/order/save';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 订单列表
      orderList: function orderList(params) {
        var url = BASEURL + '/routine/order/orderList';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 待付款多笔订单一次支付
      wxPayGuaranteeFeeCheck: function wxPayGuaranteeFeeCheck(params) {
        var url = BASEURL + '/routine/wxpay/wxPayGuaranteeFeeCheck';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 计算价格
      caculate: function caculate(params) {
        var url = BASEURL + '/routine/category/caculate';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 提交样本
      commitSample: function commitSample(params) {
        var url = BASEURL + '/routine/order/commitSample';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 我的报告列表
      reportList: function reportList(params) {
        var url = BASEURL + '/routine/order/reportList';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 未开发票列表
      unInvoiceList: function unInvoiceList(params) {
        var url = BASEURL + '/routine/order/unInvoiceList';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 合并订单开发票
      unionInvoice: function unionInvoice(params) {
        var url = BASEURL + '/routine/order/unionInvoice';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 合并订单时计算合并后发票金额
      unInvoiceCaculate: function unInvoiceCaculate(params) {
        var url = BASEURL + '/routine/order/caculate';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 订单详情
      orderDetail: function orderDetail(params) {
        var url = BASEURL + '/routine/order/orderInfo';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 首页
      home: function home(params) {
        var url = BASEURL + '/routine/category/crop';
        return __WEBPACK_IMPORTED_MODULE_0__Net_js__["a" /* default */].request(url, params);
      },

      // 下载PDF
      downloadPDF: function downloadPDF(params) {
        var url = BASEURL + '/routine/order/downloadPDF?id=' + params.id;
        return url;
      }
    };

    /* harmony default export */__webpack_exports__["a"] = API;

    /***/
  },

  /***/41:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__ = __webpack_require__(18);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__ = __webpack_require__(85);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__ = __webpack_require__(27);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_3_onfire_js__ = __webpack_require__(86);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_3_onfire_js___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_onfire_js__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_4__utils_const__ = __webpack_require__(42);

    var NJKit = {
      state: {
        token: '',
        status: '',
        isLogin: false
      },

      getToken: function getToken() {
        return this.state.token;
      },
      isLogin: function isLogin() {
        return this.state.isLogin;
      },

      // 存Token
      setToken: function setToken(tk) {
        var _this = this;

        console.log('token___________', tk);
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].setValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].TOKEN_KEY, tk).then(function (success) {
            _this.state.token = tk;
            _this.state.isLogin = true;
            console.log('write token =>', _this.state.token);
            console.log('isLogin =>', _this.state.isLogin);
            resolve(tk);
          }, function (failure) {
            console.log('保存失败');
            reject(failure);
          });
        });
      },

      // 取Token
      readToken: function readToken() {
        var _this2 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].getValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].TOKEN_KEY).then(function (success) {
            _this2.state.token = success;
            _this2.state.isLogin = true;
            resolve(success);
            console.log('read token =>', _this2.state.token);
            console.log('isLogin =>', _this2.state.isLogin);
          }, function (failure) {
            console.log('读取失败');
            reject(failure);
          });
        });
      },

      // 删除Token
      deleteToken: function deleteToken() {
        var _this3 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].delValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].TOKEN_KEY).then(function (success) {
            console.log('删除成功 ->', success);
            _this3.state.token = '';
            _this3.state.isLogin = false;
            resolve(success);
          }, function (failure) {
            console.log('删除失败 ->', failure);
            reject(failure);
          });
        });
      },

      // 存用户类型 商户/个人
      setStatus: function setStatus(type) {
        var _this4 = this;

        console.log('type___________', type);
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].setValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].STATUS_KEY, type).then(function (success) {
            _this4.state.status = type;
            console.log('write status =>', _this4.state.status);
            resolve(type);
          }, function (failure) {
            console.log('保存失败');
            reject(failure);
          });
        });
      },

      // 取Status
      readStatus: function readStatus() {
        var _this5 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].getValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].STATUS_KEY).then(function (success) {
            _this5.state.status = success;
            console.log('用户类型', _this5.state.status);
            resolve(success);
          }, function (failure) {
            console.log('读取失败');
            reject(failure);
          });
        });
      },

      // 删除Status
      deleteStatus: function deleteStatus() {
        var _this6 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          __WEBPACK_IMPORTED_MODULE_1__NJStorage_js__["a" /* default */].delValue(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].STATUS_KEY).then(function (success) {
            console.log('删除成功 ->', success);
            _this6.state.status = '';
            resolve(success);
          }, function (failure) {
            console.log('删除失败 ->', failure);
            reject(failure);
          });
        });
      },

      // 获取系统
      getOS: function getOS() {
        return 'wx';
      },

      // 微信支付Appkey
      getWXAppKey: function getWXAppKey() {
        // 农鲸首信AppKey
        return 'wx71da55810db19b2d';
      },

      // 获取渠道
      getChannel: function getChannel() {
        return 'DQY';
      },

      // 获取颜色
      getColor: function getColor() {
        return '#d9534f';
      },

      // 版本号
      getVersion: function getVersion() {
        return '1.0.0';
      },

      // Toast
      showToast: function showToast(titles) {
        wx.showToast({
          title: titles,
          icon: 'none',
          duration: 2000
        });
      },

      // loading
      showLoading: function showLoading() {
        var title = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

        wx.showLoading({ title: title });
      },

      // hide loading
      hideLoading: function hideLoading() {
        wx.hideLoading();
      },

      // 取数组
      getArray: function getArray() {
        var currentArray = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

        var array = [];
        currentArray.map(function (item) {
          array.push(item.name);
        });
        return array;
      },

      // 取key
      getKey: function getKey() {
        var currentArray = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        var value = arguments[1];

        var eduV = '';
        currentArray.map(function (item) {
          if (item.name === value) {
            eduV = item.key;
          }
        });
        return eduV;
      },

      // 取value
      getValue: function getValue() {
        var currentArray = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
        var key = arguments[1];

        var eduV = '请选择';
        currentArray.map(function (item) {
          if (item.key === key) {
            eduV = item.name;
          }
        });
        return eduV;
      },

      // 选照片
      selectImages: function selectImages() {
        var imageCount = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          wx.chooseImage({
            count: imageCount,
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success: function success(res) {
              // tempFilePath可以作为img标签的src属性显示图片
              var tempFilePaths = res.tempFilePaths;
              resolve(tempFilePaths[0]);
            },
            fail: function fail(res) {
              reject(res);
            }
          });
        });
      },

      // 七牛上传照片
      QNUploadImage: function QNUploadImage() {
        var _this7 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          var that = _this7;
          _this7.selectImages().then(function (image) {
            that.showLoading();
            __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].imageUpload(image).then(function (succ) {
              that.hideLoading();
              resolve(succ);
            }, function (fail) {
              that.hideLoading();
              reject(fail);
            });
          });
        });
      },

      // 本地上传照片
      LocalUploadImage: function LocalUploadImage() {
        var _this8 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          var that = _this8;
          _this8.selectImages().then(function (image) {
            that.showLoading();
            __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].localImageUpload(image).then(function (succ) {
              that.hideLoading();
              resolve(succ);
            }, function (fail) {
              that.hideLoading();
              reject(fail);
            });
          });
        });
      },

      // OCR上传照片
      OCRUploadImage: function OCRUploadImage() {
        var _this9 = this;

        var side = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'front';

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          var that = _this9;
          // 获取access_token
          __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].ocrGetToken().then(function (tk) {
            // 选择身份证照片
            that.selectImages().then(function (image) {
              that.showLoading('识别中');
              // 照片转base64
              var res = wx.getFileSystemManager().readFileSync(image, 'base64');
              // 上传照片
              __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].orcUpload(res, tk.access_token, side).then(function (succ) {
                that.hideLoading();
                resolve(succ);
              }, function (fail) {
                that.hideLoading();
                reject(fail);
              });
            });
          }, function (e) {
            var error = '网络失败';
            reject(error);
          });
        });
      },

      // OCR识别银行卡
      OCRBankImage: function OCRBankImage() {
        var _this10 = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          var that = _this10;
          // that.showLoading('识别中')
          that.ocrApiBaidu().then(function (success) {
            that.showLoading('识别中');
            // 上传照片
            __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].ocrBank(success.image, success.token).then(function (succ) {
              that.hideLoading();
              console.log('orcUpload =>', succ);
              resolve(succ);
            }, function (fail) {
              that.hideLoading();
              console.log('orcUpload =>', fail);
              reject(fail);
            });
          }, function (failure) {
            reject(failure);
          });
        });
      },
      ocrApiBaidu: function ocrApiBaidu() {
        var that = this;
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          // 获取access_token
          __WEBPACK_IMPORTED_MODULE_2__NJNetAPI__["a" /* default */].ocrGetToken().then(function (tk) {
            var token = tk.access_token;
            // 选择身份证照片
            that.selectImages().then(function (image) {
              // 照片转base64
              var res = wx.getFileSystemManager().readFileSync(image, 'base64');
              var dict = {
                'token': token,
                'image': res
              };
              resolve(dict);
            }, function (fail) {
              reject(fail);
            });
          }, function (e) {
            var error = '网络失败';
            reject(error);
          });
        });
      },

      // 进件状态
      intoPieceStatus: function intoPieceStatus(s) {
        var status = s;
        switch (status) {
          case '-1':
            status = '进件终审中';
            break;
          case '1':
            status = '补全资料中';
            break;
          case '2':
            status = '进件初审中';
            break;
          case '3':
            status = '进件复审中';
            break;
          case '4':
            status = '进件审核未通过';
            break;
          case '5':
            status = '合同制作中';
            break;
          case '6':
            status = '合同初审中';
            break;
          case '7':
            status = '合同复审中';
            break;
          case '8':
            status = '合同审核未通过';
            break;
          case '9':
            status = '待放款';
            break;
          case '10':
            status = '放款复核中';
            break;
          case '11':
            status = '还款中';
            break;
          case '12':
            status = '还款完成';
            break;
          case '13':
            status = '作废';
            break;
        }
        return status;
      },

      // 状态查询状态
      searchStatusValue: function searchStatusValue(s) {
        var status = s;
        switch (status) {
          case '0':
            status = '被拒件';
            break;
          case '1':
            status = '资料补全中';
            break;
          case '2':
            status = '初审中';
            break;
          case '3':
            status = '复审中';
            break;
          case '4':
            status = '保函出具中';
            break;
          case '5':
            status = '资方终审中';
            break;
          case '6':
            status = '合同制作';
            break;
          case '7':
            status = '合同签署';
            break;
          case '8':
            status = '待放款';
            break;
          case '9':
            status = '已放款';
            break;
          case '10':
            status = '还款中';
            break;
          case '11':
            status = '已逾期';
            break;
          case '12':
            status = '已转呆/坏账';
            break;
          case '13':
            status = '还款完成';
            break;
        }
        return status;
      },
      trim: function trim() {
        var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

        return name.replace(/\s+/g, '');
      },
      pop: function pop(url) {
        __WEBPACK_IMPORTED_MODULE_3_onfire_js___default.a.fire(__WEBPACK_IMPORTED_MODULE_4__utils_const__["a" /* KEYS */].GO_BACK_KEY, { 'url': url });
        wx.navigateBack();
      },
      NJPop: function NJPop(key, result) {
        __WEBPACK_IMPORTED_MODULE_3_onfire_js___default.a.fire(key, result);
        wx.navigateBack();
      },
      fire: function fire(key, value) {
        __WEBPACK_IMPORTED_MODULE_3_onfire_js___default.a.fire(key, { 'result': value });
      },
      on: function on(key, res) {
        __WEBPACK_IMPORTED_MODULE_3_onfire_js___default.a.on(key, res);
      }
    };

    /* harmony default export */__webpack_exports__["a"] = NJKit;

    /***/
  },

  /***/43:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__App__ = __webpack_require__(45);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__utils_NJNetAPI__ = __webpack_require__(27);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_3__utils_NJKit__ = __webpack_require__(41);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_4__utils_arrays__ = __webpack_require__(88);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_5__utils_base__ = __webpack_require__(89);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_5__utils_base___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__utils_base__);

    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.productionTip = false;
    __WEBPACK_IMPORTED_MODULE_1__App__["a" /* default */].mpType = 'app';

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__App__["a" /* default */]);
    app.$mount();

    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.API = __WEBPACK_IMPORTED_MODULE_2__utils_NJNetAPI__["a" /* default */];
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.NJKit = __WEBPACK_IMPORTED_MODULE_3__utils_NJKit__["a" /* default */];
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.arrays = __WEBPACK_IMPORTED_MODULE_4__utils_arrays__["a" /* default */];
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_5__utils_base___default.a);

    /***/
  },

  /***/45:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_App_vue__ = __webpack_require__(48);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(46);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */
    var __vue_template__ = null;
    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_App_vue__["a" /* default */], __vue_template__, __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/App.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-19104796", Component.options);
        } else {
          hotAPI.reload("data-v-19104796", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/46:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/48:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    /* harmony default export */
    __webpack_exports__["a"] = {
      created: function created() {
        // 调用API从本地缓存中获取数据
        /*
         * 平台 api 差异的处理方式:  api 方法统一挂载到 mpvue 名称空间, 平台判断通过 mpvuePlatform 特征字符串
         * 微信：mpvue === wx, mpvuePlatform === 'wx'
         * 头条：mpvue === tt, mpvuePlatform === 'tt'
         * 百度：mpvue === swan, mpvuePlatform === 'swan'
         * 支付宝(蚂蚁)：mpvue === my, mpvuePlatform === 'my'
          "pages/index/main", // 首页
          "pages/mine/main", // 我的
          "pages/order/main", // 订单
          "pages/invoceList/main", // 发票列表
          "pages/invoceInfo/main", // 发票
          "pages/packageList/main", // 套餐
          "pages/other/main", // 其它检测
          "pages/customPackage/main", // 自定义检测
          "pages/orderBuy/main", // 下单
          "pages/commitSample/main", // 提交样本
          "pages/reportList/main", // 报告列表
          "pages/unInvoiceList/main" // 开发票
         */

        var logs = void 0;
        if (global.mpvuePlatform === 'my') {
          logs = global.mpvue.getStorageSync({ key: 'logs' }).data || [];
          logs.unshift(Date.now());
          global.mpvue.setStorageSync({
            key: 'logs',
            data: logs
          });
        } else {
          logs = global.mpvue.getStorageSync('logs') || [];
          logs.unshift(Date.now());
          global.mpvue.setStorageSync('logs', logs);
        }
      },
      log: function log() {
        console.log('log at:' + Date.now());
      }
    };

    /***/
  },

  /***/49:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__ = __webpack_require__(18);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__NJKit_js__ = __webpack_require__(41);

    var timeout = 100000;
    var Fly = __webpack_require__(87);
    var fly = new Fly();
    fly.config.timeout = timeout;

    var CONST_LINE = '============网络请求============';

    var Net = {
      request: function request(url, data) {
        var isJson = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

        var config = {
          method: 'POST',
          headers: this.getheaders(isJson),
          timeout: timeout,
          Accept: 'application/json, text/plain, */*'
        };
        console.log(CONST_LINE);
        console.log('request url:', url, 'request data:', data);
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          fly.request(url, data, config).then(function (res) {
            console.log('response data:', res.data);
            console.log(CONST_LINE);
            if (res.status === 200) {
              resolve(res.data);
            } else {
              reject(res.data.message);
            }
          }).catch(function (error) {
            console.log('error =>', error);
            var msg = '网络失败';
            if (error.response && error.response.status) {
              if (typeof error.response.data.message === 'string') {
                msg = error.response.data.message;
              } else {
                msg = '网络故障或服务器错误 #' + error.response.status;
              }
              if (error.response.status === 401) {
                msg = '您的账号已在他处登录，请退出重新登录';
              }
            }
            console.log('response error', msg);
            console.log(CONST_LINE);
            reject(msg);
          });
        });
      },
      getheaders: function getheaders(isJson) {
        var headers = {
          'platform': __WEBPACK_IMPORTED_MODULE_1__NJKit_js__["a" /* default */].getOS(),
          'version': __WEBPACK_IMPORTED_MODULE_1__NJKit_js__["a" /* default */].getVersion(),
          'token': __WEBPACK_IMPORTED_MODULE_1__NJKit_js__["a" /* default */].getToken(),
          'channel': __WEBPACK_IMPORTED_MODULE_1__NJKit_js__["a" /* default */].getChannel(),
          'Content-Type': isJson ? 'application/json;charset=utf-8;' : 'application/x-www-form-urlencoded'
        };
        return headers;
      },
      uploadImage: function uploadImage(url, image, imageName) {
        var _this = this;

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          wx.uploadFile({
            url: url,
            filePath: image,
            name: 'filePath',
            header: _this.getheaders(),
            formData: {
              'token': __WEBPACK_IMPORTED_MODULE_1__NJKit_js__["a" /* default */].getToken()
            },
            success: function success(res) {
              var data = JSON.parse(res.data);
              // console.log('data =>', data)
              resolve(data);
            },
            fail: function fail(err) {
              console.log('error =>', JSON.parse(err));
              reject(JSON.parse(err));
            }
          });
        });
      }
    };

    /* harmony default export */__webpack_exports__["a"] = Net;

    /***/
  },

  /***/85:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__ = __webpack_require__(18);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__);

    var NJStorage = {
      getValue: function getValue(key) {
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          wx.getStorage({
            key: key,
            success: function success(res) {
              resolve(res.data);
            },
            fail: function fail(error) {
              reject(error);
            }
          });
        });
      },
      setValue: function setValue(key) {
        var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          wx.setStorage({
            key: key,
            data: value,
            success: function success(res) {
              resolve(res);
            },
            fail: function fail(res) {
              reject(res);
            }
          });
        });
      },
      delValue: function delValue(key) {
        return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
          wx.removeStorage({
            key: key,
            success: function success(res) {
              resolve(res);
            },
            fail: function fail(res) {
              reject(res);
            }
          });
        });
      }
    };

    /* harmony default export */__webpack_exports__["a"] = NJStorage;

    /***/
  },

  /***/88:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var arrays = {
      HealthArray: [{ 'key': '1', 'name': '很好' }, { 'key': '2', 'name': '一般' }, { 'key': '3', 'name': '有疾病' }],
      EducationArray: [{ 'key': '1', 'name': '初中以下' }, { 'key': '2', 'name': '中专/高中' }, { 'key': '3', 'name': '大专' }, { 'key': '4', 'name': '本科及以上' }],
      HistoryArray: [{ 'key': '1', 'name': '盈亏平衡' }, { 'key': '2', 'name': '略有盈利' }, { 'key': '3', 'name': '较大部分盈利' }, { 'key': '4', 'name': '略有亏损' }],
      ManageTypeArray: [{ 'key': '1', 'name': '化肥' }, { 'key': '2', 'name': '种子' }, { 'key': '3', 'name': '农药' }, { 'key': '4', 'name': '粮食作物' }, { 'key': '5', 'name': '果蔬' }, { 'key': '6', 'name': '肉禽蛋' }],
      HouseArray: [{ 'key': '1', 'name': '在外租房' }, { 'key': '2', 'name': '有农村房屋' }, { 'key': '3', 'name': '自购小产权房/安置房' }, { 'key': '4', 'name': '自购商品房' }],
      HousepowerArray: [{ 'key': '1', 'name': '大产权' }, { 'key': '2', 'name': '小产权/集体产权' }, { 'key': '3', 'name': '无' }],
      MarryArray: [{ 'key': '1', 'name': '已婚' }, { 'key': '2', 'name': '未婚' }, { 'key': '3', 'name': '离异' }, { 'key': '4', 'name': '丧偶' }],
      useArray: [{ 'key': '1', 'name': '小微贷' }, { 'key': '2', 'name': '装修贷' }, { 'key': '3', 'name': '饲料贷' }, { 'key': '4', 'name': '农资贷' }],
      investArray: [{ 'key': '1', 'name': '原始积累' }, { 'key': '2', 'name': '较少部分筹借' }, { 'key': '3', 'name': '较多部分筹借' }],
      typeArray: [{ 'key': '1', 'name': '房贷' }, { 'key': '2', 'name': '车贷' }, { 'key': '3', 'name': '经营贷' }, { 'key': '4', 'name': '农户贷' }],
      livestock: [{ 'key': '1', 'name': '牛' }, { 'key': '2', 'name': '猪' }, { 'key': '3', 'name': '羊' }, { 'key': '4', 'name': '鸡' }, { 'key': '5', 'name': '鱼' }, { 'key': '6', 'name': '其他' }],
      grow: [{ 'key': '1', 'name': '水稻' }, { 'key': '2', 'name': '玉米' }, { 'key': '3', 'name': '小麦' }, { 'key': '4', 'name': '蔬菜' }, { 'key': '5', 'name': '水果' }, { 'key': '6', 'name': '其他' }],
      work: [{ 'key': '1', 'name': '农资销售' }, { 'key': '2', 'name': '批发' }, { 'key': '3', 'name': '饭店等个体经营' }, { 'key': '4', 'name': '上班' }, { 'key': '5', 'name': '其他' }, { 'key': '6', 'name': '其他' }],
      relationArray: [{ 'key': '1', 'name': '配偶' }, { 'key': '2', 'name': '子女' }, { 'key': '3', 'name': '兄弟' }, { 'key': '4', 'name': '父母' }, { 'key': '5', 'name': '其它' }],
      yearArray: [2025, 2024, 2023, 2022, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012],
      montyArray: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      dayArray: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]

    };

    /* harmony default export */__webpack_exports__["a"] = arrays;

    /***/
  },

  /***/89:
  /***/function _(module, exports) {

    exports.install = function (Vue, options) {
      function newLog() {
        var n = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

        console.log('执行成功' + n);
      }
      function getUserOauth(resolve, reject) {
        wx.getSetting({
          success: function success(res) {
            if (res.authSetting['scope.userInfo']) {
              resolve();
            } else {
              reject();
            }
          }
        });
      }
      function getUserInfo(resolve, reject) {
        wx.getUserInfo({
          success: function success(res) {
            resolve(res);
          },
          fail: function fail() {
            reject();
          }
        });
      }
      function wxlogin(resolve, reject) {
        wx.login({
          success: function success(res) {
            resolve(res.code);
          },
          fail: function fail() {
            reject();
          }
        });
      }
      Vue.prototype.text1 = newLog;
      Vue.prototype.text2 = function () {
        console.log('执行成功2');
        return 'abcd';
      };
      // 获取用户信息
      Vue.prototype.getUserInfo = getUserInfo;
      // 获取用户授权状态
      Vue.prototype.getUserOauth = getUserOauth;
      Vue.prototype.wxlogin = wxlogin;
    };

    /***/
  }

}, [43]);
});require("app.js")
var __wxRoute = "pages/index/main", __wxRouteBegin = true;
define("pages/index/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([4], {

  /***/113:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(114);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/114:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(116);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_7c83043e_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(121);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(115);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-7c83043e";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_7c83043e_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/index/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-7c83043e", Component.options);
        } else {
          hotAPI.reload("data-v-7c83043e", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/115:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/116:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__components_hometab__ = __webpack_require__(117);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          dataArray: [],
          oneActive: -1,
          twoActive: -1,
          threeActive: -1,
          twoArray: [],
          threeArray: [],
          packageId: '',
          hasThree: false,
          showPackage: false
        };
      },

      components: {
        hometab: __WEBPACK_IMPORTED_MODULE_1__components_hometab__["a" /* default */]
      },

      methods: {
        fnOneActive: function fnOneActive(index, ev) {
          this.cleanSelected();
          this.oneActive = index;
          var item = this.dataArray[index];
          if (item && item.children) {
            this.twoArray = item.children;
          }
        },
        fnTwoActive: function fnTwoActive(index, ev) {
          this.threeActive = -1;
          this.threeArray = [];
          this.hasThree = false;
          this.showPackage = false;

          this.twoActive = index;
          var item = this.twoArray[index];
          if (item && item.children) {
            this.hasThree = item.children.length > 0;
            this.threeArray = item.children;
          }
          this.fnSelectPackage(item);
        },
        fnThreeActive: function fnThreeActive(index, ev) {
          this.threeActive = index;
          var item = this.threeArray[index];
          if (item && item.children) {
            this.fnSelectPackage(item);
          }
        },
        fnSelectPackage: function fnSelectPackage(item) {
          if (item && item.children) {
            this.showPackage = item.children.length === 0;
            if (item.children.length === 0) {
              this.packageId = item.id;
            }
          }
        },
        actionClick: function actionClick() {
          var dict = {
            'id': this.packageId,
            'type': '1',
            'custom': false
          };
          var url = '../packageList/main?dict=' + __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(dict);
          wx.navigateTo({ url: url });
        },
        cleanSelected: function cleanSelected() {
          this.oneActive = -1;
          this.twoActive = -1;
          this.threeActive = -1;
          this.twoArray = [];
          this.threeArray = [];
          this.hasThree = false;
          this.showPackage = false;
        },
        getToken: function getToken() {
          var that = this;
          this.wxlogin(function (code) {
            var dict = {
              'code': code
            };
            that.API.getOpenId(dict).then(function (success) {
              that.NJKit.setToken(success.openid).then(function (succ) {
                console.log('存成功', succ);
              });
            }, function (fail) {
              console.log('failure =>', fail);
            });
          }, function (failure) {
            console.log('failure', failure);
          });
        },
        getJSON: function getJSON() {
          var that = this;
          this.NJKit.readToken().then(function (success) {
            console.log('open id =>', success);
          }, function (failure) {
            that.getToken();
          });
        },
        refresh: function refresh() {
          var that = this;
          this.NJKit.showLoading();
          this.API.home({}).then(function (success) {
            that.NJKit.hideLoading();
            wx.stopPullDownRefresh();
            that.dataArray = success.data;
            that.loadViews();
          }, function (failure) {
            wx.stopPullDownRefresh();
            that.dataArray = [];
            that.NJKit.hideLoading();
            that.NJKit.showToast(failure);
          });
        },
        loadViews: function loadViews() {
          this.fnOneActive(0);
          this.fnTwoActive(0);
          this.fnThreeActive(0);
        }
      },
      onLoad: function onLoad(options) {
        if (options.q) {
          var getQuery = decodeURIComponent(options.q);
          var channelId = getQuery.split('https://soil-mall.daqiuyin.com/')[1];
          var that = this;
          this.wxlogin(function (code) {
            var dict = {
              'code': code,
              'channelId': channelId
            };
            that.API.getOpenId(dict).then(function (success) {
              console.log('success', success);
            }, function (fail) {
              console.log('failure =>', fail);
            });
          }, function (failure) {
            console.log('code', failure);
          });
        }
        this.getJSON();
        this.refresh();
      },
      onPullDownRefresh: function onPullDownRefresh() {
        this.cleanSelected();
        this.refresh();
      },
      onShow: function onShow() {
        this.loadViews();
      }
    };

    /***/
  },

  /***/117:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_hometab_vue__ = __webpack_require__(119);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_156664d9_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_hometab_vue__ = __webpack_require__(120);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(118);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_hometab_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_156664d9_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_hometab_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/components/hometab.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] hometab.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-156664d9", Component.options);
        } else {
          hotAPI.reload("data-v-156664d9", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/118:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/119:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //

    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {};
      },

      props: ['item'],
      methods: {},
      onLoad: function onLoad(options) {
        console.log('item =>', options);
      }
    };

    /***/
  },

  /***/120:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('div', {
        staticClass: "home_tabs_item"
      }, [_vm._v("\n  " + _vm._s(_vm.item.name) + "\n")]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-156664d9", esExports);
      }
    }

    /***/
  },

  /***/121:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "categoryStyle"
      }, [_c('div', {
        staticClass: "tab_title"
      }, [_vm._v("请选择种植类型")]), _vm._v(" "), _c('div', {
        staticClass: "categoryClass"
      }, _vm._l(_vm.dataArray, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          class: _vm.oneActive === index ? 'categoryItemActive' : 'categoryItem',
          attrs: {
            "data-id": index,
            "eventid": '0_' + index
          },
          on: {
            "click": function click($event) {
              _vm.fnOneActive(index, $event);
            }
          }
        }, [_vm._v("\n          " + _vm._s(item.name) + "\n        ")])]);
      }))]), _vm._v(" "), _c('view', {
        staticClass: "categoryStyle"
      }, [_c('div', {
        staticClass: "tab_title"
      }, [_vm._v("请选检测种类")]), _vm._v(" "), _c('div', {
        staticClass: "categoryClass"
      }, _vm._l(_vm.twoArray, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          class: _vm.twoActive === index ? 'categoryItemActive' : 'categoryItem',
          attrs: {
            "data-id": index,
            "eventid": '1_' + index
          },
          on: {
            "click": function click($event) {
              _vm.fnTwoActive(index, $event);
            }
          }
        }, [_vm._v("\n          " + _vm._s(item.name) + "\n        ")])]);
      }))]), _vm._v(" "), _vm.hasThree ? _c('block', [_c('view', {
        staticClass: "categoryStyle"
      }, [_c('div', {
        staticClass: "tab_title"
      }, [_vm._v("请选择种植介质")]), _vm._v(" "), _c('div', {
        staticClass: "categoryClass"
      }, _vm._l(_vm.threeArray, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          class: _vm.threeActive === index ? 'categoryItemActive' : 'categoryItem',
          attrs: {
            "data-id": index,
            "eventid": '2_' + index
          },
          on: {
            "click": function click($event) {
              _vm.fnThreeActive(index, $event);
            }
          }
        }, [_vm._v("\n            " + _vm._s(item.name) + "\n          ")])]);
      }))])]) : _vm._e(), _vm._v(" "), _vm.showPackage ? _c('block', [_c('button', {
        staticClass: "btnClass",
        attrs: {
          "type": "default",
          "eventid": '3'
        },
        on: {
          "click": _vm.actionClick
        }
      }, [_vm._v("确定")])], 1) : _vm._e()], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-7c83043e", esExports);
      }
    }

    /***/
  }

}, [113]);
});require("pages/index/main.js")
var __wxRoute = "pages/mine/main", __wxRouteBegin = true;
define("pages/mine/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([18], {

  /***/145:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(146);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/146:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(148);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_49008ebd_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(149);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(147);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-49008ebd";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_49008ebd_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/mine/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-49008ebd", Component.options);
        } else {
          hotAPI.reload("data-v-49008ebd", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/147:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/148:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          userInfo: {},
          hasUserInfo: false,
          canIUse: wx.canIUse('button.open-type.getUserInfo')
        };
      },

      components: {},

      methods: {
        actionService: function actionService() {
          var url = '../service/main';
          wx.navigateTo({ url: url });
        },
        getJSON: function getJSON() {
          var that = this;
          this.API.home().then(function (success) {
            that.selectActive(success.data);
          }, function (failure) {
            console.log('failure =>', failure);
          });
        },
        makePhoneCall: function makePhoneCall() {
          wx.makePhoneCall({
            phoneNumber: '0871-67354002'
          });
        },
        actionInvoiceTitle: function actionInvoiceTitle() {
          var url = '../invoceList/main';
          console.log('url =>', url);
          wx.navigateTo({ url: url });
        },
        actionPdf: function actionPdf() {
          var url = '../reportList/main';
          wx.navigateTo({ url: url });
        },
        actionInvoiceList: function actionInvoiceList() {
          var url = '../unInvoiceList/main';
          wx.navigateTo({ url: url });
        },
        actionContactus: function actionContactus() {
          var url = '../contactus/main';
          wx.navigateTo({ url: url });
        },
        actionClick: function actionClick() {
          var t = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

          switch (t) {
            case '我的报告':
              this.actionPdf();
              break;
            case '申请开票':
              this.actionInvoiceList();
              break;
            case '发票抬头':
              this.actionInvoiceTitle();
              break;
            case '服务介绍':
              this.actionService();
              break;
            case '联系我们':
              this.actionContactus();
              break;
          }
        }
      },
      onLoad: function onLoad() {}
    };

    /***/
  },

  /***/149:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "mine_header"
      }, [_c('view', {
        staticClass: "userinfo-avatar"
      }, [_c('open-data', {
        attrs: {
          "type": "userAvatarUrl",
          "background-size": "cover",
          "mpcomid": '0'
        }
      })], 1), _vm._v(" "), _c('open-data', {
        staticClass: "userinfo-nickname",
        attrs: {
          "type": "userNickName",
          "mpcomid": '1'
        }
      })], 1), _vm._v(" "), _c('view', {
        staticClass: "mine_content"
      }, [_c('van-cell-group', {
        attrs: {
          "mpcomid": '7'
        }
      }, [_c('van-cell', {
        attrs: {
          "title": "我的报告",
          "is-link": "",
          "eventid": '0',
          "mpcomid": '2'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('我的报告');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "申请开票",
          "is-link": "",
          "eventid": '1',
          "mpcomid": '3'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('申请开票');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "发票抬头",
          "is-link": "",
          "eventid": '2',
          "mpcomid": '4'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('发票抬头');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "服务介绍",
          "is-link": "",
          "eventid": '3',
          "mpcomid": '5'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('服务介绍');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "联系我们",
          "is-link": "",
          "eventid": '4',
          "mpcomid": '6'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('联系我们');
          }
        }
      })], 1)], 1), _vm._v(" "), _c('view', {
        staticClass: "bottom",
        attrs: {
          "eventid": '5'
        },
        on: {
          "click": _vm.makePhoneCall
        }
      }, [_c('text', {
        staticClass: "bottomTitle"
      }, [_vm._v("检测热线 0871-67354002")])])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-49008ebd", esExports);
      }
    }

    /***/
  }

}, [145]);
});require("pages/mine/main.js")
var __wxRoute = "pages/order/main", __wxRouteBegin = true;
define("pages/order/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([17], {

  /***/150:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(151);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/151:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(153);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_bc7b108c_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(154);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(152);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-bc7b108c";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_bc7b108c_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/order/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-bc7b108c", Component.options);
        } else {
          hotAPI.reload("data-v-bc7b108c", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/152:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/153:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          floorPrice: 0,
          status: 0,
          dataArray: []
        };
      },

      components: {},

      methods: {
        actionDetail: function actionDetail(item) {
          var url = '../orderDetail/main?id=' + item.id;
          wx.navigateTo({ url: url });
        },
        actionCommitSample: function actionCommitSample(item) {
          var url = '../commitSample/main?id=' + item.id;
          wx.navigateTo({ url: url });
        },
        actionPay: function actionPay(isArr, orderId) {
          var that = this;
          var orderIds = [];
          if (isArr) {
            this.dataArray.map(function (item) {
              if (item.checked) {
                orderIds.push(item.id);
              }
            });
          } else {
            orderIds.push(orderId);
          }

          var dict = {
            'openId': this.NJKit.getToken(),
            'orderIds': orderIds.join(',')
          };
          this.NJKit.showLoading();
          this.API.wxPayGuaranteeFeeCheck(dict).then(function (succ) {
            that.NJKit.hideLoading();
            console.log('支付 =>', succ);
            wx.requestPayment({
              timeStamp: succ.data.timeStamp,
              nonceStr: succ.data.nonceStr,
              package: succ.data.package,
              signType: succ.data.signType,
              paySign: succ.data.paySign,
              success: function success(res) {
                that.NJKit.showToast('支付成功');
                console.log('success =>', res);
              },
              fail: function fail(res) {
                that.NJKit.showToast('支付失败');
                console.log('failure =>', res);
              }
            });
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        checkboxChange: function checkboxChange(e) {
          var idsArr = e.mp.detail.value;
          for (var i = 0; i < this.dataArray.length; i++) {
            var item = this.dataArray[i];
            if (idsArr.indexOf(item.id) !== -1) {
              this.dataArray[i].checked = true;
            } else {
              this.dataArray[i].checked = false;
            }
          }
          this.calcPrice();
        },
        calcPrice: function calcPrice() {
          var price = 0;
          for (var i = 0; i < this.dataArray.length; i++) {
            var item = this.dataArray[i];
            if (item.checked) {
              price += item.capital;
            }
          }
          this.floorPrice = price;
        },
        changeStatus: function changeStatus(ev) {
          this.status = ev.mp.detail.index;
          console.log('status =>', this.status);
          var type = ev.mp.detail.index + 1;
          this.getJSON(type);
          this.floorPrice = 0;
        },
        getJSON: function getJSON() {
          var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

          var that = this;
          var dict = {
            'type': type,
            'openId': this.NJKit.getToken()
          };
          this.NJKit.showLoading();
          this.API.orderList(dict).then(function (success) {
            that.NJKit.hideLoading();
            that.dataArray = success.data;
          }, function (failure) {
            that.NJKit.hideLoading();
            that.dataArray = [];
            console.log('failure =>', failure);
          });
        }
      },
      onShow: function onShow() {
        this.status = 0;
        this.dataArray = [];
        this.getJSON();
        this.floorPrice = 0;
      }
    };

    /***/
  },

  /***/154:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "top"
      }, [_c('van-tabs', {
        attrs: {
          "color": "#4ad4d4",
          "active": _vm.status,
          "sticky": "",
          "eventid": '0',
          "mpcomid": '6'
        },
        on: {
          "change": _vm.changeStatus
        }
      }, [_c('van-tab', {
        attrs: {
          "title": "待付款",
          "mpcomid": '0'
        }
      }), _vm._v(" "), _c('van-tab', {
        attrs: {
          "title": "待送样",
          "mpcomid": '1'
        }
      }), _vm._v(" "), _c('van-tab', {
        attrs: {
          "title": "送样中",
          "mpcomid": '2'
        }
      }), _vm._v(" "), _c('van-tab', {
        attrs: {
          "title": "待检测",
          "mpcomid": '3'
        }
      }), _vm._v(" "), _c('van-tab', {
        attrs: {
          "title": "已完成",
          "mpcomid": '4'
        }
      }), _vm._v(" "), _c('van-tab', {
        attrs: {
          "title": "全部",
          "mpcomid": '5'
        }
      })], 1), _vm._v(" "), _vm.status === 0 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_c('checkbox-group', {
        attrs: {
          "eventid": '1',
          "mpcomid": '7'
        },
        on: {
          "change": _vm.checkboxChange
        }
      }, _vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('checkbox', {
          staticClass: "check-item",
          attrs: {
            "value": item.id,
            "checked": item.checked
          }
        }), _vm._v(" "), _c('text', {
          staticClass: "orderState"
        }, [_vm._v("待付款")])], 1), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])])])]);
      })), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 1), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('view', {
        staticClass: "btnClass"
      }, [_c('label', {
        staticClass: "priceCheckbox"
      }, [_c('text', {
        staticClass: "totalPrice"
      }, [_vm._v("合计￥" + _vm._s(_vm.floorPrice))])]), _vm._v(" "), _c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '2'
        },
        on: {
          "click": function click($event) {
            _vm.actionPay(true);
          }
        }
      }, [_vm._v("立即支付")])], 1)])]) : _vm._e(), _vm._v(" "), _vm.status === 1 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderState"
        }, [_vm._v("待送样")])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '3_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionCommitSample(item);
            }
          }
        }, [_vm._v("提交样本")]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2)]) : _vm._e(), _vm._v(" "), _vm.status === 2 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderState"
        }, [_vm._v("送样中")])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '4_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionDetail(item);
            }
          }
        }, [_vm._v("详情")]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2)]) : _vm._e(), _vm._v(" "), _vm.status === 3 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderState"
        }, [_vm._v("待检测")])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '5_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionDetail(item);
            }
          }
        }, [_vm._v("详情")]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2)]) : _vm._e(), _vm._v(" "), _vm.status === 4 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderState"
        }, [_vm._v("已完成")])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '6_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionDetail(item);
            }
          }
        }, [_vm._v("详情")]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2)]) : _vm._e(), _vm._v(" "), _vm.status === 5 ? _c('block', [_c('view', {
        staticClass: "container"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), item.status === 1 ? _c('block', [_c('text', {
          staticClass: "orderState"
        }, [_vm._v("待付款")])]) : item.status === 2 ? _c('block', [_c('text', {
          staticClass: "orderState"
        }, [_vm._v("待送样")])]) : item.status === 3 ? _c('block', [_c('text', {
          staticClass: "orderState"
        }, [_vm._v("送样中")])]) : item.status === 4 ? _c('block', [_c('text', {
          staticClass: "orderState"
        }, [_vm._v("待检测")])]) : item.status === 5 ? _c('block', [_c('text', {
          staticClass: "orderState"
        }, [_vm._v("已完成")])]) : _vm._e()], 1), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [item.status === 1 ? _c('block', [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '7_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionPay(false, item.id);
            }
          }
        }, [_vm._v("支付")])], 1) : item.status === 2 ? _c('block', [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '8_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionCommitSample(item);
            }
          }
        }, [_vm._v("提交样本")])], 1) : _c('block', [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '9_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionDetail(item);
            }
          }
        }, [_vm._v("详情")])], 1), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2)]) : _vm._e()], 1)]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-bc7b108c", esExports);
      }
    }

    /***/
  }

}, [150]);
});require("pages/order/main.js")
var __wxRoute = "pages/invoceList/main", __wxRouteBegin = true;
define("pages/invoceList/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([3], {

  /***/127:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(128);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/128:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(130);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_3c14a1a8_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(135);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(129);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-3c14a1a8";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_3c14a1a8_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/invoceList/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-3c14a1a8", Component.options);
        } else {
          hotAPI.reload("data-v-3c14a1a8", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/129:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/130:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__components_invoceListCell__ = __webpack_require__(131);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_2__utils_const__ = __webpack_require__(42);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          isSelect: false,
          dataArray: []
        };
      },

      components: {
        invoceListCell: __WEBPACK_IMPORTED_MODULE_1__components_invoceListCell__["a" /* default */]
      },

      methods: {
        actionSelect: function actionSelect(item, index) {
          if (this.isSelect) {
            console.log('选择发票');
            this.NJKit.fire(__WEBPACK_IMPORTED_MODULE_2__utils_const__["a" /* KEYS */].SELECT_INVOCE, __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(item));
            wx.navigateBack();
          } else {
            console.log('编辑发票');
            var url = '../invoceInfo/main?json=' + __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(item);
            wx.navigateTo({ url: url });
          }
        },
        getJSON: function getJSON() {
          var that = this;
          var dict = {
            'openId': this.NJKit.getToken()
          };
          this.NJKit.showLoading();
          that.API.invoiceList(dict).then(function (success) {
            that.NJKit.hideLoading();
            console.log('success =>', success);
            that.dataArray = success.data;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        actionClick: function actionClick() {
          console.log('添加发票');
          var url = '../invoceInfo/main';
          wx.navigateTo({ url: url });
        }
      },
      onShow: function onShow() {
        this.getJSON();
      },
      onLoad: function onLoad(option) {
        this.isSelect = false;
        this.dataArray = [];

        if (option.isSelect) {
          this.isSelect = option.isSelect === '1';
        }
        this.getJSON();
      }
    };

    /***/
  },

  /***/131:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_invoceListCell_vue__ = __webpack_require__(133);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_54830fe6_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_invoceListCell_vue__ = __webpack_require__(134);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(132);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = null;
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_invoceListCell_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_54830fe6_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_invoceListCell_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/components/invoceListCell.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] invoceListCell.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-54830fe6", Component.options);
        } else {
          hotAPI.reload("data-v-54830fe6", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/132:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/133:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          taxNo: ''
        };
      },

      props: ['item'],
      onLoad: function onLoad() {
        console.log('listcell ->', this.item);
        // console.log(this.item.taxNo.replace(/(.{3}).*(.{4})/, '$1******$2'))
        this.taxNo = this.item.taxNo.replace(/(.{3}).*(.{4})/, '$1******$2');
      }
    };

    /***/
  },

  /***/134:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "cellFlex"
      }, [_c('view', {
        staticClass: "cellItem cellBlock"
      }, [_vm._v("抬头: " + _vm._s(_vm.item.name))]), _vm._v(" "), _c('view', {
        staticClass: "cellItem cellGray"
      }, [_vm._v(_vm._s(_vm.item.head === 1 ? '企业' : '个人'))])]), _vm._v(" "), _c('view', {
        staticClass: "cellFlex"
      }, [_c('view', {
        staticClass: "cellItem cellGray"
      }, [_vm._v(_vm._s(_vm.item.content))]), _vm._v(" "), _vm.item.head === 1 ? _c('block', [_c('view', {
        staticClass: "cellItem cellGray"
      }, [_vm._v("税号: " + _vm._s(_vm.taxNo))])]) : _vm._e()], 1)]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-54830fe6", esExports);
      }
    }

    /***/
  },

  /***/135:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "top"
      }, [_vm._l(_vm.dataArray, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          staticClass: "cell",
          attrs: {
            "eventid": '0_' + index
          },
          on: {
            "click": function click($event) {
              _vm.actionSelect(item, index);
            }
          }
        }, [_c('invoceListCell', {
          attrs: {
            "item": item,
            "mpcomid": '0_' + index
          }
        })], 1)]);
      }), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 2), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('button', {
        staticClass: "btnClass",
        attrs: {
          "eventid": '1'
        },
        on: {
          "click": _vm.actionClick
        }
      }, [_vm._v("添加")])], 1)]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-3c14a1a8", esExports);
      }
    }

    /***/
  }

}, [127]);
});require("pages/invoceList/main.js")
var __wxRoute = "pages/invoceInfo/main", __wxRouteBegin = true;
define("pages/invoceInfo/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([19], {

  /***/122:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(123);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/123:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(125);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1ae4fc90_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(126);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(124);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-1ae4fc90";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1ae4fc90_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/invoceInfo/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-1ae4fc90", Component.options);
        } else {
          hotAPI.reload("data-v-1ae4fc90", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/124:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/125:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__utils_index__ = __webpack_require__(17);
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          ids: '',
          union: false,
          id: '',
          content: '鉴证咨询服务费',
          type: 1,
          head: 1,
          name: '',
          taxNo: '',
          account: '',
          phone: '',
          address: ''
        };
      },

      components: {},

      methods: {
        actionSelect: function actionSelect(key, value) {
          this[key] = value;
          if (this.type === 2) {
            this.head = 1;
          }
        },

        setName: function setName(e, key) {
          this[key] = e.mp.detail;
        },
        setTax: function setTax(e, key) {
          this[key] = e.mp.detail.toUpperCase();
        },
        actionDelete: function actionDelete() {
          var that = this;
          var dict = {
            'id': this.id
          };
          this.NJKit.showLoading();
          that.API.inoviceDelete(dict).then(function (success) {
            that.NJKit.hideLoading();
            that.NJKit.showToast('删除成功');
            wx.navigateBack();
          }, function (failure) {
            that.NJKit.hideLoading();
            wx.navigateBack();
            console.log('failure =>', failure);
          });
        },
        actionBeforeSave: function actionBeforeSave(saveType) {
          console.log('self', this);
          if (this.content.length === 0) {
            this.NJKit.showToast('请填写发票内容');
            return;
          }
          if (this.type === 2) {
            if (this.account.length === 0) {
              this.NJKit.showToast('请填写帐号');
              return;
            }
            if (!Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["a" /* checkNumber */])(this.account)) {
              this.NJKit.showToast('请检查帐号');
              return;
            }
            if (this.phone.length === 0) {
              this.NJKit.showToast('请填写电话');
              return;
            }
            if (!Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["b" /* checkPhone */])(this.phone)) {
              this.NJKit.showToast('请检查电话号码');
              return;
            }
            if (this.address.length === 0) {
              this.NJKit.showToast('请填写地址');
              return;
            }
          }
          if (this.head === 1) {
            if (this.name.length === 0) {
              this.NJKit.showToast('请填写发票抬头名称');
              return;
            }
            if (this.taxNo.length === 0) {
              this.NJKit.showToast('请填写纳税人识别号');
              return;
            }
            if (!Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["c" /* checkTaxNo */])(this.taxNo)) {
              this.NJKit.showToast('请检查纳税人识别号');
              return;
            }
          }
          if (this.head === 2) {
            if (this.name.length === 0) {
              this.NJKit.showToast('请填写发票抬头');
              return;
            }
          }
          if (saveType === 'actionInvoiceSave') {
            this.actionInvoiceSave();
          }
          if (saveType === 'actionUnionInvoice') {
            this.actionUnionInvoice();
          }
        },
        actionInvoiceSave: function actionInvoiceSave() {
          var dict = {
            'id': this.id,
            'openId': this.NJKit.getToken(),
            'content': this.content,
            'type': this.type,
            'head': this.head,
            'name': this.name,
            'taxNo': this.taxNo,
            'account': this.account,
            'phone': this.phone,
            'address': this.address
          };
          var that = this;
          this.NJKit.showLoading();
          that.API.invoiceSave(dict).then(function (success) {
            that.NJKit.hideLoading();
            console.log('success =>', success);
            that.NJKit.showToast(success.message);
            wx.navigateBack();
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
            that.NJKit.showToast('保存失败');
          });
        },
        actionUnionInvoice: function actionUnionInvoice() {
          var dict = {
            'id': this.id,
            'openId': this.NJKit.getToken(),
            'content': this.content,
            'type': this.type,
            'head': this.head,
            'name': this.name,
            'taxNo': this.taxNo,
            'account': this.account,
            'phone': this.phone,
            'address': this.address,
            'orderIds': this.ids
          };
          var that = this;
          that.API.unionInvoice(dict).then(function (success) {
            console.log('success =>', success);
            that.NJKit.showToast(success.message);
            wx.navigateBack({ delta: 100 });
          }, function (failure) {
            console.log('failure =>', failure);
            that.NJKit.showToast('保存失败');
          });
        }
      },
      onLoad: function onLoad(option) {
        this.union = false;
        this.id = '';
        this.content = '鉴证咨询服务费';
        this.type = 1;
        this.head = 1;
        this.name = '';
        this.taxNo = '';
        this.account = '';
        this.phone = '';
        this.address = '';
        console.log('option =>', option);
        if (option.json) {
          var res = JSON.parse(option.json);
          this.id = res.id;
          this.content = res.content;
          this.type = res.type;
          this.head = res.head;
          this.name = res.name;
          this.taxNo = res.taxNo;
          this.account = res.account;
          this.phone = res.phone;
          this.address = res.address;
        }
        if (option.ids) {
          this.union = true;
          this.ids = option.ids;
        }
      }
    };

    /***/
  },

  /***/126:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('div', [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "radio-container"
      }, [_c('van-cell-group', {
        attrs: {
          "mpcomid": '7'
        }
      }, [_c('van-field', {
        attrs: {
          "value": _vm.content,
          "required": "",
          "clearable": "",
          "label": "发票内容",
          "placeholder": "请填写发票内容",
          "eventid": '0',
          "mpcomid": '0'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'content');
          }
        }
      }), _vm._v(" "), _c('view', {
        staticClass: "form_title"
      }, [_vm._v("发票类型")]), _vm._v(" "), _c('view', {
        staticClass: "categoryClass"
      }, [_c('view', {
        class: _vm.type === 1 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '1'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('type', 1);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("普票")])]), _vm._v(" "), _c('view', {
        class: _vm.type === 2 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '2'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('type', 2);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("专票")])])]), _vm._v(" "), _c('view', {
        staticClass: "form_title"
      }, [_vm._v("发票抬头")]), _vm._v(" "), _c('view', {
        staticClass: "categoryClass"
      }, [_c('view', {
        class: _vm.head === 1 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '3'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('head', 1);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("企业")])]), _vm._v(" "), _c('view', {
        class: _vm.head === 2 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '4'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('head', 2);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("个人")])])]), _vm._v(" "), _vm.head === 1 ? _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "企业名称",
          "placeholder": "请填写发票抬头名称",
          "eventid": '5',
          "mpcomid": '1'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'name');
          }
        },
        model: {
          value: _vm.name,
          callback: function callback($$v) {
            _vm.name = $$v;
          },
          expression: "name"
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "企业税号",
          "placeholder": "请填写纳税人识别号",
          "eventid": '6',
          "mpcomid": '2'
        },
        on: {
          "change": function change($event) {
            _vm.setTax($event, 'taxNo');
          }
        },
        model: {
          value: _vm.taxNo,
          callback: function callback($$v) {
            _vm.taxNo = $$v;
          },
          expression: "taxNo"
        }
      })], 1) : _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "个人",
          "placeholder": "请填写个人名称",
          "eventid": '7',
          "mpcomid": '3'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'name');
          }
        },
        model: {
          value: _vm.name,
          callback: function callback($$v) {
            _vm.name = $$v;
          },
          expression: "name"
        }
      })], 1), _vm._v(" "), _vm.type === 2 ? _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "帐号",
          "placeholder": "请填写帐号",
          "eventid": '8',
          "mpcomid": '4'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'account');
          }
        },
        model: {
          value: _vm.account,
          callback: function callback($$v) {
            _vm.account = $$v;
          },
          expression: "account"
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "type": "number",
          "required": "",
          "clearable": "",
          "label": "电话",
          "placeholder": "请填写电话",
          "eventid": '9',
          "mpcomid": '5'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'phone');
          }
        },
        model: {
          value: _vm.phone,
          callback: function callback($$v) {
            _vm.phone = $$v;
          },
          expression: "phone"
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "地址",
          "placeholder": "请填写地址",
          "eventid": '10',
          "mpcomid": '6'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'address');
          }
        },
        model: {
          value: _vm.address,
          callback: function callback($$v) {
            _vm.address = $$v;
          },
          expression: "address"
        }
      })], 1) : _vm._e()], 1)], 1)]), _vm._v(" "), _vm.union ? _c('block', [_c('view', {
        staticClass: "btnClass"
      }, [_c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '11'
        },
        on: {
          "click": function click($event) {
            _vm.actionBeforeSave('actionUnionInvoice');
          }
        }
      }, [_vm._v("提交")])], 1)]) : _c('block', [_c('view', {
        staticClass: "btnClass"
      }, [_c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '12'
        },
        on: {
          "click": function click($event) {
            _vm.actionBeforeSave('actionInvoiceSave');
          }
        }
      }, [_vm._v("保存")])], 1), _vm._v(" "), _c('view', {
        staticClass: "btnClass"
      }, [_c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '13'
        },
        on: {
          "click": _vm.actionDelete
        }
      }, [_vm._v("删除")])], 1)])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-1ae4fc90", esExports);
      }
    }

    /***/
  }

}, [122]);
});require("pages/invoceInfo/main.js")
var __wxRoute = "pages/packageList/main", __wxRouteBegin = true;
define("pages/packageList/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([13], {

  /***/170:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(171);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/171:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(173);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1fed2a30_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(174);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(172);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-1fed2a30";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1fed2a30_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/packageList/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-1fed2a30", Component.options);
        } else {
          hotAPI.reload("data-v-1fed2a30", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/172:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/173:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          custom: false,
          prices: 0,
          floorPrices: 0,
          packageArray: [],
          selectedItem: {},
          listArray: [],
          tabArr: [],
          packageId: ''
        };
      },

      components: {},

      methods: {
        actionBuy: function actionBuy() {
          if (this.custom) {
            var array = [];
            this.listArray.map(function (item, index) {
              if (item.checked) {
                array.push(item);
              }
            });
            if (array.length === 0) {
              this.NJKit.showToast('请选择套餐');
              return;
            }
            this.selectedItem.packageInfo = array;
          }
          var dict = {
            'selectedItem': this.selectedItem,
            'packageId': this.selectedItem.id,
            'custom': this.custom
          };
          console.log('dict', dict);
          var url = '../orderBuy/main?dict=' + __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(dict);
          wx.navigateTo({ url: url });
        },
        countPrice: function countPrice() {
          var list = [];
          this.listArray.map(function (item) {
            if (item.checked) {
              list.push(item);
            }
          });
          var that = this;
          var dict = {
            'packageInfo': __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(list)
          };
          this.NJKit.showLoading();
          this.API.caculate(dict).then(function (succ) {
            that.NJKit.hideLoading();
            that.prices = succ.prices;
            that.floorPrices = succ.floorPrices;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        checkboxChange: function checkboxChange(e) {
          var idsArr = e.mp.detail.value;
          for (var i = 0; i < this.listArray.length; i++) {
            var item = this.listArray[i];
            if (idsArr.indexOf(item.name) !== -1) {
              this.listArray[i].checked = true;
            } else {
              this.listArray[i].checked = false;
            }
          }
          this.countPrice();
        },
        tapTabs: function tapTabs(ev) {
          console.log('tapTabs =>', ev);
          var index = ev.mp.detail.index;
          this.changePackage(index);
        },
        changePackage: function changePackage(index) {
          this.selectedIndex = index;
          this.selectedItem = this.packageArray[index];
          if (this.custom) {
            this.listArray = this.selectedItem.packageInfo;
            this.listArray.map(function (item) {
              item.checked = true;
            });
            this.countPrice();
          } else {
            this.listArray = this.selectedItem.packageInfo.split(',');
            this.prices = this.selectedItem.price;
            this.floorPrices = this.selectedItem.floorPrice;
          }
        },
        configTabs: function configTabs() {
          var array = [];
          this.packageArray.map(function (item, index) {
            array.push(item.packageType);
          });
          this.tabArr = array;
        },
        getPackage: function getPackage(dict) {
          var that = this;
          this.packageId = dict.id;
          this.NJKit.showLoading();
          this.API.findPackage(dict).then(function (success) {
            that.NJKit.hideLoading();
            console.log('success =>', success);
            that.packageArray = success.data;
            that.configTabs();
            that.changePackage(0);
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        }
      },
      onLoad: function onLoad(option) {
        this.custom = false;
        this.sumPrice = '';
        this.packageArray = [];
        this.selectedItem = {};
        this.listArray = [];
        this.tabArr = [];
        this.packageId = '';

        var dict = JSON.parse(option.dict);
        this.custom = dict.custom;
        this.getPackage(dict);
      }
    };

    /***/
  },

  /***/174:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('van-tabs', {
        attrs: {
          "color": "#4ad4d4",
          "eventid": '0',
          "mpcomid": '1'
        },
        on: {
          "change": _vm.tapTabs
        }
      }, _vm._l(_vm.tabArr, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('van-tab', {
          attrs: {
            "title": item,
            "mpcomid": '0_' + index
          }
        }, [_c('view', {
          staticClass: "tab_title"
        }, [_vm._v(_vm._s(_vm.selectedItem.name))])])], 1);
      })), _vm._v(" "), _c('view', {
        staticClass: "top"
      }, [_vm.custom ? _c('block', [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "radio-container"
      }, [_c('checkbox-group', {
        staticClass: "checkbox-group",
        attrs: {
          "eventid": '1',
          "mpcomid": '2'
        },
        on: {
          "change": _vm.checkboxChange
        }
      }, _vm._l(_vm.listArray, function (item, index) {
        return _c('label', {
          key: index,
          staticClass: "checkbox"
        }, [_c('view', [_c('text', {
          staticClass: "item-name"
        }, [_vm._v(_vm._s(item.name))])]), _vm._v(" "), _c('view', {
          staticClass: "flexStyle"
        }, [_c('text', {
          staticClass: "item-price deleteStyle"
        }, [_vm._v("￥" + _vm._s(item.prize))]), _c('text', {
          staticClass: "price"
        }, [_vm._v("￥" + _vm._s(item.floorprize))]), _vm._v(" "), _c('checkbox', {
          staticClass: "check-item",
          attrs: {
            "value": item.name,
            "checked": item.checked
          }
        })], 1)]);
      }))], 1)])]) : _c('block', [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "radio-container"
      }, [_c('checkbox-group', {
        staticClass: "checkbox-group",
        attrs: {
          "mpcomid": '3'
        }
      }, _vm._l(_vm.listArray, function (item, index) {
        return _c('label', {
          key: index,
          staticClass: "checkbox"
        }, [_c('view', [_c('text', {
          staticClass: "item-name"
        }, [_vm._v(_vm._s(item))])])]);
      }))], 1)])]), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })], 1), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('view', {
        staticClass: "btnClass"
      }, [_c('label', {
        staticClass: "priceCheckbox"
      }, [_c('view', {
        staticClass: "flexStyle"
      }, [_c('text', {
        staticClass: "totalPrice"
      }, [_vm._v("合计￥" + _vm._s(_vm.floorPrices))])]), _vm._v(" "), _c('view', [_c('text', {
        staticClass: "deleteStyle"
      }, [_vm._v("￥" + _vm._s(_vm.prices))])])]), _vm._v(" "), _c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '2'
        },
        on: {
          "click": _vm.actionBuy
        }
      }, [_vm._v("立即购买")])], 1)])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-1fed2a30", esExports);
      }
    }

    /***/
  }

}, [170]);
});require("pages/packageList/main.js")
var __wxRoute = "pages/other/main", __wxRouteBegin = true;
define("pages/other/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([14], {

  /***/165:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(166);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/166:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(168);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1f8a24fc_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(169);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(167);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-1f8a24fc";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1f8a24fc_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/other/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-1f8a24fc", Component.options);
        } else {
          hotAPI.reload("data-v-1f8a24fc", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/167:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/168:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {};
      },

      components: {},

      methods: {
        actionClick: function actionClick(key) {
          var type = '';
          var packageId = '';
          switch (key) {
            case '植物营养':
              type = '1';
              packageId = '51';
              break;
            case '水质检测':
              type = '2';
              packageId = '52';
              break;
            case '土壤重金属':
              type = '2';
              packageId = '53';
              break;
            case '绿色食品':
              type = '2';
              packageId = '54';
              break;
            case '食品营养':
              type = '2';
              packageId = '55';
              break;
            case '中药材成分':
              type = '2';
              packageId = '56';
              break;
            case '自定义种植检测':
              type = '1';
              packageId = '40';
              break;
            default:
              break;
          }
          if (type === '1') {
            var url = '../customPackage/main?id=' + packageId;
            console.log('url =>', url);
            wx.navigateTo({ url: url });
          } else if (type === '2') {
            var dict = {
              'id': packageId,
              'type': type
            };
            var _url = '../packageList/main?dict=' + __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(dict);
            wx.navigateTo({ url: _url });
          }
        }
      },
      onLoad: function onLoad() {}
    };

    /***/
  },

  /***/169:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "sampleview"
      }, [_c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "1",
          "eventid": '0'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('自定义种植检测');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_plant.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("自定义种植检测")])]), _vm._v(" "), _c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "0",
          "eventid": '1'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('植物营养');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_soil.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("植物营养")])])]), _vm._v(" "), _c('view', {
        staticClass: "sampleview"
      }, [_c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "0",
          "eventid": '2'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('绿色食品');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_greenFood.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("绿色食品")])]), _vm._v(" "), _c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "1",
          "eventid": '3'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('食品营养');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_metal.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("食品营养")])])]), _vm._v(" "), _c('view', {
        staticClass: "sampleview"
      }, [_c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "1",
          "eventid": '4'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('土壤重金属');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_srtoma.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("土壤重金属")])]), _vm._v(" "), _c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "0",
          "eventid": '5'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('中药材成分');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_medicine.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("中药材成分")])])]), _vm._v(" "), _c('view', {
        staticClass: "sampleview"
      }, [_c('view', {
        staticClass: "sampleSubview",
        attrs: {
          "data-index": "0",
          "eventid": '6'
        },
        on: {
          "click": function click($event) {
            _vm.actionClick('水质检测');
          }
        }
      }, [_c('image', {
        attrs: {
          "mode": "aspectFit",
          "src": "/static/images/home/dqy_water.png"
        }
      }), _vm._v(" "), _c('text', {
        staticClass: "sampleText"
      }, [_vm._v("水质检测")])]), _vm._v(" "), _c('view', {
        staticClass: "temp",
        attrs: {
          "data-index": "1"
        }
      })])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-1f8a24fc", esExports);
      }
    }

    /***/
  }

}, [165]);
});require("pages/other/main.js")
var __wxRoute = "pages/customPackage/main", __wxRouteBegin = true;
define("pages/customPackage/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([20], {

  /***/107:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(108);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/108:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(110);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_6ac2d241_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(112);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(109);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-6ac2d241";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_6ac2d241_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/customPackage/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-6ac2d241", Component.options);
        } else {
          hotAPI.reload("data-v-6ac2d241", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/109:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/110:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          oneActive: -1,
          oneArray: [],
          type: '',
          packageId: '',
          isEnd: false,
          custom: false
        };
      },

      components: {},

      methods: {
        actionClick: function actionClick() {
          var dict = {
            'id': this.packageId,
            'type': this.type,
            'custom': this.custom
          };
          var url = '../packageList/main?dict=' + __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(dict);
          wx.navigateTo({ url: url });
        },
        fnOneActive: function fnOneActive(index, ev) {
          this.oneActive = index;
          var item = this.oneArray[index];
          this.fnSelectPackage(item);
        },
        fnSelectPackage: function fnSelectPackage(item) {
          this.packageId = item.id;
          this.isEnd = true;
        },
        getCategory: function getCategory() {
          var getId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '00';
          var resolve = arguments[1];

          var dict = {
            'id': getId
          };
          var that = this;
          this.NJKit.showLoading();
          this.API.category(dict).then(function (success) {
            that.NJKit.hideLoading();
            resolve(success);
          }, function (failure) {
            that.NJKit.hideLoading();
            that.NJKit.showToast(failure);
          });
        }
      },
      onLoad: function onLoad(option) {
        this.packageId = '';
        this.isEnd = false;

        var getId = option.id;
        this.custom = getId === '40';
        var that = this;
        this.getCategory(getId, function (succ) {
          that.oneArray = succ.data;
          if (!succ.moreChild) {
            that.type = succ.type;
          }
        });
      }
    };

    /***/
  },

  /***/112:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "categoryStyle"
      }, [_c('div', {
        staticClass: "tab_title"
      }, [_vm._v("请选择种植类型")]), _vm._v(" "), _c('div', {
        staticClass: "categoryClass"
      }, _vm._l(_vm.oneArray, function (item, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          class: _vm.oneActive === index ? 'categoryItemActive' : 'categoryItem',
          attrs: {
            "eventid": '0_' + index
          },
          on: {
            "click": function click($event) {
              _vm.fnOneActive(index, $event);
            }
          }
        }, [_vm._v("\n          " + _vm._s(item.name) + "\n        ")])]);
      }))]), _vm._v(" "), _vm.isEnd ? _c('block', [_c('button', {
        staticClass: "btnClass",
        attrs: {
          "eventid": '1'
        },
        on: {
          "click": _vm.actionClick
        }
      }, [_vm._v("确定")])], 1) : _vm._e()], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-6ac2d241", esExports);
      }
    }

    /***/
  }

}, [107]);
});require("pages/customPackage/main.js")
var __wxRoute = "pages/orderBuy/main", __wxRouteBegin = true;
define("pages/orderBuy/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([16], {

  /***/155:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(156);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/156:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(158);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_55fe5d02_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(159);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(157);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-55fe5d02";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_55fe5d02_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/orderBuy/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-55fe5d02", Component.options);
        } else {
          hotAPI.reload("data-v-55fe5d02", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/157:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/158:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__utils_index__ = __webpack_require__(17);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          custom: false,
          items: 0,
          prices: 0,
          floorPrices: 0,
          selectedItem: {},
          listArray: [],
          packageId: '',
          oName: '',
          oPhone: '',
          doInvoice: false,
          id: '',
          content: '鉴证咨询服务费',
          type: '1',
          head: '1',
          name: '',
          taxNo: '',
          account: '',
          phone: '',
          address: ''
        };
      },

      components: {},

      methods: {
        setName: function setName(e, key) {
          this[key] = e.mp.detail;
        },
        setTax: function setTax(e, key) {
          this[key] = e.mp.detail.toUpperCase();
        },
        actionSelect: function actionSelect(key, value) {
          this[key] = value;
          if (this.type === 2) {
            this.head = 1;
          }
        },
        selectedInvoice: function selectedInvoice(ev) {
          console.log('ev =>', ev);
          this.doInvoice = ev.mp.detail;
        },
        countPice: function countPice() {
          var that = this;
          var dict = {
            'packageInfo': __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(this.listArray)
          };
          this.NJKit.showLoading();
          this.API.caculate(dict).then(function (succ) {
            that.NJKit.hideLoading();
            console.log('succ =>', succ);
            that.items = succ.items;
            that.prices = succ.prices;
            that.floorPrices = succ.floorPrices;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        actionBuy: function actionBuy() {
          console.log('确认方案');
          if (this.oName.length === 0) {
            this.NJKit.showToast('请填写姓名或单位');
            return;
          }
          if (this.oPhone.length === 0) {
            this.NJKit.showToast('请填写电话');
            return;
          }
          if (this.oPhone.length < 8) {
            this.NJKit.showToast('请检查电话号码');
            return;
          }
          if (!Object(__WEBPACK_IMPORTED_MODULE_1__utils_index__["b" /* checkPhone */])(this.oPhone)) {
            this.NJKit.showToast('请检查电话号码');
            return;
          }
          if (this.head === 1) {
            if (this.name.length === 0) {
              this.NJKit.showToast('请填写发票抬头名称');
              return;
            }
            if (this.taxNo.length === 0) {
              this.NJKit.showToast('请填写纳税人识别号');
              return;
            }
            if (Object(__WEBPACK_IMPORTED_MODULE_1__utils_index__["c" /* checkTaxNo */])(this.taxNo)) {
              console.log('true');
            } else {
              console.log('false');
              this.NJKit.showToast('请检查纳税人识别号');
              return;
            }
          }
          if (this.head === 2) {
            if (this.name.length === 0) {
              this.NJKit.showToast('请填写发票抬头');
              return;
            }
          }
          if (this.type === 2) {
            if (this.account.length === 0) {
              this.NJKit.showToast('请填写帐号');
              return;
            }
            if (!Object(__WEBPACK_IMPORTED_MODULE_1__utils_index__["a" /* checkNumber */])(this.account)) {
              this.NJKit.showToast('请检查帐号');
              return;
            }
            if (this.phone.length === 0) {
              this.NJKit.showToast('请填写电话');
              return;
            }
            if (this.phone.length < 8) {
              this.NJKit.showToast('请检查电话号码');
              return;
            }
            if (!Object(__WEBPACK_IMPORTED_MODULE_1__utils_index__["b" /* checkPhone */])(this.phone)) {
              this.NJKit.showToast('请检查电话号码');
              return;
            }
            if (this.address.length === 0) {
              this.NJKit.showToast('请填写地址');
              return;
            }
          }

          var array = [];
          if (this.custom) {
            this.listArray.map(function (item, index) {
              if (item.checked) {
                array.push(item);
              }
            });
          }
          var that = this;
          var dict = {
            'packageId': this.packageId,
            'packageInfo': this.custom ? __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(array) : this.selectedItem.packageInfo,
            'openId': this.NJKit.getToken(),
            'oName': this.oName,
            'oPhone': this.oPhone,
            'doInvoice': this.doInvoice,
            'id': this.id,
            'content': this.content,
            'type': this.type,
            'head': this.head,
            'name': this.name,
            'taxNo': this.taxNo,
            'account': this.account,
            'phone': this.phone,
            'address': this.address
          };
          this.NJKit.showLoading();
          that.API.orderSave(dict).then(function (succ) {
            that.NJKit.hideLoading();
            console.log('succ =>', succ);
            wx.requestPayment({
              timeStamp: succ.data.timeStamp,
              nonceStr: succ.data.nonceStr,
              package: succ.data.package,
              signType: succ.data.signType,
              paySign: succ.data.paySign,
              success: function success(res) {
                that.NJKit.showToast('支付成功');
                console.log('success =>', res);
                wx.navigateBack({
                  delta: 100
                });
              },
              fail: function fail(res) {
                that.NJKit.showToast('支付失败');
                console.log('failure =>', res);
              }
            });
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        }
      },
      onLoad: function onLoad(option) {
        this.custom = false;
        this.items = 0;
        this.prices = 0;
        this.floorPrices = 0;
        this.selectedItem = {};
        this.listArray = [];
        this.packageId = '';
        this.oName = '';
        this.oPhone = '';
        this.doInvoice = false;
        this.id = '';
        this.content = '鉴证咨询服务费';
        this.type = '1';
        this.head = '1';
        this.name = '';
        this.taxNo = '';
        this.account = '';
        this.phone = '';
        this.address = '';

        console.log('option =>', option);
        // this.getJSON()
        var dict = JSON.parse(option.dict);
        console.log('dict =>', dict);
        this.selectedItem = dict.selectedItem;
        this.packageId = dict.packageId;
        this.custom = dict.custom;
        if (this.custom) {
          this.listArray = this.selectedItem.packageInfo;
          this.countPice();
        } else {
          this.listArray = this.selectedItem.packageInfo.split(',');
          this.items = this.listArray.length;
          this.prices = this.selectedItem.price;
          this.floorPrices = this.selectedItem.floorPrice;
        }
        console.log('listArray =>', this.listArray);
      }
    };

    /***/
  },

  /***/159:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "top"
      }, [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("方案信息")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('checkbox-group', {
        staticClass: "checkbox-group",
        attrs: {
          "mpcomid": '2'
        }
      }, [_c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("套餐类型 : " + _vm._s(_vm.selectedItem.packageType))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v(_vm._s(_vm.selectedItem.name))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("检测项 : " + _vm._s(_vm.items))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("付款金额(元) : " + _vm._s(_vm.floorPrices))])])]), _vm._v(" "), _c('i-collapse', {
        attrs: {
          "mpcomid": '1'
        }
      }, [_c('i-collapse-item', {
        staticClass: "collapseTitleClass",
        attrs: {
          "title": "详情",
          "name": "name1",
          "mpcomid": '0'
        }
      }, _vm._l(_vm.listArray, function (listItem, index) {
        return _c('block', {
          key: index
        }, [_c('view', {
          attrs: {
            "i-class-content": "checkbox"
          },
          slot: "content"
        }, [_vm.custom ? _c('block', [_c('view', {
          staticClass: "collapseContentClass"
        }, [_c('text', {
          staticClass: "item-name"
        }, [_vm._v(_vm._s(listItem.name))]), _vm._v(" "), _c('view', {
          staticClass: "flexStyle"
        }, [_c('text', {
          staticClass: "price"
        }, [_vm._v("￥" + _vm._s(listItem.floorprize))]), _vm._v(" "), _c('text', {
          staticClass: "item-price deleteStyle"
        }, [_vm._v("￥" + _vm._s(listItem.prize))])])])]) : _c('block', [_c('text', {
          staticClass: "item-name"
        }, [_vm._v(_vm._s(listItem))])])], 1)]);
      }))], 1)], 1)], 1)]), _vm._v(" "), _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("送样信息")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('van-field', {
        attrs: {
          "required": "",
          "label": "姓名/单位",
          "placeholder": "请填写姓名或单位",
          "eventid": '0',
          "mpcomid": '3'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'oName');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "type": "number",
          "required": "",
          "label": "电话",
          "placeholder": "请填写电话",
          "eventid": '1',
          "mpcomid": '4'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'oPhone');
          }
        }
      })], 1)]), _vm._v(" "), _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("发票信息(选填)")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('van-switch-cell', {
        attrs: {
          "active-color": "#4ad4d4",
          "title": "开具发票",
          "checked": _vm.doInvoice,
          "eventid": '2',
          "mpcomid": '5'
        },
        on: {
          "change": _vm.selectedInvoice
        }
      }), _vm._v(" "), _vm.doInvoice ? _c('block', [_c('van-cell-group', {
        attrs: {
          "mpcomid": '13'
        }
      }, [_c('van-field', {
        attrs: {
          "value": _vm.content,
          "clearable": "",
          "label": "发票内容",
          "placeholder": "请填写发票内容",
          "eventid": '3',
          "mpcomid": '6'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'content');
          }
        }
      }), _vm._v(" "), _c('view', {
        staticClass: "form_title"
      }, [_vm._v("发票类型")]), _vm._v(" "), _c('view', {
        staticClass: "categoryClass"
      }, [_c('view', {
        class: _vm.type === 1 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '4'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('type', 1);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("普票")])]), _vm._v(" "), _c('view', {
        class: _vm.type === 2 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '5'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('type', 2);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("专票")])])]), _vm._v(" "), _c('view', {
        staticClass: "form_title"
      }, [_vm._v("发票抬头")]), _vm._v(" "), _c('view', {
        staticClass: "categoryClass"
      }, [_c('view', {
        class: _vm.head === 1 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '6'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('head', 1);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("企业")])]), _vm._v(" "), _c('view', {
        class: _vm.head === 2 ? 'categoryItemActive' : 'categoryItem',
        attrs: {
          "eventid": '7'
        },
        on: {
          "click": function click($event) {
            _vm.actionSelect('head', 2);
          }
        }
      }, [_c('view', {
        staticClass: "form_title"
      }, [_vm._v("个人")])])]), _vm._v(" "), _vm.head === 1 ? _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "企业名称",
          "placeholder": "请填写发票抬头名称",
          "eventid": '8',
          "mpcomid": '7'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'name');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "企业税号",
          "placeholder": "请填写纳税人识别号",
          "eventid": '9',
          "mpcomid": '8'
        },
        on: {
          "change": function change($event) {
            _vm.setTax($event, 'taxNo');
          }
        },
        model: {
          value: _vm.taxNo,
          callback: function callback($$v) {
            _vm.taxNo = $$v;
          },
          expression: "taxNo"
        }
      })], 1) : _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "个人",
          "placeholder": "请填写个人名称",
          "eventid": '10',
          "mpcomid": '9'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'name');
          }
        }
      })], 1), _vm._v(" "), _vm.type === 2 ? _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "帐号",
          "placeholder": "请填写帐号",
          "eventid": '11',
          "mpcomid": '10'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'account');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "type": "number",
          "clearable": "",
          "label": "电话",
          "placeholder": "请填写电话",
          "eventid": '12',
          "mpcomid": '11'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'phone');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "clearable": "",
          "label": "地址",
          "placeholder": "请填写地址",
          "eventid": '13',
          "mpcomid": '12'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'address');
          }
        }
      })], 1) : _vm._e()], 1)], 1) : _vm._e()], 1)]), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })]), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('view', {
        staticClass: "btnClass"
      }, [_c('label', {
        staticClass: "priceCheckbox"
      }, [_c('view', {
        staticClass: "flexStyle"
      }, [_c('text', {
        staticClass: "totalPrice"
      }, [_vm._v("合计￥" + _vm._s(_vm.floorPrices))])]), _vm._v(" "), _c('view', [_c('text', {
        staticClass: "deleteStyle"
      }, [_vm._v("￥" + _vm._s(_vm.prices))])])]), _vm._v(" "), _c('button', {
        staticClass: "okBtn",
        attrs: {
          "eventid": '14'
        },
        on: {
          "click": _vm.actionBuy
        }
      }, [_vm._v("立即支付")])], 1)])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-55fe5d02", esExports);
      }
    }

    /***/
  }

}, [155]);
});require("pages/orderBuy/main.js")
var __wxRoute = "pages/commitSample/main", __wxRouteBegin = true;
define("pages/commitSample/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([22], {

  /***/90:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(91);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/91:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(93);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_f22000aa_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(94);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(92);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-f22000aa";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_f22000aa_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/commitSample/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-f22000aa", Component.options);
        } else {
          hotAPI.reload("data-v-f22000aa", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/92:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/93:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__utils_index__ = __webpack_require__(17);
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          actions: [{ 'name': '土壤采样说明' }, { 'name': '基质采样说明' }, { 'name': '水质采样说明' }, { 'name': '植物采样说明' }],
          showActionSheet: false,
          orderId: '',
          showDatePicker: false,
          minDate: Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["e" /* datePast */])(),
          maxDate: Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["d" /* dateNow */])(),
          samplingDateTimeStamp: '',
          crop: '',
          plantArea: '',
          locations: '',
          samplingDate: '',
          transportType: '',
          courierNumber: '',
          carrier: ''
        };
      },

      components: {},

      methods: {
        selectActionSheet: function selectActionSheet(e) {
          var index = e.mp.detail.index;
          var value = this.actions[index].name;
          this.closeActionSheet();
          var uri = '';
          switch (value) {
            case '土壤采样说明':
              uri = 'soilSampleInstr';
              break;
            case '基质采样说明':
              uri = 'stromaSampleInstr';
              break;
            case '水质采样说明':
              uri = 'waterSampleInstr';
              break;
            case '植物采样说明':
              uri = 'plantSampleInstr';
              break;
          }
          var url = '../' + uri + '/main';
          wx.navigateTo({ url: url });
        },
        closeActionSheet: function closeActionSheet() {
          this.showActionSheet = false;
        },
        actionSampleInstr: function actionSampleInstr() {
          this.showActionSheet = true;
        },
        actionComfirm: function actionComfirm(e) {
          this.samplingDateTimeStamp = e.mp.detail;
          this.samplingDate = Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["g" /* formatYYYYMMDD */])(e.mp.detail);
          this.actionCloseDatePicker();
        },
        actionCancel: function actionCancel(e) {
          this.actionCloseDatePicker();
        },
        actionOpenDatePicker: function actionOpenDatePicker() {
          this.showDatePicker = true;
        },
        actionCloseDatePicker: function actionCloseDatePicker() {
          this.showDatePicker = false;
        },

        setName: function setName(e, key) {
          this[key] = e.mp.detail;
        },
        onChangeRadio: function onChangeRadio(e) {
          console.log('e =>', e);
          this.transportType = e.mp.detail;
        },
        actionBuy: function actionBuy() {
          console.log('提交样本');
          if (this.crop.length === 0) {
            this.NJKit.showToast('请填写种植作物');
            return;
          }
          if (this.plantArea.length === 0) {
            this.NJKit.showToast('请填写种植面积');
            return;
          }
          if (this.locations.length === 0) {
            this.NJKit.showToast('请填写省市县镇乡地址');
            return;
          }
          if (this.samplingDate.length === 0) {
            this.NJKit.showToast('请填写采样日期');
            return;
          }
          if (this.locations.length === 0) {
            this.NJKit.showToast('请填写省市县镇乡地址');
            return;
          }
          if (this.transportType.length === 0) {
            this.NJKit.showToast('请选择送检方式');
            return;
          }
          if (this.transportType === '1' && this.courierNumber.length === 0) {
            this.NJKit.showToast('请填写快递单号');
            return;
          }
          if (this.transportType === '2' && this.carrier.length === 0) {
            this.NJKit.showToast('请填写送检人');
            return;
          }
          var that = this;
          var commitSampleDict = {
            'id': this.orderId,
            'crop': this.crop,
            'plantArea': this.plantArea,
            'locations': this.locations,
            'samplingDate': this.samplingDate,
            'transportType': this.transportType,
            'courierNumber': this.courierNumber,
            'carrier': this.carrier
          };
          this.NJKit.showLoading();
          this.API.commitSample(commitSampleDict).then(function (success) {
            that.NJKit.hideLoading();
            console.log('commitSample =>', success);
            that.NJKit.showToast(success.message);
            wx.navigateBack({ delta: 100 });
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        }
      },
      onLoad: function onLoad(option) {
        this.showDatePicker = false;
        this.minDate = Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["e" /* datePast */])();
        this.maxDate = Object(__WEBPACK_IMPORTED_MODULE_0__utils_index__["d" /* dateNow */])();
        this.samplingDateTimeStamp = '';
        this.crop = '';
        this.plantArea = '';
        this.locations = '';
        this.samplingDate = '';
        this.transportType = '';
        this.courierNumber = '';
        this.carrier = '';

        console.log('option =>', option);
        this.orderId = option.id;
      }
    };

    /***/
  },

  /***/94:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "top"
      }, [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("填写送样信息")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('van-field', {
        attrs: {
          "required": "",
          "label": "种植作物",
          "placeholder": "请填写种植作物",
          "eventid": '0',
          "mpcomid": '0'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'crop');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "type": "number",
          "required": "",
          "label": "种植面积(亩)",
          "placeholder": "请填写种植面积",
          "eventid": '1',
          "mpcomid": '1'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'plantArea');
          }
        }
      }), _vm._v(" "), _c('van-field', {
        attrs: {
          "required": "",
          "label": "采样地点",
          "placeholder": "请填写省市县镇乡地址",
          "eventid": '2',
          "mpcomid": '2'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'locations');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "required": "",
          "title": "采样日期",
          "value": _vm.samplingDate,
          "is-link": "",
          "eventid": '3',
          "mpcomid": '3'
        },
        on: {
          "click": _vm.actionOpenDatePicker
        }
      }), _vm._v(" "), _c('van-popup', {
        attrs: {
          "position": "bottom",
          "show": _vm.showDatePicker,
          "eventid": '5',
          "mpcomid": '5'
        },
        on: {
          "close": _vm.actionCloseDatePicker
        }
      }, [_c('van-datetime-picker', {
        attrs: {
          "type": "date",
          "value": _vm.samplingDateTimeStamp,
          "min-date": _vm.minDate,
          "max-date": _vm.maxDate,
          "eventid": '4',
          "mpcomid": '4'
        },
        on: {
          "confirm": _vm.actionComfirm,
          "cancel": _vm.actionCancel
        }
      })], 1), _vm._v(" "), _c('van-radio-group', {
        attrs: {
          "value": _vm.transportType,
          "eventid": '6',
          "mpcomid": '8'
        },
        on: {
          "change": _vm.onChangeRadio
        }
      }, [_c('view', {
        staticClass: "rowClass"
      }, [_c('view', {
        staticClass: "vanClass"
      }, [_vm._v("送检方式:")]), _vm._v(" "), _c('van-radio', {
        staticClass: "vanClass",
        attrs: {
          "name": "1",
          "mpcomid": '6'
        }
      }, [_vm._v("快递")]), _vm._v(" "), _c('van-radio', {
        staticClass: "vanClass",
        attrs: {
          "name": "2",
          "mpcomid": '7'
        }
      }, [_vm._v("自送")])], 1)]), _vm._v(" "), _vm.transportType === '1' ? _c('block', [_c('van-field', {
        attrs: {
          "type": "number",
          "required": "",
          "label": "快递单号",
          "placeholder": "请填写快递单号",
          "eventid": '7',
          "mpcomid": '9'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'courierNumber');
          }
        }
      })], 1) : _c('block', [_c('van-field', {
        attrs: {
          "required": "",
          "label": "送检人",
          "placeholder": "请填写送检人",
          "eventid": '8',
          "mpcomid": '10'
        },
        on: {
          "change": function change($event) {
            _vm.setName($event, 'carrier');
          }
        }
      })], 1)], 1), _vm._v(" "), _c('view', {
        staticClass: "order_title"
      }, [_c('view', {
        attrs: {
          "eventid": '9'
        },
        on: {
          "click": _vm.actionSampleInstr
        }
      }, [_vm._v("请根据 "), _c('text', {
        staticStyle: {
          "color": "red"
        }
      }, [_vm._v("采样说明")]), _vm._v(" 进行采样，填写好采样信息，并将采集好的样本邮寄到以下地址：")])]), _vm._v(" "), _c('view', {
        staticClass: "order_title"
      }, [_vm._v("收件人：施敏")]), _vm._v(" "), _c('view', {
        staticClass: "order_title"
      }, [_vm._v("手机号：18388127437")]), _vm._v(" "), _c('view', {
        staticClass: "order_title"
      }, [_vm._v("地址：云南省昆明市盘龙区北京路2238号云南省农科院大蚯蚓科技检测实验组")])])]), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('button', {
        staticClass: "btnClass",
        attrs: {
          "eventid": '10'
        },
        on: {
          "click": _vm.actionBuy
        }
      }, [_vm._v("提交")])], 1), _vm._v(" "), _c('i-action-sheet', {
        attrs: {
          "visible": _vm.showActionSheet,
          "actions": _vm.actions,
          "show-cancel": "",
          "eventid": '11',
          "mpcomid": '11'
        },
        on: {
          "cancel": _vm.closeActionSheet,
          "iclick": function iclick($event) {
            _vm.selectActionSheet($event);
          }
        }
      })], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-f22000aa", esExports);
      }
    }

    /***/
  }

}, [90]);
});require("pages/commitSample/main.js")
var __wxRoute = "pages/reportList/main", __wxRouteBegin = true;
define("pages/reportList/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([11], {

  /***/180:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(181);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/181:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(183);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_05c3a85c_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(184);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(182);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-05c3a85c";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_05c3a85c_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/reportList/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-05c3a85c", Component.options);
        } else {
          hotAPI.reload("data-v-05c3a85c", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/182:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/183:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          nodata: false,
          dataArray: []
        };
      },

      components: {},

      methods: {
        checkPdf: function checkPdf(item) {
          var dict = {
            'id': item.id
          };
          var url = this.API.downloadPDF(dict);
          console.log('path =>', url);
          wx.downloadFile({
            url: url,
            success: function success(res) {
              var downloadPath = res.tempFilePath;
              console.log('downloadPath =>', downloadPath);
              wx.openDocument({
                filePath: downloadPath,
                fileType: 'pdf',
                success: function success(res) {
                  console.log('打开文档成功 =>', res);
                },
                fail: function fail(err) {
                  console.log('打开失败 =>', err);
                }
              });
            }
          });
        },
        getJSON: function getJSON() {
          var that = this;
          var dict = {
            'openId': this.NJKit.getToken()
          };
          this.NJKit.showLoading();
          this.API.reportList(dict).then(function (success) {
            that.NJKit.hideLoading();
            that.dataArray = success.data;
            that.nodata = success.data.length === 0;
            console.log('nodata =>', that.nodata);
          }, function (failure) {
            that.NJKit.hideLoading();
            that.nodata = false;
            console.log('failure =>', failure);
          });
        }
      },
      onLoad: function onLoad() {
        this.getJSON();
      }
    };

    /***/
  },

  /***/184:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "top"
      }, [_c('view', {
        staticClass: "container"
      }, [_vm.nodata ? _c('block', [_c('view', [_vm._v("暂无数据")])]) : _c('block', _vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v(_vm._s(item.reportName))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('button', {
          staticClass: "smallBtn",
          attrs: {
            "eventid": '0_' + index
          },
          on: {
            "click": function click($event) {
              _vm.checkPdf(item);
            }
          }
        }, [_vm._v("查看报告")]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])], 1)])]);
      }))], 1)])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-05c3a85c", esExports);
      }
    }

    /***/
  }

}, [180]);
});require("pages/reportList/main.js")
var __wxRoute = "pages/unInvoiceList/main", __wxRouteBegin = true;
define("pages/unInvoiceList/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([7], {

  /***/200:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(201);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/201:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(203);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_25e8e37e_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(204);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(202);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-25e8e37e";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_25e8e37e_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/unInvoiceList/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-25e8e37e", Component.options);
        } else {
          hotAPI.reload("data-v-25e8e37e", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/202:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/203:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__ = __webpack_require__(6);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify__);

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */__webpack_exports__["a"] = {
      data: function data() {
        return {
          selected: '2',
          orderNum: 0,
          capital: 0,
          dataArray: []
        };
      },

      components: {},

      methods: {
        onChangeRadio: function onChangeRadio(e) {
          this.selected = e.mp.detail;
          this.selectAll(this.selected === '1');
        },
        selectAll: function selectAll(checked) {
          this.dataArray.map(function (item) {
            item.checked = checked;
          });
          this.calc();
        },
        actionUnionInvoice: function actionUnionInvoice() {
          var array = [];
          var getIds = '';
          this.dataArray.map(function (item) {
            if (item.checked) {
              array.push({ 'id': item.id });
            }
          });
          if (array.length === 0) {
            this.NJKit.showToast('请选择订单');
            return;
          }
          getIds = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_json_stringify___default()(array);
          var url = '../invoceInfo/main?ids=' + getIds;
          wx.navigateTo({ url: url });
        },
        calc: function calc() {
          var array = [];
          var getIds = '';
          this.dataArray.map(function (item) {
            if (item.checked) {
              array.push(item.id);
            }
          });
          getIds = array.join(',');

          var that = this;
          var dict = {
            'openId': this.NJKit.getToken(),
            'orderIds': getIds
          };
          this.NJKit.showLoading();
          this.API.unInvoiceCaculate(dict).then(function (success) {
            that.NJKit.hideLoading();
            that.orderNum = success.orderNum;
            that.capital = success.capital;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('calc failure =>', failure);
          });
        },
        checkboxChange: function checkboxChange(e) {
          var idsArr = e.mp.detail.value;
          for (var i = 0; i < this.dataArray.length; i++) {
            var item = this.dataArray[i];
            if (idsArr.indexOf(item.id) !== -1) {
              this.dataArray[i].checked = true;
            } else {
              this.dataArray[i].checked = false;
            }
          }
          this.calc();
        },
        getJSON: function getJSON() {
          var that = this;
          var dict = {
            'openId': this.NJKit.getToken()
          };
          this.NJKit.showLoading();
          this.API.unInvoiceList(dict).then(function (success) {
            that.NJKit.hideLoading();
            console.log('commitSample =>', success);
            that.dataArray = success.data;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        initConfig: function initConfig() {
          this.selected = '2';
          this.orderNum = 0;
          this.capital = 0;
          this.dataArray = [];
          this.getJSON();
        }
      },
      onLoad: function onLoad() {
        this.initConfig();
      },
      onShow: function onShow() {
        this.initConfig();
      }
    };

    /***/
  },

  /***/204:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "top"
      }, [_c('view', {
        staticClass: "container"
      }, [_c('checkbox-group', {
        attrs: {
          "eventid": '0',
          "mpcomid": '0'
        },
        on: {
          "change": _vm.checkboxChange
        }
      }, _vm._l(_vm.dataArray, function (item, index) {
        return _c('label', {
          key: index
        }, [_c('view', {
          staticClass: "orderCell"
        }, [_c('view', {
          staticClass: "column"
        }, [_c('checkbox', {
          staticClass: "check-item",
          attrs: {
            "value": item.id,
            "checked": item.checked
          }
        }), _vm._v(" "), _c('text', {
          staticClass: "orderState",
          staticStyle: {
            "color": "#FDA773"
          }
        }, [_vm._v("未开票")])], 1), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "orderNo"
        }, [_vm._v("订单号：" + _vm._s(item.id))])]), _vm._v(" "), _c('view', {
          staticClass: "column"
        }, [_c('text', {
          staticClass: "item-price"
        }, [_vm._v("￥" + _vm._s(item.capital))]), _vm._v(" "), _c('text', {
          staticClass: "orderTime"
        }, [_vm._v("下单时间：" + _vm._s(item.creDate))])])])]);
      }))], 1), _vm._v(" "), _c('view', {
        staticClass: "hideBottom"
      })]), _vm._v(" "), _c('view', {
        staticClass: "bottom"
      }, [_c('view', {
        staticClass: "bottomHeader"
      }, [_c('div', {
        staticClass: "left"
      }, [_vm._v(_vm._s(_vm.orderNum) + "个订单,共" + _vm._s(_vm.capital) + "元")])]), _vm._v(" "), _c('view', {
        staticClass: "bottomContent"
      }, [_c('van-radio-group', {
        staticClass: "bottomLeft",
        attrs: {
          "value": _vm.selected,
          "eventid": '1',
          "mpcomid": '3'
        },
        on: {
          "change": _vm.onChangeRadio
        }
      }, [_c('van-radio', {
        staticClass: "vanClass",
        attrs: {
          "name": "1",
          "mpcomid": '1'
        }
      }, [_vm._v("全选")]), _vm._v(" "), _c('van-radio', {
        staticClass: "vanClass",
        attrs: {
          "name": "2",
          "mpcomid": '2'
        }
      }, [_vm._v("全不选")])], 1), _vm._v(" "), _c('button', {
        staticClass: "bottomRight",
        attrs: {
          "eventid": '2'
        },
        on: {
          "click": _vm.actionUnionInvoice
        }
      }, [_vm._v("申请开票")])], 1)])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-25e8e37e", esExports);
      }
    }

    /***/
  }

}, [200]);
});require("pages/unInvoiceList/main.js")
var __wxRoute = "pages/service/main", __wxRouteBegin = true;
define("pages/service/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([10], {

  /***/185:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(186);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/186:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(188);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_76ec7221_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(189);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(187);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-76ec7221";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_76ec7221_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/service/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-76ec7221", Component.options);
        } else {
          hotAPI.reload("data-v-76ec7221", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/187:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/188:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {};

    /***/
  },

  /***/189:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _vm._m(0);
    };
    var staticRenderFns = [function () {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "serviceStyle"
      }, [_c('text', {
        staticClass: "textStyle"
      }, [_vm._v("\n      大蚯蚓检测科技有限公司于2018 年 10 月在云南省农业科学院花卉研究所建立土壤和植物分析实验室，为科研机构、农业公司及农户提供土壤测试、水质、植物营养、重金属及农残检测，并提供专业土壤和植物营养管理指导意见。同时，分析实验室针对花卉、果蔬和果树提供了专业的检测套餐，为种植户提供专业的检测服务。分析实验室由一个高度专业化和国际化的专家团队领导，装备了最先进的检测仪器并引进了国际先进水平的检测流程，可提供土壤，水质，植物营养等近 50个指标的专业检测和分析。通过各项精准可确定土壤中的有效养分的含量，然后根据作物对营养元素的需求做到缺什么、补什么、缺多少、补多少，全面协调植物营养状况，优化资源投入，并达到作物高产、高效、优质的目的，同时保护农业生态环境，节约肥料资源，促进农业可持续发展。截止 2017 年 12 月，通过土壤测试受益土地面积已到达 5000 亩，已开始为数家云南大型花卉企业提供专业土壤和基质检测服务，从而替代了荷兰检测服务商。 \n  ")]), _vm._v(" "), _c('text', {
        staticClass: "textStyle"
      }, [_vm._v("\n      影响农田产量及质量的因素很多，包括自然因素：气候、水分、土壤和地形；人文因素：交通运输、科技水平和消费市场。分析实验室通过与大蚯蚓科技有限公司总部的专业化和国际化的专家团队合作，通过对土壤健康状况、植物健康状况、历史气候气象数据分析、病虫害风险分析、地理及空间遥感分析、周边农业生态环境和水源质量等因素进行综合评估，可为种植户提供精准的数据分析和科学的种植建议。\n  ")])]);
    }];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-76ec7221", esExports);
      }
    }

    /***/
  }

}, [185]);
});require("pages/service/main.js")
var __wxRoute = "pages/soilSampleInstr/main", __wxRouteBegin = true;
define("pages/soilSampleInstr/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([9], {

  /***/190:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(191);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/191:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(193);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_28308362_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(194);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(192);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-28308362";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_28308362_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/soilSampleInstr/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-28308362", Component.options);
        } else {
          hotAPI.reload("data-v-28308362", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/192:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/193:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {};

    /***/
  },

  /***/194:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('scroll-view', {
        staticClass: "sampleInstruction"
      }, [_c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("本采样说明根据“NY/T 1121.1-2006”号标准")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("取土样点选择")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n        1.\t根据所测大田的面积和形状安排取土点，样点的分布尽量要均匀，不可集中，小于10亩的面积至少取3个点，以6个点为佳。\n  2.\t大于10亩的面积，每3-6亩加一个取样点为佳。如土地平整，土壤类型均一，也可5-10亩增加一个取样点。\n  3.\t取样点切不可设在地边、路旁、沟旁、肥堆、农机出入口等地方。\n  4.\t一般采用“Z”字型取土法取样，按大田形状选取取样点后，顺序标记取样点的编号，以方便进行分区检测后按配方精确施肥。\n\n      ")])]), _vm._v(" "), _c('image', {
        attrs: {
          "mode": "scaleToFill",
          "src": "/static/images/sample/soilPic1.png"
        }
      })]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("取土方法")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      1.\t一般选取深度为0-20cm的土样较为适宜，果园为0～40cm，注意每个采样点的取土深度及采样量应均匀一致。每个采样点取400-500g。\n  2. 取土前要刮去取样点的表土，用土钻垂直插入土中，深度为0-20cm（土钻上标有刻度）。如用铁锨取土，则先刮去取样点表土，然后用铁锨挖一个“V”字型土坑，深度为20cm，然后用铁锨斜向下切下一片土壤（所有取样点切下的土壤厚度应基本一致）。\n      ")])]), _vm._v(" "), _c('image', {
        attrs: {
          "mode": "scaleToFill",
          "src": "/static/images/sample/soilPic2.png"
        }
      })]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("土壤收集")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      将采好的土样装入自封袋、内外贴上标签、标签上注明采样地点、深度、前茬作物、种植作物、施肥水平、采集人和日期。针对每种作物，附上一份土壤采集信息表。\n      ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("注意事项")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      采样时一定不能取到肥料，要避开沟渠、林带、田埂、路边、旧房基、粪堆底等无代表性地段。将根系、秸秆、虫体等杂物挑出。避免在长期水淹处或大雨后土壤处于高含水情况下取土。\n      ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("土壤诊断样品的采集")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      为诊断某些植物（包括作物）发生局部死苗、失绿、矮缩、花而不实等异常现象，必须有针对性地对土壤某些成分进行分析，以查明原因。一般应在发生异常现象的范围内，采集典型土壤样品，多点混合，同时，在附近采集正常土样作为对照。\n      ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("土壤物理性质测定样品的采集")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      测定土壤容重和孔隙度等物理性状，须用原状土样，其样品可直接用环刀在各土层中采集。采取土壤结构性的样品，须注意土壤湿度，不宜过干或过湿，应在不粘铲、经接触不变形时分层采取。在取样过程中须保持土块不受挤压、不变形、尽量保持土壤原状，如有受挤压变形的部分要弃去。土样采集后要小心装入铁盒。其他项目土样根据要求装入铝盒或环刀，带回实验室分析测定。 \n      ")])])])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-28308362", esExports);
      }
    }

    /***/
  }

}, [190]);
});require("pages/soilSampleInstr/main.js")
var __wxRoute = "pages/stromaSampleInstr/main", __wxRouteBegin = true;
define("pages/stromaSampleInstr/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([8], {

  /***/195:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(196);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/196:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(198);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1a38e1fc_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(199);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(197);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-1a38e1fc";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_1a38e1fc_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/stromaSampleInstr/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-1a38e1fc", Component.options);
        } else {
          hotAPI.reload("data-v-1a38e1fc", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/197:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/198:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {};

    /***/
  },

  /***/199:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('scroll-view', {
        staticClass: "sampleInstruction"
      }, [_c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("采样注意事项")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n    1.\t刚调配好的基质应放置一天后再取样，要从不同部位混合均匀后取样。 \n    2.\t测量已经植有作物的基质时，要从距表面1/3以下的部位取样，下面2/3处是根生长的主要区域。 \n    3.\t取样量为400-500g\n    4.\t将采好的基质装入自封袋、内外贴上标签、标签上注明编号。\n    ")])])])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-1a38e1fc", esExports);
      }
    }

    /***/
  }

}, [195]);
});require("pages/stromaSampleInstr/main.js")
var __wxRoute = "pages/waterSampleInstr/main", __wxRouteBegin = true;
define("pages/waterSampleInstr/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([6], {

  /***/205:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(206);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/206:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(208);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_b66f2896_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(209);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(207);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-b66f2896";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_b66f2896_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/waterSampleInstr/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-b66f2896", Component.options);
        } else {
          hotAPI.reload("data-v-b66f2896", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/207:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/208:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {};

    /***/
  },

  /***/209:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('scroll-view', {
        staticClass: "sampleInstruction"
      }, [_c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("采样容器的选择")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n    1. 无机化合物检测：聚乙烯塑料瓶500ml；\n    2. 有机化合物检测：玻璃瓶1000ml；保存方法：冷藏；\n    3. 微生物检测：玻璃瓶（灭菌）500ml；保存方法：冷藏。\n    ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("水样的采集")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n    水源水。\n    采样点通常应选择汲水处；采集自喷的泉水可在涌口处直接采样；采集不自喷的泉水时，应将停滞在抽水管中的水汲出，新水更替后再进行采样；井水采集时应在充分抽汲后（存水的2倍以上）进行，以保证水样的代表性。\n    ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("水样采集注意事项")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n    1. 采样时不可搅动水底的沉积物；\n    2. 用于理化指标检测的水样，采集前用待测水样荡洗容器和盖子2-3次。\n    ")])])])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-b66f2896", esExports);
      }
    }

    /***/
  }

}, [205]);
});require("pages/waterSampleInstr/main.js")
var __wxRoute = "pages/plantSampleInstr/main", __wxRouteBegin = true;
define("pages/plantSampleInstr/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([12], {

  /***/175:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(176);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/176:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(178);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_3a96b2e1_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(179);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(177);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-3a96b2e1";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_3a96b2e1_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/plantSampleInstr/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-3a96b2e1", Component.options);
        } else {
          hotAPI.reload("data-v-3a96b2e1", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/177:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/178:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {};

    /***/
  },

  /***/179:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('scroll-view', {
        staticClass: "sampleInstruction"
      }, [_c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("取样部位")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      1.\t通常情况下（植株表现性健康）选择进入生理期的成熟新叶，因为幼嫩叶、老叶及叶柄养分含量变化迅速所以不建议取样。 \n      2.\t若出现严重缺素症状需应急诊断，应从典型症状蜘蛛上采取有症状的叶片，为进行比较，需同时采取生长在正常植株上的同一部位叶片。 \n      3.\t为探明潜在缺素诊断，要根据可能缺乏元素在植株内移动难以决定部位，容易移动的元素如：氮、磷、钾、镁采下位老叶；不易移动的元素如：硼、钙、铁、钼等应采上位新叶。\n    ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("取样时期及时间")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      1.\t最佳采样时期为植物营养生长及生殖生长最旺盛的时期。 \n      2.\t在植物发现缺素或生长不良时需立即采样。 \n      3.\t上午8时到下午3时期间为最佳采样时间。\n    ")])])]), _vm._v(" "), _c('scroll-view', {
        staticClass: "contentView"
      }, [_c('view', {
        staticClass: "flex-view-row tittle"
      }, [_c('view', {
        staticClass: "verticalLine"
      }), _vm._v(" "), _c('view', [_vm._v("采样数量")])]), _vm._v(" "), _c('view', {
        staticClass: "line-css"
      }), _vm._v(" "), _c('view', {
        staticClass: "flex-view-row content"
      }, [_c('text', {
        attrs: {
          "decode": "true",
          "space": "true"
        }
      }, [_vm._v("\n      1. 大田作物 （蔬菜或花卉类）采样20到30个植株为最佳，果树采样应在50个植株以上为最佳。 \n      2. 植物取样与土样相同“Z”字型取样，植物样本可与土样对应采取同一个点，具有对比性。\n      3. 采取的样本装入自封袋密封，内外贴上标签、标签上注明叶片采取部位及编号。3天内送到实验室为最佳检测时间，若无法立马送样需冷藏。\n    ")])]), _vm._v(" "), _c('image', {
        attrs: {
          "mode": "scaleToFill",
          "src": "/static/images/sample/soilPic1.png"
        }
      })])], 1);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-3a96b2e1", esExports);
      }
    }

    /***/
  }

}, [175]);
});require("pages/plantSampleInstr/main.js")
var __wxRoute = "pages/contactus/main", __wxRouteBegin = true;
define("pages/contactus/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([21], {

  /***/95:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(96);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/96:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(98);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_099382ac_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(99);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(97);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-099382ac";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_099382ac_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/contactus/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-099382ac", Component.options);
        } else {
          hotAPI.reload("data-v-099382ac", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/97:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/98:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          userInfo: {},
          hasUserInfo: false,
          canIUse: wx.canIUse('button.open-type.getUserInfo')
        };
      },

      components: {},

      methods: {
        makePhoneCall: function makePhoneCall(num) {
          wx.makePhoneCall({
            phoneNumber: num
          });
        }
      }
    };

    /***/
  },

  /***/99:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_vm._m(0), _vm._v(" "), _c('view', {
        staticClass: "mine_content"
      }, [_c('van-cell-group', {
        attrs: {
          "mpcomid": '3'
        }
      }, [_c('van-cell', {
        attrs: {
          "title": "工作邮箱",
          "value": "lab@daqiuyin.com",
          "mpcomid": '0'
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "工作电话",
          "value": "18388127437",
          "eventid": '0',
          "mpcomid": '1'
        },
        on: {
          "click": function click($event) {
            _vm.makePhoneCall('18388127437');
          }
        }
      }), _vm._v(" "), _c('van-cell', {
        attrs: {
          "title": "地址",
          "value": "昆明市盘龙区北京路延长线2238号云南省农科院花卉研究所",
          "mpcomid": '2'
        }
      })], 1)], 1)]);
    };
    var staticRenderFns = [function () {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', {
        staticClass: "mine_header"
      }, [_c('image', {
        staticClass: "headImage",
        attrs: {
          "mode": "aspectFill",
          "src": "/static/images/mine/raw_1524641901.png"
        }
      })]);
    }];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-099382ac", esExports);
      }
    }

    /***/
  }

}, [95]);
});require("pages/contactus/main.js")
var __wxRoute = "pages/orderDetail/main", __wxRouteBegin = true;
define("pages/orderDetail/main.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

require("../../common/manifest.js");
require("../../common/vendor.js");
global.webpackJsonpMpvue([15], {

  /***/160:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(161);

    // add this to handle exception
    __WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
      if (console && console.error) {
        console.error(err);
      }
    };

    var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
    app.$mount();

    /***/
  },

  /***/161:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    /* harmony import */
    var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(163);
    /* harmony import */var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_0e222fab_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(164);
    var disposed = false;
    function injectStyle(ssrContext) {
      if (disposed) return;
      __webpack_require__(162);
    }
    var normalizeComponent = __webpack_require__(0);
    /* script */

    /* template */

    /* styles */
    var __vue_styles__ = injectStyle;
    /* scopeId */
    var __vue_scopeId__ = "data-v-0e222fab";
    /* moduleIdentifier (server only) */
    var __vue_module_identifier__ = null;
    var Component = normalizeComponent(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */], __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_0e222fab_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */], __vue_styles__, __vue_scopeId__, __vue_module_identifier__);
    Component.options.__file = "src/pages/orderDetail/index.vue";
    if (Component.esModule && Object.keys(Component.esModule).some(function (key) {
      return key !== "default" && key.substr(0, 2) !== "__";
    })) {
      console.error("named exports are not supported in *.vue files.");
    }
    if (Component.options.functional) {
      console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.");
    }

    /* hot reload */
    if (false) {
      (function () {
        var hotAPI = require("vue-hot-reload-api");
        hotAPI.install(require("vue"), false);
        if (!hotAPI.compatible) return;
        module.hot.accept();
        if (!module.hot.data) {
          hotAPI.createRecord("data-v-0e222fab", Component.options);
        } else {
          hotAPI.reload("data-v-0e222fab", Component.options);
        }
        module.hot.dispose(function (data) {
          disposed = true;
        });
      })();
    }

    /* harmony default export */__webpack_exports__["a"] = Component.exports;

    /***/
  },

  /***/162:
  /***/function _(module, exports) {

    // removed by extract-text-webpack-plugin

    /***/},

  /***/163:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    /* harmony default export */
    __webpack_exports__["a"] = {
      data: function data() {
        return {
          id: '',
          phone: '',
          channelName: '',
          courierNumber: '',
          rankB: '',
          itemsInfo: '',
          statusValue: '',
          status: 0,
          channelId: '',
          invoiceId: '',
          rankA: '',
          packageId: '',
          creDate: '',
          capital: 0.00,
          crop: '',
          invoiceStatus: 0,
          isDelete: 0,
          plantArea: '',
          locations: '',
          name: '',
          report: '',
          carrier: '',
          memberId: '',
          itemsType: 0,
          samplingDate: '',
          transportType: ''
        };
      },

      components: {},

      methods: {
        getJSON: function getJSON() {
          var that = this;
          var dict = {
            'id': this.id,
            'openId': this.NJKit.getToken()
          };
          this.NJKit.showLoading();
          that.API.orderDetail(dict).then(function (succ) {
            that.NJKit.hideLoading();
            that.phone = succ.data.phone;
            that.channelName = succ.data.channelName;
            that.courierNumber = succ.data.courierNumber;
            that.rankB = succ.data.rankB;
            that.itemsInfo = succ.data.itemsInfo;
            that.status = succ.data.status;
            that.statusValue = that.getStatus(succ.data.status);
            that.channelId = succ.data.channelId;
            that.invoiceId = succ.data.invoiceId;
            that.rankA = succ.data.rankA;
            that.packageId = succ.data.packageId;
            that.creDate = succ.data.creDate;
            that.capital = succ.data.capital;
            that.crop = succ.data.crop;
            that.invoiceStatus = succ.data.invoiceStatus;
            that.isDelete = succ.data.isDelete;
            that.plantArea = succ.data.plantArea;
            that.locations = succ.data.locations;
            that.name = succ.data.name;
            that.report = succ.data.report;
            that.carrier = succ.data.carrier;
            that.memberId = succ.data.memberId;
            that.itemsType = succ.data.itemsType;
            that.samplingDate = succ.data.samplingDate;
            that.transportType = succ.data.transportType;
          }, function (failure) {
            that.NJKit.hideLoading();
            console.log('failure =>', failure);
          });
        },
        getStatus: function getStatus(status) {
          var res = '';
          switch (status) {
            case 1:
              res = '待付款';
              break;
            case 2:
              res = '待送样';
              break;
            case 3:
              res = '送样中';
              break;
            case 4:
              res = '检测中';
              break;
            case 5:
              res = '完成';
              break;
            default:
              res = '完成';
          }
          console.log('res =>', res);
          return res;
        }
      },
      onLoad: function onLoad(option) {
        console.log('option =>', option);
        this.id = option.id;
        this.getJSON();
      }
    };

    /***/
  },

  /***/164:
  /***/function _(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    var render = function render() {
      var _vm = this;var _h = _vm.$createElement;var _c = _vm._self._c || _h;
      return _c('view', [_c('view', {
        staticClass: "top"
      }, [_c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("订单信息")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('checkbox-group', {
        staticClass: "checkbox-group",
        attrs: {
          "mpcomid": '0'
        }
      }, [_c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("订单号 : " + _vm._s(_vm.id))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("订单金额(元) : " + _vm._s(_vm.capital))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("订单时间 : " + _vm._s(_vm.creDate))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("订单状态 : " + _vm._s(_vm.statusValue))])])])], 1)], 1)]), _vm._v(" "), _c('view', {
        staticClass: "root"
      }, [_c('view', {
        staticClass: "order_title"
      }, [_vm._v("送样信息")]), _vm._v(" "), _c('view', {
        staticClass: "radio-container"
      }, [_c('checkbox-group', {
        staticClass: "checkbox-group",
        attrs: {
          "mpcomid": '1'
        }
      }, [_c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("种植作物 : " + _vm._s(_vm.crop))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("种植面积(亩) : " + _vm._s(_vm.plantArea))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("采样地点 : " + _vm._s(_vm.locations))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("采样日期 : " + _vm._s(_vm.samplingDate))])])]), _vm._v(" "), _c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("送检方式 : " + _vm._s(_vm.transportType === 1 ? '快递' : '自送'))])])]), _vm._v(" "), _vm.transportType === 1 ? _c('block', [_c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("快递单号 : " + _vm._s(_vm.courierNumber))])])])], 1) : _vm._e(), _vm._v(" "), _vm.transportType === 2 ? _c('block', [_c('label', {
        staticClass: "checkbox"
      }, [_c('view', [_c('text', {
        staticClass: "item-name"
      }, [_vm._v("送检人 : " + _vm._s(_vm.carrier))])])])], 1) : _vm._e()], 1)], 1)])])]);
    };
    var staticRenderFns = [];
    render._withStripped = true;
    var esExports = { render: render, staticRenderFns: staticRenderFns
      /* harmony default export */ };__webpack_exports__["a"] = esExports;
    if (false) {
      module.hot.accept();
      if (module.hot.data) {
        require("vue-hot-reload-api").rerender("data-v-0e222fab", esExports);
      }
    }

    /***/
  }

}, [160]);
});require("pages/orderDetail/main.js")