define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

//app.js
App({
  onLaunch: function onLaunch() {},
  globalData: {
    userInfo: null
  }
});
});require("app.js")
var __wxRoute = "pages/index/index", __wxRouteBegin = true;
define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

//index.js
//获取应用实例
var app = getApp();

Page({
  data: {
    motto: 'Hello World',
    mottoxyz: 'ok',
    motto3: ''
  },
  //事件处理函数
  bindViewTap: function bindViewTap() {
    wx.navigateTo({
      url: '../logs/logs'
    });
  },
  onLoad: function onLoad() {},
  getnetwork3: function getnetwork3(e) {
    var that = this;
    wx.request({
      url: 'https://www.easy-mock.com/mock/5baf55473f7d2f35f339d1c6/example/app/res/fields/mine',
      success: function success(result) {
        console.log('request success', result);
        that.setData({
          motto3: '成功 => ' + result
        });
        wx.showToast({
          title: '成功'
        });
      },
      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        console.log('request fail', errMsg);
        that.setData({
          motto3: '失败 => '
        });
        wx.showToast({
          title: '失败'
        });
      }
    });
  },
  getnetwork2: function getnetwork2(e) {
    var that = this;
    wx.request({
      url: 'https://www.easy-mock.com/mock/5baf55473f7d2f35f339d1c6/example/mock/5baf55473f7d2f35f339d1c6/example/nj/login/user',
      data: 'data',
      method: 'POST',
      success: function success(result) {
        console.log('request success', result);
        that.setData({
          mottoxyz: '成功 => ' + result
        });
        wx.showToast({
          title: '成功'
        });
      },
      fail: function fail(_ref2) {
        var errMsg = _ref2.errMsg;

        console.log('request fail', errMsg);
        that.setData({
          mottoxyz: '失败 => '
        });
        wx.showToast({
          title: '失败'
        });
      }
    });
  },
  getnetwork: function getnetwork(e) {
    var that = this;
    wx.request({
      url: 'https://www.kehutuijian.com/miaotui/loginForMiniApps',
      method: 'POST',
      data: 'telephone=13124779516&password=1VSjEvhOEl6Sy83vwyJM5qc7O8QUzltI1PLpdGlW4lI%3D&timestamp=1565596335488&sign=82992ac7de3ab311a0d4101ebb4efc22',
      success: function success(result) {
        wx.showToast({
          title: '成功'
        });
        console.log('request success', result);
        console.log('request success:', result.data.resultMsg);
        that.setData({
          motto: 'result => ' + result.data.resultMsg
        });
      },
      fail: function fail(_ref3) {
        var errMsg = _ref3.errMsg;

        wx.showToast({
          title: '失败'
        });
        that.setData({
          motto: 'result => 网络失败了'
        });
        console.log('request fail', errMsg);
      }
    });
  }
});
});require("pages/index/index.js")